"""FastAPI app: routers (/api + /api/v1), middleware, scheduler, logging."""
import logging
import sys
import traceback

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from . import models as _models  # noqa: F401  (register tables first)
from .db import Base, engine
from .routers import auth, contents, misc, player, playlists, screens

logging.basicConfig(level=logging.INFO, stream=sys.stdout)
log = logging.getLogger("signagecms")

Base.metadata.create_all(bind=engine)

app = FastAPI(title="SignageCMS API", version="1.1")
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_credentials=True,
    allow_methods=["*"], allow_headers=["*"],
)


@app.exception_handler(Exception)
async def unhandled(request: Request, exc: Exception):
    if "HTTPException" in type(exc).__name__:
        raise exc
    log.error(f"500 {request.url.path}: {exc}\n{traceback.format_exc()}")
    return JSONResponse({"detail": "Kesalahan server internal"}, status_code=500)


for prefix in ("/api", "/api/v1"):
    app.include_router(auth.router, prefix=prefix)
    app.include_router(contents.router, prefix=prefix)
    app.include_router(playlists.router, prefix=prefix)
    app.include_router(screens.router, prefix=prefix)
    app.include_router(player.router, prefix=prefix)
    app.include_router(misc.router, prefix=prefix)


@app.on_event("startup")
def _startup():
    try:
        from .scheduler import start
        start()
    except Exception as e:
        log.error(f"scheduler gagal start: {e}")
    log.info("SignageCMS backend siap")


@app.get("/healthz")
def healthz():
    from datetime import datetime, timezone

    return {"ok": True, "time": datetime.now(timezone.utc).isoformat()}
