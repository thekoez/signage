"""Password hashing, JWT, device tokens, signed media URLs."""
import hashlib
import hmac
import secrets
import time
from datetime import datetime, timedelta, timezone

import bcrypt as _bcrypt
from jose import jwt

from . import config


def hash_pw(pw: str) -> str:
    return _bcrypt.hashpw(pw.encode()[:72], _bcrypt.gensalt()).decode()


def verify_pw(pw: str, h: str) -> bool:
    try:
        return _bcrypt.checkpw(pw.encode()[:72], h.encode())
    except Exception:
        return False


def _encode(data: dict) -> str:
    return jwt.encode(data, config.SECRET_KEY, algorithm=config.ALGORITHM)


def _now():
    return datetime.now(timezone.utc)


def make_access(user) -> str:
    return _encode({
        "sub": user.id, "role": user.role, "tv": user.token_version,
        "typ": "access",
        "exp": _now() + timedelta(minutes=config.ACCESS_MIN),
    })


def make_refresh(user) -> str:
    return _encode({
        "sub": user.id, "tv": user.token_version, "typ": "refresh",
        "exp": _now() + timedelta(days=config.REFRESH_DAYS),
    })


def make_challenge(user) -> str:
    return _encode({
        "sub": user.id, "typ": "challenge",
        "exp": _now() + timedelta(minutes=config.CHALLENGE_MIN),
    })


def make_reset(user) -> str:
    return _encode({
        "sub": user.id, "tv": user.token_version, "typ": "reset",
        "exp": _now() + timedelta(hours=2),
    })


def decode(token: str) -> dict:
    return jwt.decode(token, config.SECRET_KEY, algorithms=[config.ALGORITHM])


def new_device_token() -> str:
    return "scr_" + secrets.token_hex(16)


def hash_device_token(tok: str) -> str:
    return hashlib.sha256(tok.encode()).hexdigest()


def sign_media(path: str, exp_sec: int | None = None) -> str:
    exp = int(time.time()) + (exp_sec or config.SIGNED_TTL)
    msg = f"{path}:{exp}".encode()
    sig = hmac.new(config.SECRET_KEY.encode(), msg, hashlib.sha256).hexdigest()
    return f"/media/{path}?exp={exp}&sig={sig}"


def check_media_sig(path: str, exp: str, sig: str) -> bool:
    try:
        if int(exp) < int(time.time()):
            return False
    except ValueError:
        return False
    good = hmac.new(
        config.SECRET_KEY.encode(), f"{path}:{exp}".encode(), hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(good, sig)
