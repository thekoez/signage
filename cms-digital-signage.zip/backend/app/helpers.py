"""Small shared helpers: audit, notifications, pagination."""
from datetime import datetime, timezone

from .models import AuditLog, Notification


def audit(db, action, actor_id=None, entity_type="", entity_id=None, meta=None):
    db.add(AuditLog(
        actor_id=actor_id, action=action, entity_type=entity_type,
        entity_id=str(entity_id) if entity_id else None, meta=meta or {},
    ))


def notify(db, user_id, kind, title, body="", link=None):
    db.add(Notification(
        user_id=user_id, kind=kind, title=title, body=body, link=link,
    ))


def notify_role(db, role, kind, title, body="", link=None, exclude=None):
    from .models import User

    q = db.query(User).filter(User.role == role, User.is_active.is_(True))
    for u in q.all():
        if exclude and u.id == exclude:
            continue
        notify(db, u.id, kind, title, body, link)


def paginate(query, page: int, limit: int):
    page = max(1, page)
    limit = min(100, max(1, limit))
    total = query.count()
    items = query.offset((page - 1) * limit).limit(limit).all()
    return items, total, page, limit


def utcnow():
    return datetime.now(timezone.utc)
