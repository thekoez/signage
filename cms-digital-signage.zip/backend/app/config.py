import os

SECRET_KEY = os.environ.get("JWT_SECRET", "dev-secret-change-me-please-32chars")
ALGORITHM = "HS256"
ACCESS_MIN = int(os.environ.get("JWT_EXPIRE_MIN", "15"))
REFRESH_DAYS = int(os.environ.get("REFRESH_DAYS", "7"))
CHALLENGE_MIN = int(os.environ.get("CHALLENGE_TOKEN_MIN", "5"))
DATABASE_URL = os.environ.get(
    "DATABASE_URL", "sqlite:///./signage.db"
)
MEDIA_DIR = os.environ.get("MEDIA_DIR", "/app/media")
UPLOAD_DIR = os.environ.get("UPLOAD_DIR", "/app/uploads")
MAX_IMAGE_MB = int(os.environ.get("MAX_IMAGE_MB", "10"))
MAX_VIDEO_MB = int(os.environ.get("MAX_VIDEO_MB", "200"))
TZ = os.environ.get("TZ", "Asia/Jakarta")
OFFLINE_SEC = int(os.environ.get("OFFLINE_THRESHOLD_SEC", "90"))
SIGNED_TTL = int(os.environ.get("SIGNED_URL_TTL_SEC", "7200"))
TOTP_ISSUER = os.environ.get("TOTP_ISSUER", "SignageCMS")
TOTP_WINDOW = int(os.environ.get("TOTP_WINDOW", "1"))
REQUIRE_2FA_OWNER = os.environ.get("REQUIRE_2FA_OWNER", "true").lower() == "true"
REQUIRE_2FA_ALL = os.environ.get("REQUIRE_2FA_ALL", "false").lower() == "true"
SMTP_HOST = os.environ.get("SMTP_HOST", "")
SMTP_PORT = int(os.environ.get("SMTP_PORT", "587"))
SMTP_USER = os.environ.get("SMTP_USER", "")
SMTP_PASS = os.environ.get("SMTP_PASS", "")
SMTP_FROM = os.environ.get("SMTP_FROM", "noreply@signagecms.local")
_candidates = [
    os.environ.get("TOTP_ENCRYPTION_KEY", ""),
    "dev-fernet-key-please-change-in-prod!",
]
FERNET_KEY_RAW = _candidates[0] if _candidates[0] else _candidates[1]
