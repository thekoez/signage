"""Seed idempoten: akun, grup, layar, konten, playlist, jadwal, log, notif."""
import random
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

from PIL import Image, ImageDraw

from . import config, security
from .db import SessionLocal
from .helpers import utcnow
from .models import (
    AppSetting, Approval, Assignment, Content, Notification, PlayLog,
    Playlist, PlaylistItem, Report, Schedule, Screen, ScreenGroup, User,
)

PW = security.hash_pw("Signage123!")


def _img(path: Path, text: str, color):
    path.parent.mkdir(parents=True, exist_ok=True)
    im = Image.new("RGB", (1280, 720), color)
    d = ImageDraw.Draw(im)
    d.rectangle([60, 200, 1220, 520], fill=(0, 0, 0))
    d.text((90, 300), text, fill="white")
    d.text((90, 380), "SignageCMS demo", fill=(200, 200, 200))
    im.save(path, "JPEG", quality=85)
    th = path.parent / (path.stem + "_thumb.jpg")
    t = im.copy()
    t.thumbnail((640, 360))
    t.save(th, "JPEG", quality=80)
    return th


def main():
    from .db import Base, engine
    from . import models as _m  # noqa
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        if db.query(User).filter(User.email == "owner@demo.local").first():
            print("seed: sudah ada, lewati", flush=True)
            return
        media = Path(config.MEDIA_DIR)
        users = [
            ("Budi Santoso", "owner@demo.local", "owner"),
            ("Sari Rahma", "marketing@demo.local", "staff"),
            ("Agus Teknisi", "teknisi@demo.local", "teknisi"),
            ("Dimas Prasetyo", "dimas@demo.local", "staff"),
        ]
        umap = {}
        for name, email, role in users:
            u = User(name=name, email=email, password_hash=PW, role=role)
            db.add(u)
            db.flush()
            umap[email] = u
        db.add(AppSetting(key="require_2fa_all", value={"v": False}))
        db.add(AppSetting(key="require_2fa_owner", value={"v": True}))
        db.add(AppSetting(key="timezone", value={"v": "Asia/Jakarta"}))
        groups = {}
        for gname, loc in [("Lobi Gedung A", "Gedung A Lt.1, Jakarta"),
                           ("Toko Cabang 1", "Jl. Merdeka No.10, Bandung"),
                           ("Ruang Tunggu RS", "RS Sehat, Lt.2")]:
            g = ScreenGroup(name=gname, location=loc)
            db.add(g)
            db.flush()
            groups[gname] = g
        screens = {}
        specs = [
            ("Lobi Lt.1 - TV 01", "Lobi Gedung A", "landscape", True, 20),
            ("Lobi Lt.1 - TV 02", "Lobi Gedung A", "landscape", True, 41),
            ("Kasir - Toko Cabang 1", "Toko Cabang 1", "landscape", True, 60),
            ("Etalase - Toko Cabang 1", "Toko Cabang 1", "landscape", True, 47 * 60),
            ("Ruang Tunggu - TV 01", "Ruang Tunggu RS", "portrait", True, 28),
            ("Gudang - TV 01", "Toko Cabang 1", "landscape", False, None),
        ]
        for i, (nm, g, ori, en, ago) in enumerate(specs):
            tok = f"scr_demo{i:02d}" + "a" * 24
            s = Screen(name=nm, group_id=groups[g].id, orientation=ori,
                       is_enabled=en,
                       device_token_hash=security.hash_device_token(tok),
                       last_heartbeat_at=(utcnow() - timedelta(seconds=ago)
                                          if ago is not None else None))
            db.add(s)
            db.flush()
            screens[nm] = (s, tok)
            print(f"seed layar: {nm} token={tok}", flush=True)
        promos = [
            ("Promo Akhir Pekan", "PROMO AKHIR PEKAN s.d. 50%", (14, 165, 233)),
            ("Jadwal Layanan RS", "JADWAL LAYANAN 08-16", (16, 185, 129)),
            ("Selamat Datang", "SELAMAT DATANG", (139, 92, 246)),
            ("Flash Sale 10.10", "FLASH SALE 10.10", (234, 88, 12)),
        ]
        contents = []
        staff = umap["marketing@demo.local"]
        for title, txt, col in promos:
            rel = f"images/2026/10/{uuid.uuid4().hex}.jpg"
            full = media / rel
            th = _img(full, txt, col)
            trel = str(th.relative_to(media)).replace("\\", "/")
            c = Content(title=title, type="image", file_path=rel,
                        thumb_path=trel, mime="image/jpeg",
                        size_bytes=full.stat().st_size, duration_sec=10,
                        width=1280, height=720, status="approved",
                        created_by=staff.id, published_at=utcnow())
            db.add(c)
            contents.append(c)
        db.flush()
        tickers = [
            ("Teks Berjalan Antrian", {"text": "Antrian loket 4-6 pindah ke loket 7-9. Terima kasih.",
                                       "speed": "normal", "fg_color": "#FFFFFF",
                                       "bg_color": "#E11D48", "position": "bottom"}),
            ("Pengumuman Libur", {"text": "PENGUMUMAN: Libur Maulid, layanan buka kembali esok hari.",
                                  "speed": "slow", "fg_color": "#FFFFFF",
                                  "bg_color": "#0369A1", "position": "bottom"}),
        ]
        for title, payload in tickers:
            c = Content(title=title, type="ticker", text_payload=payload,
                        duration_sec=15, status="approved", created_by=staff.id,
                        published_at=utcnow())
            db.add(c)
            contents.append(c)
        db.flush()
        pend = Content(title="Promo Baru - menunggu approval", type="image",
                       file_path=contents[0].file_path, thumb_path=contents[0].thumb_path,
                       mime="image/jpeg", size_bytes=12345, duration_sec=10,
                       status="pending_review", created_by=staff.id, version=2)
        db.add(pend)
        db.flush()
        db.add(Approval(kind="publish", content_id=pend.id, requested_by=staff.id))
        oldc = Content(title="Pengumuman Kadaluarsa", type="notice",
                       text_payload={"text": "Promo lama Juni", "bg_color": "#475569"},
                       duration_sec=10, status="pending_delete",
                       created_by=umap["dimas@demo.local"].id,
                       delete_reason="sudah kedaluwarsa")
        db.add(oldc)
        db.flush()
        db.add(Approval(kind="delete", content_id=oldc.id, requested_by=staff.id))
        pl = Playlist(name="Loop Harian Lobi", description="Putar harian lobi",
                      status="approved", created_by=staff.id, transition="fade")
        db.add(pl)
        db.flush()
        for i, c in enumerate(contents[:4]):
            db.add(PlaylistItem(playlist_id=pl.id, content_id=c.id, position=i))
        promo = Playlist(name="Promo Akhir Pekan", status="approved",
                         created_by=staff.id)
        db.add(promo)
        db.flush()
        db.add(PlaylistItem(playlist_id=promo.id, content_id=contents[0].id, position=0))
        db.add(PlaylistItem(playlist_id=promo.id, content_id=contents[3].id, position=1))
        db.flush()
        db.add(Assignment(playlist_id=pl.id, group_id=groups["Lobi Gedung A"].id))
        db.add(Assignment(playlist_id=pl.id, group_id=groups["Ruang Tunggu RS"].id))
        now = utcnow()
        sched = Schedule(name="Promo Akhir Pekan", playlist_id=promo.id,
                         group_id=groups["Toko Cabang 1"].id,
                         starts_at=now - timedelta(days=1),
                         ends_at=now + timedelta(days=9),
                         daily_start="08:00", daily_end="21:00",
                         days_of_week=[1, 2, 3, 4, 5, 6, 7], priority=10,
                         created_by=staff.id)
        db.add(sched)
        old_sched = Schedule(name="Apel Pagi Kampus", playlist_id=pl.id,
                             group_id=groups["Lobi Gedung A"].id,
                             starts_at=now - timedelta(days=14),
                             ends_at=now - timedelta(days=7),
                             daily_start="07:00", daily_end="09:00",
                             days_of_week=[1], priority=5, is_active=False,
                             created_by=staff.id)
        db.add(old_sched)
        db.flush()
        random.seed(42)
        scr_list = list(screens.values())
        for d in range(7):
            day = now - timedelta(days=d)
            for _ in range(28):
                s, _tok = random.choice(scr_list[:5])
                c = random.choice(contents)
                st = day.replace(hour=random.randint(8, 20),
                                 minute=random.randint(0, 59), second=0)
                db.add(PlayLog(screen_id=s.id, content_id=c.id,
                               playlist_id=pl.id,
                               started_at=st, ended_at=st + timedelta(seconds=10),
                               played_sec=10,
                               status="completed" if random.random() > 0.03 else "failed"))
        rep = Report(period_start=(now - timedelta(days=14)).date().isoformat(),
                     period_end=(now - timedelta(days=7)).date().isoformat(),
                     payload={"total_plays": 8693, "total_sec": 86930,
                              "completion_pct": 96.4,
                              "top_contents": [{"title": "Promo Akhir Pekan", "plays": 2140}]},
                     emailed_at=now - timedelta(days=7))
        db.add(rep)
        owner = umap["owner@demo.local"]
        teknisi = umap["teknisi@demo.local"]
        db.add(Notification(user_id=owner.id, kind="review_requested",
                            title="Pengajuan baru: Promo Baru",
                            body="Sari Rahma mengajukan review terbit.",
                            link="/dashboard/review.html"))
        db.add(Notification(user_id=teknisi.id, kind="screen_offline",
                            title="Etalase offline 47 menit",
                            body="Tidak ada heartbeat sejak 09:37.",
                            link="/dashboard/monitoring.html"))
        db.add(Notification(user_id=owner.id, kind="report_ready",
                            title="Laporan mingguan siap",
                            body="Rekap pekan lalu sudah terkirim.",
                            link="/dashboard/reports.html"))
        db.commit()
        print("seed: OK", flush=True)
    finally:
        db.close()


if __name__ == "__main__":
    main()
