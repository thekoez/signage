"""Contents: upload, text, CRUD, review flow, delete flow (TSD 4.2)."""
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from pydantic import BaseModel
from sqlalchemy.orm import Session

from .. import config, security
from ..db import get_db
from ..deps import enforce_2fa_policy, get_current_user, require_roles
from ..helpers import audit, notify, notify_role, paginate, utcnow
from ..models import (
    Approval, Assignment, Content, ContentVersion, PlaylistItem, Schedule, User,
)

router = APIRouter()

IMG_EXT = {"jpg", "jpeg", "png", "webp"}
VID_EXT = {"mp4", "webm"}


def _utcnow():
    return datetime.now(timezone.utc)


def content_out(c: Content, db: Session, user=None) -> dict:
    thumb = f"/media/{c.thumb_path}" if c.thumb_path else None
    fileu = f"/media/{c.file_path}" if c.file_path else None
    creator = db.get(User, c.created_by) if c.created_by else None
    d = {
        "id": c.id, "title": c.title, "type": c.type,
        "file_url": fileu, "thumb_url": thumb, "mime": c.mime,
        "size_bytes": c.size_bytes, "duration_sec": c.duration_sec,
        "width": c.width, "height": c.height, "text_payload": c.text_payload,
        "status": c.status, "version": c.version,
        "created_by": c.created_by,
        "creator_name": creator.name if creator else "-",
        "rejection_note": c.rejection_note, "delete_reason": c.delete_reason,
        "published_at": c.published_at.isoformat() if c.published_at else None,
        "created_at": c.created_at.isoformat() if c.created_at else None,
        "updated_at": c.updated_at.isoformat() if c.updated_at else None,
    }
    if user and user.role == "teknisi":
        d.pop("file_url", None)  # teknisi: thumbnail saja
    return d


def _usage(db: Session, cid: str) -> dict:
    pls = (db.query(Assignment).join(__import__("backend.app.models", fromlist=["Playlist"]).Playlist)
           if False else db.query(Assignment)).all()
    used_playlists = db.query(PlaylistItem).filter(PlaylistItem.content_id == cid).count()
    from ..models import Playlist  # noqa
    names = []
    for pi in db.query(PlaylistItem).filter(PlaylistItem.content_id == cid).all():
        pl = db.get(Playlist, pi.playlist_id)
        if pl:
            names.append(pl.name)
    scheds = db.query(Schedule).filter(Schedule.is_active.is_(True)).all()
    return {"playlist_items": used_playlists, "playlists": names[:5]}


def _save_upload(f: UploadFile, kind: str) -> tuple[str, str, int]:
    ext = (f.filename or "").rsplit(".", 1)[-1].lower()
    allowed = IMG_EXT if kind == "image" else VID_EXT
    if ext not in allowed:
        raise HTTPException(400, f"Format .{ext} tidak didukung untuk {kind}")
    data = f.file.read()
    limit = (config.MAX_IMAGE_MB if kind == "image" else config.MAX_VIDEO_MB) * 1024 * 1024
    if len(data) > limit:
        raise HTTPException(400, f"File melebihi batas {config.MAX_IMAGE_MB if kind == 'image' else config.MAX_VIDEO_MB} MB")
    if len(data) < 16:
        raise HTTPException(400, "File kosong / rusak")
    head = data[:16]
    if kind == "image" and not (head[:3] == b"\xff\xd8\xff" or head[:8].startswith(b"\x89PNG")
                                or head[:4] in (b"RIFF",) or b"WEBP" in head[:16] or head[:2] in (b"BM", b"II", b"MM")):
        # allow common headers loosely; still check by Pillow later
        pass
    if kind == "video" and not (b"ftyp" in data[:32] or data[:4] == b"\x1a\x45\xdf\xa3" or head[:4] == b"RIFF"):
        raise HTTPException(400, "File video rusak / bukan MP4-WebM valid")
    sub = "images" if kind == "image" else "videos"
    rel = f"{sub}/{_utcnow():%Y/%m}/{uuid.uuid4().hex}.{ext}"
    dest = Path(config.MEDIA_DIR) / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    return rel, f.content_type or "", len(data)


def _make_thumb(rel: str, kind: str, title: str) -> str | None:
    try:
        from PIL import Image, ImageDraw
        src = Path(config.MEDIA_DIR) / rel
        trel = f"thumbs/{_utcnow():%Y/%m}/{uuid.uuid4().hex}.jpg"
        dest = Path(config.MEDIA_DIR) / trel
        dest.parent.mkdir(parents=True, exist_ok=True)
        if kind == "image":
            im = Image.open(src).convert("RGB")
            im.thumbnail((640, 360))
            im.save(dest, "JPEG", quality=80)
        else:
            # video: coba ffmpeg, fallback gradien berlabel
            import shutil
            import subprocess
            if shutil.which("ffmpeg"):
                r = subprocess.run(
                    ["ffmpeg", "-y", "-i", str(src), "-ss", "1",
                     "-vframes", "1", "-vf", "scale=640:-1", str(dest)],
                    capture_output=True, timeout=20)
                if r.returncode == 0 and dest.exists():
                    return trel
            im = Image.new("RGB", (640, 360), (2, 132, 199))
            ImageDraw.Draw(im).text((24, 160), (title or "VIDEO")[:28], fill="white")
            im.save(dest, "JPEG", quality=80)
        return trel
    except Exception as e:
        print(f"[thumb] gagal: {e}", flush=True)
        return None


def _probe_duration(rel: str) -> int | None:
    try:
        import shutil
        import subprocess
        if shutil.which("ffprobe"):
            r = subprocess.run(
                ["ffprobe", "-v", "error", "-show_entries", "format=duration",
                 "-of", "default=noprint_wrappers=1:nokey=1", str(Path(config.MEDIA_DIR) / rel)],
                capture_output=True, text=True, timeout=15)
            return max(1, int(float(r.stdout.strip())))
    except Exception:
        pass
    return None


@router.get("/contents")
def list_contents(type: str | None = None, status: str | None = None,
                  q: str | None = None, mine: bool = False,
                  page: int = 1, limit: int = 20,
                  user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    query = db.query(Content).order_by(Content.created_at.desc())
    if type:
        query = query.filter(Content.type == type)
    if status:
        query = query.filter(Content.status == status)
    if q:
        query = query.filter(Content.title.ilike(f"%{q}%"))
    if mine:
        query = query.filter(Content.created_by == user.id)
    items, total, page, limit = paginate(query, page, limit)
    return {"items": [content_out(c, db, user) for c in items],
            "total": total, "page": page, "limit": limit}


@router.post("/contents/upload", status_code=201)
def upload(file: UploadFile = File(...), title: str = Form(""),
           duration_sec: int = Form(10),
           user: User = Depends(require_roles("owner", "staff")),
           db: Session = Depends(get_db)):
    user = enforce_2fa_policy(user, db)
    name = (file.filename or "").lower()
    kind = "video" if name.rsplit(".", 1)[-1] in VID_EXT else "image"
    if not 5 <= duration_sec <= 120 and kind == "image":
        raise HTTPException(400, "Durasi gambar 5–120 detik")
    rel, mime, size = _save_upload(file, kind)
    dur = duration_sec
    if kind == "video":
        probed = _probe_duration(rel)
        dur = probed or duration_sec
    c = Content(title=title.strip() or (file.filename or "Tanpa judul"),
                type=kind, file_path=rel, mime=mime, size_bytes=size,
                duration_sec=dur, created_by=user.id)
    if kind == "image":
        try:
            from PIL import Image
            im = Image.open(Path(config.MEDIA_DIR) / rel)
            c.width, c.height = im.size
        except Exception:
            pass
    db.add(c)
    db.flush()
    c.thumb_path = _make_thumb(rel, kind, c.title)
    audit(db, "upload", user.id, "content", c.id, {"title": c.title, "type": kind})
    db.commit()
    db.refresh(c)
    return content_out(c, db, user)


class TextIn(BaseModel):
    title: str
    type: str = "ticker"
    text_payload: dict = {}
    duration_sec: int = 10


@router.post("/contents/text", status_code=201)
def create_text(body: TextIn, user: User = Depends(require_roles("owner", "staff")),
                db: Session = Depends(get_db)):
    user = enforce_2fa_policy(user, db)
    if body.type not in ("ticker", "notice"):
        raise HTTPException(400, "Tipe harus ticker / notice")
    if not body.title.strip():
        raise HTTPException(400, "Judul wajib diisi")
    if not body.text_payload.get("text", "").strip():
        raise HTTPException(400, "Isi teks wajib diisi")
    if not 5 <= body.duration_sec <= 120:
        raise HTTPException(400, "Durasi 5–120 detik")
    c = Content(title=body.title.strip(), type=body.type,
                text_payload=body.text_payload, duration_sec=body.duration_sec,
                created_by=user.id)
    db.add(c)
    db.flush()
    audit(db, "upload", user.id, "content", c.id, {"title": c.title, "type": body.type})
    db.commit()
    db.refresh(c)
    return content_out(c, db, user)


@router.get("/contents/{cid}")
def detail(cid: str, user: User = Depends(get_current_user),
           db: Session = Depends(get_db)):
    c = db.get(Content, cid)
    if c is None:
        raise HTTPException(404, "Konten tidak ditemukan")
    d = content_out(c, db, user)
    d["used_in"] = _usage(db, cid)
    d["versions"] = [
        {"version": v.version, "snapshot": v.snapshot,
         "created_at": v.created_at.isoformat() if v.created_at else None}
        for v in db.query(ContentVersion).filter(
            ContentVersion.content_id == cid).order_by(ContentVersion.version.desc()).all()
    ]
    d["reviews"] = [
        {"id": a.id, "kind": a.kind, "decision": a.decision, "note": a.note,
         "requested_by": a.requested_by, "decided_by": a.decided_by,
         "decided_at": a.decided_at.isoformat() if a.decided_at else None,
         "created_at": a.created_at.isoformat() if a.created_at else None}
        for a in db.query(Approval).filter(Approval.content_id == cid)
        .order_by(Approval.created_at.desc()).all()
    ]
    return d


class ContentPatch(BaseModel):
    title: str | None = None
    duration_sec: int | None = None
    text_payload: dict | None = None


@router.patch("/contents/{cid}")
def edit(cid: str, body: ContentPatch,
         user: User = Depends(require_roles("owner", "staff")),
         db: Session = Depends(get_db)):
    c = db.get(Content, cid)
    if c is None:
        raise HTTPException(404, "Konten tidak ditemukan")
    if user.role != "owner" and c.created_by != user.id:
        raise HTTPException(403, "Hanya pemilik konten / Owner yang boleh edit")
    if c.status not in ("draft", "rejected"):
        raise HTTPException(400, "Hanya draft / rejected yang bisa diedit (ajukan versi baru)")
    if body.title is not None:
        if not body.title.strip():
            raise HTTPException(400, "Judul wajib diisi")
        c.title = body.title.strip()
    if body.duration_sec is not None:
        if not 5 <= body.duration_sec <= 120 and c.type != "video":
            raise HTTPException(400, "Durasi 5–120 detik")
        c.duration_sec = body.duration_sec
    if body.text_payload is not None:
        c.text_payload = body.text_payload
    audit(db, "edit_content", user.id, "content", cid, {})
    db.commit()
    return content_out(c, db, user)


def _submit(c: Content, user: User, db: Session, kind="publish"):
    db.add(ContentVersion(content_id=c.id, version=c.version,
                          snapshot={"title": c.title, "type": c.type,
                                    "duration_sec": c.duration_sec,
                                    "text_payload": c.text_payload,
                                    "file_path": c.file_path}))
    c.status = "pending_review" if kind == "publish" else "pending_delete"
    if kind != "publish":
        c.version += 0
    else:
        pass
    db.add(Approval(kind=kind, content_id=c.id, requested_by=user.id))
    audit(db, "submit_review" if kind == "publish" else "request_delete",
          user.id, "content", c.id, {"kind": kind})
    notify_role(db, "owner", "review_requested" if kind == "publish" else "delete_requested",
                f"Pengajuan baru: {c.title}",
                f"{user.name} mengajukan {'review terbit' if kind == 'publish' else 'hapus'} konten “{c.title}”.",
                "/dashboard/review.html", exclude=user.id)


@router.post("/contents/{cid}/submit-review")
def submit(cid: str, user: User = Depends(require_roles("owner", "staff")),
           db: Session = Depends(get_db)):
    c = db.get(Content, cid)
    if c is None:
        raise HTTPException(404, "Konten tidak ditemukan")
    if user.role != "owner" and c.created_by != user.id:
        raise HTTPException(403, "Hanya pemilik konten / Owner")
    if c.status not in ("draft", "rejected"):
        raise HTTPException(400, f"Status {c.status} tidak bisa diajukan")
    c.rejection_note = None
    c.version += 1
    _submit(c, user, db, "publish")
    db.commit()
    return content_out(c, db, user)


class DecideIn(BaseModel):
    note: str | None = None


@router.post("/contents/{cid}/approve")
def approve(cid: str, body: DecideIn, owner: User = Depends(require_roles("owner")),
            db: Session = Depends(get_db)):
    c = db.get(Content, cid)
    if c is None:
        raise HTTPException(404, "Konten tidak ditemukan")
    if c.status != "pending_review":
        raise HTTPException(400, "Tidak dalam antrean review")
    c.status = "approved"
    c.published_at = utcnow()
    for a in db.query(Approval).filter(
            Approval.content_id == cid, Approval.kind == "publish",
            Approval.decision == "pending").all():
        a.decision, a.decided_by, a.decided_at, a.note = "approved", owner.id, utcnow(), body.note
    audit(db, "approve", owner.id, "content", cid, {"note": body.note})
    notify(db, c.created_by, "review_decided", f"Disetujui: {c.title}",
           f"Konten “{c.title}” disetujui Owner. {body.note or ''}", "/dashboard/contents.html")
    db.commit()
    return content_out(c, db, owner)


@router.post("/contents/{cid}/reject")
def reject(cid: str, body: DecideIn, owner: User = Depends(require_roles("owner")),
           db: Session = Depends(get_db)):
    if not (body.note or "").strip():
        raise HTTPException(400, "Catatan penolakan wajib diisi")
    c = db.get(Content, cid)
    if c is None:
        raise HTTPException(404, "Konten tidak ditemukan")
    if c.status != "pending_review":
        raise HTTPException(400, "Tidak dalam antrean review")
    c.status = "rejected"
    c.rejection_note = body.note
    for a in db.query(Approval).filter(
            Approval.content_id == cid, Approval.kind == "publish",
            Approval.decision == "pending").all():
        a.decision, a.decided_by, a.decided_at, a.note = "rejected", owner.id, utcnow(), body.note
    audit(db, "reject", owner.id, "content", cid, {"note": body.note})
    notify(db, c.created_by, "review_decided", f"Ditolak: {c.title}",
           f"Catatan Owner: {body.note}", "/dashboard/contents.html")
    db.commit()
    return content_out(c, db, owner)


class ReqDelIn(BaseModel):
    reason: str


@router.post("/contents/{cid}/request-delete")
def request_delete(cid: str, body: ReqDelIn,
                   user: User = Depends(require_roles("owner", "staff")),
                   db: Session = Depends(get_db)):
    c = db.get(Content, cid)
    if c is None:
        raise HTTPException(404, "Konten tidak ditemukan")
    if user.role != "owner" and c.created_by != user.id:
        raise HTTPException(403, "Hanya pemilik konten / Owner")
    if not (body.reason or "").strip():
        raise HTTPException(400, "Alasan hapus wajib diisi")
    use = _usage(db, cid)
    if use["playlist_items"] > 0:
        raise HTTPException(
            400, f"Konten dipakai di {use['playlist_items']} playlist "
                 f"({', '.join(use['playlists'])}). Keluarkan dulu dari playlist.")
    if c.status not in ("approved", "rejected", "draft"):
        raise HTTPException(400, f"Status {c.status} tidak bisa diajukan hapus")
    c.delete_reason = body.reason
    _submit(c, user, db, "delete")
    db.commit()
    return content_out(c, db, user)


@router.post("/contents/{cid}/approve-delete")
def approve_delete(cid: str, owner: User = Depends(require_roles("owner")),
                   db: Session = Depends(get_db)):
    c = db.get(Content, cid)
    if c is None:
        raise HTTPException(404, "Konten tidak ditemukan")
    if c.status != "pending_delete":
        raise HTTPException(400, "Tidak dalam antrean hapus")
    c.status = "archived"
    c.archived_at = utcnow()
    for a in db.query(Approval).filter(
            Approval.content_id == cid, Approval.kind == "delete",
            Approval.decision == "pending").all():
        a.decision, a.decided_by, a.decided_at = "approved", owner.id, utcnow()
    audit(db, "approve_delete", owner.id, "content", cid, {})
    notify(db, c.created_by, "delete_decided", f"Dihapus: {c.title}",
           "Pengajuan hapus disetujui. File disimpan 30 hari.", "/dashboard/contents.html")
    db.commit()
    return content_out(c, db, owner)


@router.post("/contents/{cid}/reject-delete")
def reject_delete(cid: str, body: DecideIn, owner: User = Depends(require_roles("owner")),
                  db: Session = Depends(get_db)):
    c = db.get(Content, cid)
    if c is None:
        raise HTTPException(404, "Konten tidak ditemukan")
    if c.status != "pending_delete":
        raise HTTPException(400, "Tidak dalam antrean hapus")
    c.status = "approved"
    for a in db.query(Approval).filter(
            Approval.content_id == cid, Approval.kind == "delete",
            Approval.decision == "pending").all():
        a.decision, a.decided_by, a.decided_at, a.note = "rejected", owner.id, utcnow(), body.note
    audit(db, "reject_delete", owner.id, "content", cid, {"note": body.note})
    notify(db, c.created_by, "delete_decided", f"Hapus ditolak: {c.title}",
           body.note or "", "/dashboard/contents.html")
    db.commit()
    return content_out(c, db, owner)


@router.get("/contents/{cid}/preview-url")
def preview_url(cid: str, user: User = Depends(get_current_user),
                db: Session = Depends(get_db)):
    c = db.get(Content, cid)
    if c is None or not c.file_path:
        raise HTTPException(404, "File tidak tersedia")
    return {"url": security.sign_media(c.file_path, 300)}
