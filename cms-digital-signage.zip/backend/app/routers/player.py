"""Player API: manifest, heartbeat, proof, pair, media (TSD 4.5)."""
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from .. import config, security
from ..db import get_db
from ..deps import get_device
from ..helpers import audit, utcnow
from ..models import (
    Assignment, Content, Heartbeat, PlayLog, Playlist, PlaylistItem,
    Schedule, Screen,
)

router = APIRouter()


def _active_schedule(db: Session, screen: Screen):
    now = utcnow()
    cands = db.query(Schedule).filter(Schedule.is_active.is_(True),
                                      Schedule.starts_at <= now,
                                      Schedule.ends_at >= now).all()
    best = None
    for s in cands:
        match = (s.screen_id and s.screen_id == screen.id) or \
                (s.group_id and s.group_id == screen.group_id)
        if not match:
            continue
        if s.daily_start and s.daily_end:
            hm = now.strftime("%H:%M")
            if not (s.daily_start <= hm <= s.daily_end):
                continue
        if s.days_of_week:
            if now.isoweekday() not in s.days_of_week:
                continue
        if best is None or (s.priority, s.created_at.isoformat() if s.created_at else "") > \
                (best.priority, best.created_at.isoformat() if best.created_at else ""):
            best = s
    return best


def build_manifest(screen: Screen, db: Session) -> dict:
    sched = _active_schedule(db, screen)
    playlist = None
    if sched:
        playlist = db.get(Playlist, sched.playlist_id)
    if playlist is None:
        a = (db.query(Assignment)
             .filter(Assignment.screen_id == screen.id, Assignment.is_default.is_(True)).first())
        if a is None and screen.group_id:
            a = (db.query(Assignment)
                 .filter(Assignment.group_id == screen.group_id,
                         Assignment.is_default.is_(True)).first())
        if a:
            playlist = db.get(Playlist, a.playlist_id)
    items = []
    if playlist:
        rows = (db.query(PlaylistItem).filter(PlaylistItem.playlist_id == playlist.id)
                .order_by(PlaylistItem.position).all())
        for it in rows:
            c = db.get(Content, it.content_id)
            if c is None or c.status != "approved":
                continue
            e: dict = {
                "content_id": c.id, "type": c.type, "title": c.title,
                "duration_sec": it.override_duration_sec or c.duration_sec,
                "text_payload": c.text_payload,
            }
            if c.file_path:
                e["file_url"] = security.sign_media(c.file_path)
            if c.thumb_path:
                e["thumb_url"] = f"/media/{c.thumb_path}"
            items.append(e)
    ticker = next((i for i in items if i["type"] == "ticker"), None)
    return {
        "screen": {"id": screen.id, "name": screen.name,
                   "orientation": screen.orientation},
        "playlist": {"id": playlist.id, "name": playlist.name} if playlist else None,
        "schedule": {"id": sched.id, "name": sched.name} if sched else None,
        "items": items, "ticker": ticker,
        "server_time": utcnow().isoformat(), "refresh_in_sec": 60,
        "pending_commands": screen.pending_commands or [],
    }


@router.get("/player/manifest")
def manifest(screen: Screen = Depends(get_device), db: Session = Depends(get_db)):
    m = build_manifest(screen, db)
    screen.pending_commands = []
    db.commit()
    return m


class HbIn(BaseModel):
    player_version: str | None = None
    now_playing_content_id: str | None = None
    queue_len: int | None = None


@router.post("/player/heartbeat")
def heartbeat(body: HbIn, request: Request,
              screen: Screen = Depends(get_device), db: Session = Depends(get_db)):
    screen.last_heartbeat_at = utcnow()
    screen.last_ip = (request.client.host if request.client else None) or screen.last_ip
    if body.player_version:
        screen.player_version = body.player_version
    if body.now_playing_content_id:
        screen.current_content_id = body.now_playing_content_id
        screen.current_started_at = utcnow()
    db.add(Heartbeat(screen_id=screen.id, ip=screen.last_ip,
                     player_version=body.player_version))
    cmds = list(screen.pending_commands or [])
    screen.pending_commands = []
    db.commit()
    return {"ok": True, "server_time": utcnow().isoformat(),
            "pending_commands": cmds}


class ProofIn(BaseModel):
    content_id: str
    playlist_id: str | None = None
    schedule_id: str | None = None
    started_at: str
    ended_at: str | None = None
    played_sec: int = 0
    status: str | None = None


@router.post("/player/proof", status_code=201)
def proof(body: ProofIn, screen: Screen = Depends(get_device),
          db: Session = Depends(get_db)):
    c = db.get(Content, body.content_id)
    if c is None:
        raise HTTPException(404, "Konten tidak dikenal")
    try:
        st = datetime.fromisoformat(body.started_at.replace("Z", "+00:00"))
    except Exception:
        raise HTTPException(400, "started_at tidak valid")
    en = None
    if body.ended_at:
        try:
            en = datetime.fromisoformat(body.ended_at.replace("Z", "+00:00"))
        except Exception:
            en = None
    status = body.status
    if not status:
        status = "completed" if body.played_sec >= 0.9 * (c.duration_sec or 10) else "skipped"
    # idempotency sederhana: lewati duplikat persis
    dup = db.query(PlayLog).filter(
        PlayLog.screen_id == screen.id, PlayLog.content_id == c.id,
        PlayLog.started_at == st).first()
    if dup:
        return {"ok": True, "duplicate": True, "id": dup.id}
    log = PlayLog(screen_id=screen.id, content_id=c.id,
                  playlist_id=body.playlist_id, schedule_id=body.schedule_id,
                  started_at=st, ended_at=en, played_sec=body.played_sec,
                  status=status)
    db.add(log)
    screen.current_content_id = c.id
    screen.current_started_at = utcnow()
    db.commit()
    return {"ok": True, "id": log.id}


class PairIn(BaseModel):
    pairing_short_code: str | None = None


@router.post("/player/pair")
def pair(body: PairIn, db: Session = Depends(get_db)):
    from ..models import PairingCode

    if body.pairing_short_code:
        p = db.get(PairingCode, body.pairing_short_code.strip())
        if p is None:
            raise HTTPException(400, "Kode tidak dikenal")
        return {"ok": True, "expires_at": p.expires_at.isoformat()}
    return {"ok": True, "hint": "Minta kode pairing ke teknisi via dashboard"}


@router.get("/media/{path:path}")
def media(path: str, exp: str | None = None, sig: str | None = None,
          db: Session = Depends(get_db)):
    # file publik bila tanpa query (nginx cache); validasi bila ada sig
    if exp and sig and not security.check_media_sig(path, exp, sig):
        raise HTTPException(403, "Tautan media kedaluwarsa")
    full = f"{config.MEDIA_DIR}/{path}"
    import os

    if not os.path.isfile(full):
        raise HTTPException(404, "File tidak ditemukan")
    return FileResponse(full)
