"""Playlists, assignments, schedules (TSD 4.3)."""
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from ..db import get_db
from ..deps import get_current_user, require_roles
from ..helpers import audit, paginate, utcnow
from ..models import (
    Approval, Assignment, Content, Playlist, PlaylistItem, Schedule,
    Screen, ScreenGroup, User,
)

router = APIRouter()


def pl_out(pl: Playlist, db: Session) -> dict:
    items = (db.query(PlaylistItem).filter(PlaylistItem.playlist_id == pl.id)
             .order_by(PlaylistItem.position).all())
    det = []
    for it in items:
        c = db.get(Content, it.content_id)
        if c is None:
            continue
        det.append({
            "item_id": it.id, "content_id": c.id, "title": c.title, "type": c.type,
            "status": c.status,
            "thumb_url": f"/media/{c.thumb_path}" if c.thumb_path else None,
            "duration_sec": it.override_duration_sec or c.duration_sec,
            "position": it.position,
        })
    assigns = db.query(Assignment).filter(Assignment.playlist_id == pl.id).all()
    targets = []
    for a in assigns:
        if a.screen_id:
            s = db.get(Screen, a.screen_id)
            targets.append({"screen_id": a.screen_id,
                            "name": s.name if s else "?"})
        if a.group_id:
            g = db.get(ScreenGroup, a.group_id)
            targets.append({"group_id": a.group_id,
                            "name": g.name if g else "?"})
    return {"id": pl.id, "name": pl.name, "description": pl.description,
            "status": pl.status, "transition": pl.transition,
            "rejection_note": pl.rejection_note,
            "items": det, "item_count": len(det), "targets": targets,
            "created_at": pl.created_at.isoformat() if pl.created_at else None}


class PlIn(BaseModel):
    name: str
    description: str | None = None
    transition: str = "fade"


@router.get("/playlists")
def list_pl(q: str | None = None, page: int = 1, limit: int = 20,
            user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    query = db.query(Playlist).order_by(Playlist.created_at.desc())
    if q:
        query = query.filter(Playlist.name.ilike(f"%{q}%"))
    items, total, page, limit = paginate(query, page, limit)
    return {"items": [pl_out(p, db) for p in items], "total": total,
            "page": page, "limit": limit}


@router.post("/playlists", status_code=201)
def create_pl(body: PlIn, user: User = Depends(require_roles("owner", "staff")),
              db: Session = Depends(get_db)):
    if not body.name.strip():
        raise HTTPException(400, "Nama playlist wajib")
    if body.transition not in ("none", "fade", "slide"):
        raise HTTPException(400, "Transisi tidak valid")
    pl = Playlist(name=body.name.strip(), description=body.description,
                  transition=body.transition, created_by=user.id)
    db.add(pl)
    db.flush()
    audit(db, "create_playlist", user.id, "playlist", pl.id, {})
    db.commit()
    db.refresh(pl)
    return pl_out(pl, db)


@router.get("/playlists/{pid}")
def get_pl(pid: str, user: User = Depends(get_current_user),
           db: Session = Depends(get_db)):
    pl = db.get(Playlist, pid)
    if pl is None:
        raise HTTPException(404, "Playlist tidak ditemukan")
    return pl_out(pl, db)


class PlPatch(BaseModel):
    name: str | None = None
    description: str | None = None
    transition: str | None = None


@router.patch("/playlists/{pid}")
def patch_pl(pid: str, body: PlPatch,
             user: User = Depends(require_roles("owner", "staff")),
             db: Session = Depends(get_db)):
    pl = db.get(Playlist, pid)
    if pl is None:
        raise HTTPException(404, "Playlist tidak ditemukan")
    if body.name is not None:
        pl.name = body.name.strip() or pl.name
    if body.description is not None:
        pl.description = body.description
    if body.transition is not None:
        if body.transition not in ("none", "fade", "slide"):
            raise HTTPException(400, "Transisi tidak valid")
        pl.transition = body.transition
    if pl.status == "approved":
        pl.status = "pending_review"  # approval ulang
        db.add(Approval(kind="publish", playlist_id=pl.id, requested_by=user.id))
    audit(db, "edit_playlist", user.id, "playlist", pid, {})
    db.commit()
    return pl_out(pl, db)


@router.delete("/playlists/{pid}")
def del_pl(pid: str, user: User = Depends(require_roles("owner", "staff")),
           db: Session = Depends(get_db)):
    pl = db.get(Playlist, pid)
    if pl is None:
        raise HTTPException(404, "Playlist tidak ditemukan")
    audit(db, "delete_playlist", user.id, "playlist", pid, {})
    db.delete(pl)
    db.commit()
    return {"ok": True}


class ItemIn(BaseModel):
    content_id: str
    position: int | None = None
    override_duration_sec: int | None = None


@router.post("/playlists/{pid}/items", status_code=201)
def add_item(pid: str, body: ItemIn,
             user: User = Depends(require_roles("owner", "staff")),
             db: Session = Depends(get_db)):
    pl = db.get(Playlist, pid)
    if pl is None:
        raise HTTPException(404, "Playlist tidak ditemukan")
    c = db.get(Content, body.content_id)
    if c is None:
        raise HTTPException(404, "Konten tidak ditemukan")
    if c.status != "approved":
        raise HTTPException(400, f"Hanya konten approved (status: {c.status})")
    n = db.query(PlaylistItem).filter(PlaylistItem.playlist_id == pid).count()
    if n >= 100:
        raise HTTPException(400, "Maksimal 100 item per playlist")
    pos = body.position if body.position is not None else n
    # geser posisi >= pos
    for it in db.query(PlaylistItem).filter(
            PlaylistItem.playlist_id == pid, PlaylistItem.position >= pos).all():
        it.position += 1
    it = PlaylistItem(playlist_id=pid, content_id=c.id, position=pos,
                      override_duration_sec=body.override_duration_sec)
    db.add(it)
    if pl.status == "approved":
        pl.status = "pending_review"
    audit(db, "playlist_add_item", user.id, "playlist", pid, {"content": c.id})
    db.commit()
    return pl_out(pl, db)


class ReorderIn(BaseModel):
    ordered_ids: list[str]


@router.patch("/playlists/{pid}/items/reorder")
def reorder(pid: str, body: ReorderIn,
            user: User = Depends(require_roles("owner", "staff")),
            db: Session = Depends(get_db)):
    for i, iid in enumerate(body.ordered_ids):
        it = db.get(PlaylistItem, iid)
        if it is None or it.playlist_id != pid:
            raise HTTPException(400, f"Item {iid} tidak valid")
        it.position = i
    audit(db, "playlist_reorder", user.id, "playlist", pid, {})
    db.commit()
    return pl_out(db.get(Playlist, pid), db)


@router.delete("/playlists/{pid}/items/{iid}")
def del_item(pid: str, iid: str,
             user: User = Depends(require_roles("owner", "staff")),
             db: Session = Depends(get_db)):
    it = db.get(PlaylistItem, iid)
    if it is None or it.playlist_id != pid:
        raise HTTPException(404, "Item tidak ditemukan")
    db.delete(it)
    # rapatkan posisi
    rest = (db.query(PlaylistItem).filter(PlaylistItem.playlist_id == pid)
            .order_by(PlaylistItem.position).all())
    for i, r in enumerate(rest):
        r.position = i
    audit(db, "playlist_del_item", user.id, "playlist", pid, {})
    db.commit()
    return {"ok": True}


@router.post("/playlists/{pid}/submit-review")
def pl_submit(pid: str, user: User = Depends(require_roles("owner", "staff")),
              db: Session = Depends(get_db)):
    pl = db.get(Playlist, pid)
    if pl is None:
        raise HTTPException(404, "Playlist tidak ditemukan")
    # semua item harus approved
    for it in db.query(PlaylistItem).filter(PlaylistItem.playlist_id == pid).all():
        c = db.get(Content, it.content_id)
        if c is None or c.status != "approved":
            raise HTTPException(400, "Masih ada item non-approved di playlist")
    pl.status = "pending_review"
    db.add(Approval(kind="publish", playlist_id=pid, requested_by=user.id))
    audit(db, "submit_review", user.id, "playlist", pid, {})
    db.commit()
    return pl_out(pl, db)


# ---- assignments ----
class AssignIn(BaseModel):
    playlist_id: str
    screen_id: str | None = None
    group_id: str | None = None


@router.post("/assignments", status_code=201)
def assign(body: AssignIn, user: User = Depends(require_roles("owner", "staff")),
           db: Session = Depends(get_db)):
    if not body.screen_id and not body.group_id:
        raise HTTPException(400, "Pilih layar atau grup")
    pl = db.get(Playlist, body.playlist_id)
    if pl is None:
        raise HTTPException(404, "Playlist tidak ditemukan")
    # 1 default per layar: hapus default lama utk target yg sama
    if body.screen_id:
        db.query(Assignment).filter(Assignment.screen_id == body.screen_id,
                                    Assignment.is_default.is_(True)).delete()
    a = Assignment(playlist_id=pl.id, screen_id=body.screen_id,
                   group_id=body.group_id, is_default=True)
    db.add(a)
    audit(db, "assign", user.id, "playlist", pl.id,
          {"screen": body.screen_id, "group": body.group_id})
    db.commit()
    return {"ok": True, "id": a.id}


@router.get("/assignments")
def list_assign(screen_id: str | None = None,
                user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    q = db.query(Assignment)
    if screen_id:
        q = q.filter(Assignment.screen_id == screen_id)
    out = []
    for a in q.all():
        pl = db.get(Playlist, a.playlist_id)
        out.append({"id": a.id, "playlist_id": a.playlist_id,
                    "playlist_name": pl.name if pl else "?",
                    "screen_id": a.screen_id, "group_id": a.group_id,
                    "is_default": a.is_default})
    return {"items": out, "total": len(out)}


# ---- schedules ----
def sched_out(s: Schedule, db: Session) -> dict:
    pl = db.get(Playlist, s.playlist_id)
    tgt = ""
    if s.screen_id:
        sc = db.get(Screen, s.screen_id)
        tgt = sc.name if sc else "?"
    elif s.group_id:
        g = db.get(ScreenGroup, s.group_id)
        tgt = f"Grup {g.name}" if g else "?"
    return {"id": s.id, "name": s.name, "playlist_id": s.playlist_id,
            "playlist_name": pl.name if pl else "?",
            "screen_id": s.screen_id, "group_id": s.group_id, "target": tgt,
            "starts_at": s.starts_at.isoformat() if s.starts_at else None,
            "ends_at": s.ends_at.isoformat() if s.ends_at else None,
            "daily_start": s.daily_start, "daily_end": s.daily_end,
            "days_of_week": s.days_of_week, "priority": s.priority,
            "timezone": s.timezone, "is_active": s.is_active}


class SchedIn(BaseModel):
    name: str
    playlist_id: str
    screen_id: str | None = None
    group_id: str | None = None
    starts_at: str
    ends_at: str
    daily_start: str | None = None
    daily_end: str | None = None
    days_of_week: list[int] | None = None
    priority: int = 0
    is_active: bool = True


def _parse_dt(v: str) -> datetime:
    d = datetime.fromisoformat(v.replace("Z", "+00:00"))
    if d.tzinfo is None:
        d = d.replace(tzinfo=timezone.utc)
    return d


def _conflicts(db: Session, s: Schedule, ignore: str | None = None) -> list[dict]:
    out = []
    q = db.query(Schedule).filter(Schedule.is_active.is_(True))
    if ignore:
        q = q.filter(Schedule.id != ignore)
    for o in q.all():
        same_target = (s.screen_id and o.screen_id == s.screen_id) or \
                      (s.group_id and o.group_id == s.group_id)
        if not same_target:
            continue
        if s.starts_at <= o.ends_at and o.starts_at <= s.ends_at:
            out.append({"id": o.id, "name": o.name, "priority": o.priority})
    return out


@router.get("/schedules")
def list_sched(active_only: bool = False,
               user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    q = db.query(Schedule).order_by(Schedule.priority.desc(), Schedule.starts_at)
    if active_only:
        q = q.filter(Schedule.is_active.is_(True))
    items = q.all()
    return {"items": [sched_out(s, db) for s in items], "total": len(items)}


@router.post("/schedules", status_code=201)
def create_sched(body: SchedIn, user: User = Depends(require_roles("owner", "staff")),
                 db: Session = Depends(get_db)):
    if not body.screen_id and not body.group_id:
        raise HTTPException(400, "Pilih layar atau grup target")
    if db.get(Playlist, body.playlist_id) is None:
        raise HTTPException(404, "Playlist tidak ditemukan")
    st, en = _parse_dt(body.starts_at), _parse_dt(body.ends_at)
    if st >= en:
        raise HTTPException(400, "Tanggal mulai harus sebelum selesai")
    s = Schedule(name=body.name.strip(), playlist_id=body.playlist_id,
                 screen_id=body.screen_id, group_id=body.group_id,
                 starts_at=st, ends_at=en, daily_start=body.daily_start,
                 daily_end=body.daily_end, days_of_week=body.days_of_week,
                 priority=body.priority, is_active=body.is_active,
                 created_by=user.id)
    db.add(s)
    db.flush()
    conf = _conflicts(db, s)
    audit(db, "create_schedule", user.id, "schedule", s.id, {"conflicts": len(conf)})
    db.commit()
    d = sched_out(s, db)
    d["conflicts"] = conf
    return d


class SchedPatch(BaseModel):
    name: str | None = None
    starts_at: str | None = None
    ends_at: str | None = None
    daily_start: str | None = None
    daily_end: str | None = None
    days_of_week: list[int] | None = None
    priority: int | None = None
    is_active: bool | None = None
    playlist_id: str | None = None


@router.patch("/schedules/{sid}")
def patch_sched(sid: str, body: SchedPatch,
                user: User = Depends(require_roles("owner", "staff")),
                db: Session = Depends(get_db)):
    s = db.get(Schedule, sid)
    if s is None:
        raise HTTPException(404, "Jadwal tidak ditemukan")
    for k in ("name", "daily_start", "daily_end", "days_of_week",
              "priority", "is_active", "playlist_id"):
        v = getattr(body, k)
        if v is not None:
            setattr(s, k, v.strip() if isinstance(v, str) and k == "name" else v)
    if body.starts_at:
        s.starts_at = _parse_dt(body.starts_at)
    if body.ends_at:
        s.ends_at = _parse_dt(body.ends_at)
    if s.starts_at >= s.ends_at:
        raise HTTPException(400, "Rentang tanggal tidak valid")
    conf = _conflicts(db, s, ignore=sid)
    audit(db, "edit_schedule", user.id, "schedule", sid, {})
    db.commit()
    d = sched_out(s, db)
    d["conflicts"] = conf
    return d


@router.delete("/schedules/{sid}")
def del_sched(sid: str, user: User = Depends(require_roles("owner", "staff")),
              db: Session = Depends(get_db)):
    s = db.get(Schedule, sid)
    if s is None:
        raise HTTPException(404, "Jadwal tidak ditemukan")
    audit(db, "delete_schedule", user.id, "schedule", sid, {})
    db.delete(s)
    db.commit()
    return {"ok": True}
