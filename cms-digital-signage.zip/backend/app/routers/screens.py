"""Screens, groups, pairing, commands (TSD 4.4)."""
import secrets
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from .. import security
from ..db import get_db
from ..deps import get_current_user, online_of, require_roles
from ..helpers import audit, notify_role, paginate, utcnow
from ..models import (
    Assignment, Content, Heartbeat, PairingCode, Playlist, Schedule,
    Screen, ScreenGroup, User,
)

router = APIRouter()


def screen_out(s: Screen, db: Session) -> dict:
    g = db.get(ScreenGroup, s.group_id) if s.group_id else None
    cc = db.get(Content, s.current_content_id) if s.current_content_id else None
    return {
        "id": s.id, "name": s.name, "group_id": s.group_id,
        "group_name": g.name if g else "-",
        "location_detail": s.location_detail, "orientation": s.orientation,
        "resolution": s.resolution, "is_enabled": s.is_enabled,
        "status": online_of(s),
        "last_heartbeat_at": s.last_heartbeat_at.isoformat() if s.last_heartbeat_at else None,
        "last_ip": s.last_ip, "player_version": s.player_version,
        "now_playing": {"content_id": cc.id, "title": cc.title, "type": cc.type}
        if cc else None,
        "created_at": s.created_at.isoformat() if s.created_at else None,
    }


@router.get("/screens")
def list_screens(status: str | None = None, q: str | None = None,
                 group_id: str | None = None, page: int = 1, limit: int = 20,
                 user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    query = db.query(Screen).order_by(Screen.created_at.desc())
    if q:
        query = query.filter(Screen.name.ilike(f"%{q}%"))
    if group_id:
        query = query.filter(Screen.group_id == group_id)
    items, total, page, limit = paginate(query, page, limit)
    out = [screen_out(s, db) for s in items]
    if status in ("online", "offline", "disabled"):
        out = [o for o in out if o["status"] == status]
    return {"items": out, "total": len(out) if status else total,
            "page": page, "limit": limit}


class ScreenIn(BaseModel):
    name: str
    group_id: str | None = None
    location_detail: str = ""
    orientation: str = "landscape"
    resolution: str = "1920x1080"


@router.post("/screens", status_code=201)
def create_screen(body: ScreenIn,
                  user: User = Depends(require_roles("owner", "teknisi")),
                  db: Session = Depends(get_db)):
    if not body.name.strip():
        raise HTTPException(400, "Nama layar wajib")
    if body.orientation not in ("landscape", "portrait"):
        raise HTTPException(400, "Orientasi tidak valid")
    tok = security.new_device_token()
    s = Screen(name=body.name.strip(), group_id=body.group_id,
               location_detail=body.location_detail, orientation=body.orientation,
               resolution=body.resolution,
               device_token_hash=security.hash_device_token(tok))
    db.add(s)
    db.flush()
    audit(db, "create_screen", user.id, "screen", s.id, {"name": s.name})
    db.commit()
    d = screen_out(s, db)
    d["device_token"] = tok  # tampil sekali
    d["pairing_hint"] = "Tempel token ke /player/?token=... di TV"
    return d


@router.get("/screens/{sid}")
def get_screen(sid: str, user: User = Depends(get_current_user),
               db: Session = Depends(get_db)):
    s = db.get(Screen, sid)
    if s is None:
        raise HTTPException(404, "Layar tidak ditemukan")
    d = screen_out(s, db)
    assigns = db.query(Assignment).filter(Assignment.screen_id == sid).all()
    d["assignments"] = [
        {"id": a.id, "playlist_id": a.playlist_id,
         "playlist_name": (db.get(Playlist, a.playlist_id).name
                           if db.get(Playlist, a.playlist_id) else "?")}
        for a in assigns
    ]
    # antrean 5 berikutnya dari manifest
    from .player import build_manifest

    try:
        m = build_manifest(s, db)
        d["queue_next"] = m["items"][:5]
        d["active_playlist"] = m["playlist"]
        d["active_schedule"] = m.get("schedule")
    except Exception:
        d["queue_next"] = []
    beats = (db.query(Heartbeat).filter(Heartbeat.screen_id == sid)
             .order_by(Heartbeat.at.desc()).limit(48).all())
    d["heartbeats_24h"] = [b.at.isoformat() for b in beats if b.at]
    d["pending_commands"] = s.pending_commands or []
    return d


class ScreenPatch(BaseModel):
    name: str | None = None
    group_id: str | None = None
    location_detail: str | None = None
    orientation: str | None = None
    resolution: str | None = None


@router.patch("/screens/{sid}")
def patch_screen(sid: str, body: ScreenPatch,
                 user: User = Depends(require_roles("owner", "teknisi")),
                 db: Session = Depends(get_db)):
    s = db.get(Screen, sid)
    if s is None:
        raise HTTPException(404, "Layar tidak ditemukan")
    if body.name is not None:
        s.name = body.name.strip() or s.name
    if body.group_id is not None:
        s.group_id = body.group_id or None
    if body.location_detail is not None:
        s.location_detail = body.location_detail
    if body.orientation is not None:
        if body.orientation not in ("landscape", "portrait"):
            raise HTTPException(400, "Orientasi tidak valid")
        s.orientation = body.orientation
    if body.resolution is not None:
        s.resolution = body.resolution
    audit(db, "edit_screen", user.id, "screen", sid, {})
    db.commit()
    return screen_out(s, db)


class PairIn(BaseModel):
    screen_id: str | None = None


@router.post("/screens/pairing-code", status_code=201)
def make_pairing(body: PairIn,
                 user: User = Depends(require_roles("owner", "teknisi")),
                 db: Session = Depends(get_db)):
    code = f"{secrets.randbelow(900000) + 100000}"
    while db.get(PairingCode, code):
        code = f"{secrets.randbelow(900000) + 100000}"
    p = PairingCode(code=code, screen_id=body.screen_id,
                    expires_at=utcnow() + timedelta(minutes=10),
                    created_by=user.id)
    db.add(p)
    audit(db, "pairing_create", user.id, "screen", body.screen_id or code, {})
    db.commit()
    return {"code": code, "expires_at": p.expires_at.isoformat()}


class ClaimIn(BaseModel):
    code: str
    screen_id: str | None = None
    name: str | None = None


@router.post("/screens/claim")
def claim(body: ClaimIn, user: User = Depends(require_roles("owner", "teknisi")),
          db: Session = Depends(get_db)):
    p = db.get(PairingCode, body.code.strip())
    if p is None or p.consumed_at or utcnow() > p.expires_at.replace(
            tzinfo=p.expires_at.tzinfo):
        raise HTTPException(400, "Kode pairing tidak valid / kedaluwarsa")
    exp = p.expires_at
    if exp.tzinfo is None:
        from datetime import timezone
        exp = exp.replace(tzinfo=timezone.utc)
    if utcnow() > exp:
        raise HTTPException(400, "Kode pairing kedaluwarsa")
    target_id = body.screen_id or p.screen_id
    if target_id:
        s = db.get(Screen, target_id)
        if s is None:
            raise HTTPException(404, "Layar tidak ditemukan")
    else:
        tok = security.new_device_token()
        s = Screen(name=body.name or f"Layar baru {body.code}",
                   device_token_hash=security.hash_device_token(tok))
        db.add(s)
        db.flush()
        d_extra = {"device_token": tok}
    p.consumed_at = utcnow()
    audit(db, "pairing_claim", user.id, "screen", s.id, {"code": body.code})
    db.commit()
    d = screen_out(s, db)
    if "d_extra" in dir():
        d.update(d_extra)
    return d


class CmdIn(BaseModel):
    command: str


@router.post("/screens/{sid}/commands")
def command(sid: str, body: CmdIn,
            user: User = Depends(require_roles("owner", "teknisi")),
            db: Session = Depends(get_db)):
    if body.command not in ("reload", "identify", "refresh_manifest"):
        raise HTTPException(400, "Perintah tidak dikenal")
    s = db.get(Screen, sid)
    if s is None:
        raise HTTPException(404, "Layar tidak ditemukan")
    cmds = list(s.pending_commands or [])
    cmds.append({"command": body.command, "at": utcnow().isoformat(),
                 "by": user.id})
    s.pending_commands = cmds
    audit(db, "screen_command", user.id, "screen", sid, {"command": body.command})
    db.commit()
    return {"ok": True, "queued": body.command}


@router.post("/screens/{sid}/regenerate-token")
def regen_token(sid: str, owner: User = Depends(require_roles("owner")),
                db: Session = Depends(get_db)):
    s = db.get(Screen, sid)
    if s is None:
        raise HTTPException(404, "Layar tidak ditemukan")
    tok = security.new_device_token()
    s.device_token_hash = security.hash_device_token(tok)
    audit(db, "regenerate_token", owner.id, "screen", sid, {})
    db.commit()
    return {"device_token": tok}


class EnableIn(BaseModel):
    is_enabled: bool


@router.patch("/screens/{sid}/enable")
def enable(sid: str, body: EnableIn,
           user: User = Depends(require_roles("owner", "teknisi")),
           db: Session = Depends(get_db)):
    s = db.get(Screen, sid)
    if s is None:
        raise HTTPException(404, "Layar tidak ditemukan")
    s.is_enabled = body.is_enabled
    audit(db, "screen_enable", user.id, "screen", sid, {"is_enabled": body.is_enabled})
    db.commit()
    return screen_out(s, db)


# ---- groups ----
@router.get("/screen-groups")
def list_groups(user: User = Depends(get_current_user),
                db: Session = Depends(get_db)):
    groups = db.query(ScreenGroup).order_by(ScreenGroup.name).all()
    out = []
    for g in groups:
        n = db.query(Screen).filter(Screen.group_id == g.id).count()
        out.append({"id": g.id, "name": g.name, "location": g.location,
                    "description": g.description, "screen_count": n})
    return {"items": out, "total": len(out)}


class GroupIn(BaseModel):
    name: str
    location: str = ""
    description: str | None = None


@router.post("/screen-groups", status_code=201)
def create_group(body: GroupIn, owner: User = Depends(require_roles("owner")),
                 db: Session = Depends(get_db)):
    if not body.name.strip():
        raise HTTPException(400, "Nama grup wajib")
    if db.query(ScreenGroup).filter(ScreenGroup.name == body.name.strip()).first():
        raise HTTPException(400, "Nama grup sudah ada")
    g = ScreenGroup(name=body.name.strip(), location=body.location,
                    description=body.description)
    db.add(g)
    audit(db, "create_group", owner.id, "group", g.id, {})
    db.commit()
    db.refresh(g)
    return {"id": g.id, "name": g.name, "location": g.location,
            "description": g.description, "screen_count": 0}


@router.patch("/screen-groups/{gid}")
def patch_group(gid: str, body: GroupIn,
                owner: User = Depends(require_roles("owner")),
                db: Session = Depends(get_db)):
    g = db.get(ScreenGroup, gid)
    if g is None:
        raise HTTPException(404, "Grup tidak ditemukan")
    g.name = body.name.strip() or g.name
    g.location = body.location
    g.description = body.description
    db.commit()
    return {"id": g.id, "name": g.name, "location": g.location}


@router.delete("/screen-groups/{gid}")
def del_group(gid: str, owner: User = Depends(require_roles("owner")),
              db: Session = Depends(get_db)):
    g = db.get(ScreenGroup, gid)
    if g is None:
        raise HTTPException(404, "Grup tidak ditemukan")
    db.query(Screen).filter(Screen.group_id == gid).update({"group_id": None})
    db.delete(g)
    db.commit()
    return {"ok": True}
