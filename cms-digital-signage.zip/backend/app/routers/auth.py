"""Auth + 2FA TOTP + users/invites (TSD 4.1)."""
import hashlib
import secrets
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Response
from pydantic import BaseModel, field_validator

EmailStr = str


def _valid_email(v: str) -> str:
    v = v.strip().lower()
    if "@" not in v or "." not in v.split("@")[-1] and ".local" not in v:
        raise ValueError("Format email tidak valid")
    if "@" not in v:
        raise ValueError("Format email tidak valid")
    return v
from sqlalchemy.orm import Session

from .. import config, security, totp
from ..db import get_db
from ..deps import (
    enforce_2fa_policy, get_current_user, must_have_2fa, require_roles,
)
from ..helpers import audit, notify, notify_role, paginate, utcnow
from ..models import AppSetting, BackupCode, Invite, User

router = APIRouter()

LOGIN_FAILS: dict[str, dict] = {}


def _ip_key(ip: str) -> dict:
    return LOGIN_FAILS.setdefault(ip, {"n": 0, "until": None})


def user_out(u: User, db=None) -> dict:
    d = {
        "id": u.id, "name": u.name, "email": u.email, "role": u.role,
        "is_active": u.is_active, "avatar_url": u.avatar_url,
        "is_2fa_enabled": u.is_2fa_enabled,
        "twofa_enrolled_at": u.twofa_enrolled_at.isoformat() if u.twofa_enrolled_at else None,
    }
    if db is not None:
        d["backup_remaining"] = db.query(BackupCode).filter(
            BackupCode.user_id == u.id, BackupCode.used_at.is_(None)).count()
        try:
            d["required_by_policy"] = must_have_2fa(u, db)
        except Exception:
            d["required_by_policy"] = False
    return d


class LoginIn(BaseModel):
    email: EmailStr
    password: str

    @field_validator("email")
    @classmethod
    def _em(cls, v):
        return _valid_email(v)


@router.post("/auth/login")
def login(body: LoginIn, response: Response, db: Session = Depends(get_db)):
    ip = "global"
    st = _ip_key(ip)
    if st["until"] and utcnow() < st["until"]:
        raise HTTPException(429, "Terlalu banyak percobaan, coba lagi nanti")
    u = db.query(User).filter(User.email == body.email.lower().strip()).first()
    if u is None or not security.verify_pw(body.password, u.password_hash):
        st["n"] += 1
        if st["n"] >= 20:
            st["until"] = utcnow() + timedelta(minutes=15)
        raise HTTPException(401, "Email atau kata sandi salah")
    if not u.is_active:
        raise HTTPException(403, "Akun dinonaktifkan, hubungi Owner")
    st["n"] = 0
    # lockout check for 2fa stage
    if u.twofa_locked_until and utcnow() < _aware(u.twofa_locked_until):
        pass  # password stage still allowed; lock applies at verify
    u.last_login_at = utcnow()
    audit(db, "login", u.id, "user", u.id, {})
    db.commit()
    if u.is_2fa_enabled or must_have_2fa(u, db):
        if u.is_2fa_enabled:
            return {"need_2fa": True, "challenge_token": security.make_challenge(u),
                    "email": u.email}
        return {"need_enroll": True, "access_token": security.make_access(u),
                "refresh_token": security.make_refresh(u), "user": user_out(u, db)}
    _set_refresh(response, u)
    return {"access_token": security.make_access(u),
            "refresh_token": security.make_refresh(u), "user": user_out(u, db)}


def _aware(dt: datetime) -> datetime:
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def _set_refresh(response: Response, u: User):
    response.set_cookie("refresh_token", security.make_refresh(u), httponly=True,
                         samesite="lax", path="/", max_age=30 * 24 * 3600)


class VerifyIn(BaseModel):
    challenge_token: str
    code: str


@router.post("/auth/2fa/verify-login")
def verify_login(body: VerifyIn, response: Response, db: Session = Depends(get_db)):
    try:
        data = security.decode(body.challenge_token)
    except Exception:
        raise HTTPException(401, "Challenge kedaluwarsa, login ulang")
    if data.get("typ") != "challenge":
        raise HTTPException(401, "Challenge tidak valid")
    u = db.get(User, data.get("sub"))
    if u is None or not u.is_active:
        raise HTTPException(401, "Akun tidak valid")
    if u.twofa_locked_until and utcnow() < _aware(u.twofa_locked_until):
        raise HTTPException(429, "Terkunci 15 menit karena 5x kode salah")
    ok = False
    used_backup = False
    if u.totp_secret_enc:
        try:
            ok = totp.verify(totp.dec_secret(u.totp_secret_enc), body.code)
        except Exception:
            ok = False
    if not ok:
        # try backup code atomically (accept with/without dash, any case)
        typed = body.code.strip().upper().replace(" ", "")
        variants = {typed, typed.replace("-", "")}
        if len(typed.replace("-", "")) == 8:
            h = typed.replace("-", "")
            variants.add(h[:4] + "-" + h[4:])
        for bc in db.query(BackupCode).filter(
                BackupCode.user_id == u.id, BackupCode.used_at.is_(None)).all():
            if any(security.verify_pw(v, bc.code_hash) for v in variants):
                bc.used_at = utcnow()
                ok, used_backup = True, True
                break
    if not ok:
        u.twofa_failed_attempts = (u.twofa_failed_attempts or 0) + 1
        audit(db, "2fa_failed", u.id, "user", u.id, {})
        db.commit()
        if u.twofa_failed_attempts >= 5:
            u.twofa_locked_until = utcnow() + timedelta(minutes=15)
            u.twofa_failed_attempts = 0
            db.commit()
            raise HTTPException(429, "5x kode salah — dikunci 15 menit")
        raise HTTPException(401, "Kode 2FA salah")
    u.twofa_failed_attempts = 0
    u.twofa_locked_until = None
    u.last_login_at = utcnow()
    meta = {"via_backup": used_backup}
    audit(db, "2fa_login" if not used_backup else "backup_used", u.id, "user", u.id, meta)
    if used_backup:
        notify(db, u.id, "report_ready", "Kode cadangan dipakai",
               "Satu kode cadangan 2FA Anda baru saja dipakai. Jika bukan Anda, hubungi Owner.",
               "/dashboard/profile.html")
    db.commit()
    _set_refresh(response, u)
    remaining = db.query(BackupCode).filter(
        BackupCode.user_id == u.id, BackupCode.used_at.is_(None)).count()
    return {"access_token": security.make_access(u),
            "refresh_token": security.make_refresh(u),
            "user": user_out(u, db), "backup_remaining": remaining}


class RefreshIn(BaseModel):
    refresh_token: str | None = None


@router.post("/auth/refresh")
def refresh(body: RefreshIn, response: Response, db: Session = Depends(get_db)):
    from fastapi import Request  # local import to avoid cycle
    tok = body.refresh_token
    if not tok:
        # try cookie via raw header parse fallback
        raise HTTPException(401, "Refresh token wajib")
    try:
        data = security.decode(tok)
    except Exception:
        raise HTTPException(401, "Refresh token tidak valid")
    if data.get("typ") != "refresh":
        raise HTTPException(401, "Refresh token tidak valid")
    u = db.get(User, data.get("sub"))
    if u is None or not u.is_active or u.token_version != data.get("tv", -1):
        raise HTTPException(401, "Sesi berakhir")
    return {"access_token": security.make_access(u)}


@router.post("/auth/logout")
def logout(response: Response, user: User = Depends(get_current_user),
           db: Session = Depends(get_db)):
    audit(db, "logout", user.id, "user", user.id, {})
    db.commit()
    response.delete_cookie("refresh_token", path="/")
    return {"ok": True}


class EmailIn(BaseModel):
    email: EmailStr

    @field_validator("email")
    @classmethod
    def _em(cls, v):
        return _valid_email(v)


@router.post("/auth/forgot-password")
def forgot(body: EmailIn, db: Session = Depends(get_db)):
    u = db.query(User).filter(User.email == body.email.lower().strip()).first()
    if u is not None:
        raw = secrets.token_urlsafe(24)
        u.reset_token_hash = hashlib.sha256(raw.encode()).hexdigest()
        u.reset_expires_at = utcnow() + timedelta(hours=2)
        audit(db, "forgot_password", u.id, "user", u.id, {})
        db.commit()
        # In MVP without SMTP, return debug hint in logs only; response stays generic.
        print(f"[mailer] reset link for {u.email}: /reset-password.html?token={raw}", flush=True)
    return {"ok": True}


class ResetIn(BaseModel):
    token: str
    new_password: str


@router.post("/auth/reset-password")
def reset(body: ResetIn, db: Session = Depends(get_db)):
    if len(body.new_password) < 8:
        raise HTTPException(400, "Kata sandi minimal 8 karakter")
    h = hashlib.sha256(body.token.encode()).hexdigest()
    u = db.query(User).filter(User.reset_token_hash == h).first()
    if u is None or u.reset_expires_at is None or utcnow() > _aware(u.reset_expires_at):
        raise HTTPException(400, "Tautan reset tidak valid / kedaluwarsa")
    u.password_hash = security.hash_pw(body.new_password)
    u.token_version += 1
    u.reset_token_hash = None
    u.reset_expires_at = None
    audit(db, "reset_password", u.id, "user", u.id, {})
    db.commit()
    return {"ok": True}


# ---- 2FA setup ----
_pending: dict[str, dict] = {}


@router.post("/auth/2fa/setup")
def setup_2fa(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    secret = totp.new_secret()
    url = totp.otpauth_url(secret, user.email)
    _pending[user.id] = {"enc": totp.enc_secret(secret), "exp": utcnow() + timedelta(minutes=10)}
    return {"otpauth_url": url, "qr_data_url": totp.qr_data_url(url),
            "manual_secret": secret, "expires_in_sec": 600}


class ConfirmIn(BaseModel):
    code: str


@router.post("/auth/2fa/confirm")
def confirm_2fa(body: ConfirmIn, user: User = Depends(get_current_user),
                db: Session = Depends(get_db)):
    p = _pending.get(user.id)
    if p is None or utcnow() > p["exp"]:
        raise HTTPException(400, "Sesi setup kedaluwarsa, ulangi dari awal")
    if not totp.verify(totp.dec_secret(p["enc"]), body.code):
        raise HTTPException(401, "Kode salah, coba lagi")
    user.totp_secret_enc = p["enc"]
    user.is_2fa_enabled = True
    user.twofa_enrolled_at = utcnow()
    # hanguskan batch lama
    db.query(BackupCode).filter(BackupCode.user_id == user.id,
                                BackupCode.used_at.is_(None)).delete()
    codes = totp.new_backup_codes(10)
    for c in codes:
        db.add(BackupCode(user_id=user.id, code_hash=security.hash_pw(c)))
    audit(db, "2fa_enabled", user.id, "user", user.id, {})
    notify(user_id=user.id, db=db, kind="report_ready", title="2FA diaktifkan",
           body="Autentikasi dua faktor aktif di akun Anda. Simpan kode cadangan baik-baik.",
           link="/dashboard/profile.html")
    db.commit()
    _pending.pop(user.id, None)
    return {"ok": True, "backup_codes": codes}


@router.get("/auth/2fa/status")
def status_2fa(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    remaining = db.query(BackupCode).filter(
        BackupCode.user_id == user.id, BackupCode.used_at.is_(None)).count()
    return {"enabled": user.is_2fa_enabled,
            "enrolled_at": user.twofa_enrolled_at.isoformat() if user.twofa_enrolled_at else None,
            "backup_remaining": remaining,
            "required_by_policy": must_have_2fa(user, db)}


class DisableIn(BaseModel):
    password: str
    code: str | None = None


@router.post("/auth/2fa/disable")
def disable_2fa(body: DisableIn, user: User = Depends(get_current_user),
                db: Session = Depends(get_db)):
    if not security.verify_pw(body.password, user.password_hash):
        raise HTTPException(401, "Kata sandi salah")
    if user.is_2fa_enabled:
        if not body.code:
            raise HTTPException(400, "Kode 2FA wajib untuk menonaktifkan")
        ok = False
        try:
            ok = totp.verify(totp.dec_secret(user.totp_secret_enc), body.code)
        except Exception:
            ok = False
        if not ok:
            raise HTTPException(401, "Kode 2FA salah")
    if must_have_2fa(user, db):
        raise HTTPException(403, "2FA wajib untuk akun/organisasi Anda, tidak dapat dinonaktifkan")
    user.is_2fa_enabled = False
    user.totp_secret_enc = None
    db.query(BackupCode).filter(BackupCode.user_id == user.id).delete()
    audit(db, "2fa_disabled", user.id, "user", user.id, {})
    db.commit()
    return {"ok": True}


class RegenIn(BaseModel):
    password: str


@router.post("/auth/2fa/backup-codes/regenerate")
def regen_codes(body: RegenIn, user: User = Depends(get_current_user),
                db: Session = Depends(get_db)):
    if not security.verify_pw(body.password, user.password_hash):
        raise HTTPException(401, "Kata sandi salah")
    if not user.is_2fa_enabled:
        raise HTTPException(400, "2FA belum aktif")
    db.query(BackupCode).filter(BackupCode.user_id == user.id).delete()
    codes = totp.new_backup_codes(10)
    for c in codes:
        db.add(BackupCode(user_id=user.id, code_hash=security.hash_pw(c)))
    audit(db, "backup_regenerated", user.id, "user", user.id, {})
    db.commit()
    return {"backup_codes": codes}


class Reset2FAIn(BaseModel):
    reason: str


@router.post("/users/{uid}/reset-2fa")
def reset_2fa(uid: str, body: Reset2FAIn,
              owner: User = Depends(require_roles("owner")),
              db: Session = Depends(get_db)):
    if not body.reason or len(body.reason.strip()) < 5:
        raise HTTPException(400, "Alasan reset wajib diisi")
    target = db.get(User, uid)
    if target is None:
        raise HTTPException(404, "Pengguna tidak ditemukan")
    target.is_2fa_enabled = False
    target.totp_secret_enc = None
    target.twofa_failed_attempts = 0
    target.twofa_locked_until = None
    db.query(BackupCode).filter(BackupCode.user_id == uid).delete()
    audit(db, "reset_2fa", owner.id, "user", uid, {"reason": body.reason})
    notify(db, uid, "report_ready", "2FA Anda direset oleh Owner",
           f"Alasan: {body.reason}. Silakan login lalu aktifkan ulang 2FA.",
           "/dashboard/profile.html")
    db.commit()
    return {"ok": True}


# ---- profile & users ----
@router.get("/users/me")
def me(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    from ..models import Notification

    unread = db.query(Notification).filter(
        Notification.user_id == user.id, Notification.is_read.is_(False)).count()
    d = user_out(user, db)
    d["unread_notifications"] = unread
    return d


class MePatch(BaseModel):
    name: str | None = None
    avatar_url: str | None = None


@router.patch("/users/me")
def me_patch(body: MePatch, user: User = Depends(get_current_user),
             db: Session = Depends(get_db)):
    if body.name is not None:
        if len(body.name.strip()) < 2:
            raise HTTPException(400, "Nama minimal 2 karakter")
        user.name = body.name.strip()
    if body.avatar_url is not None:
        user.avatar_url = body.avatar_url
    db.commit()
    return user_out(user, db)


class ChangePw(BaseModel):
    old_password: str
    new_password: str


@router.post("/users/change-password")
def change_pw(body: ChangePw, user: User = Depends(get_current_user),
              db: Session = Depends(get_db)):
    if not security.verify_pw(body.old_password, user.password_hash):
        raise HTTPException(401, "Kata sandi lama salah")
    if len(body.new_password) < 8:
        raise HTTPException(400, "Kata sandi baru minimal 8 karakter")
    user.password_hash = security.hash_pw(body.new_password)
    user.token_version += 1
    audit(db, "change_password", user.id, "user", user.id, {})
    db.commit()
    return {"ok": True}


@router.get("/users")
def list_users(role: str | None = None, q: str | None = None, page: int = 1,
               limit: int = 20, owner: User = Depends(require_roles("owner")),
               db: Session = Depends(get_db)):
    query = db.query(User).order_by(User.created_at.desc())
    if role:
        query = query.filter(User.role == role)
    if q:
        query = query.filter((User.name.ilike(f"%{q}%")) | (User.email.ilike(f"%{q}%")))
    items, total, page, limit = paginate(query, page, limit)
    return {"items": [user_out(u, db) for u in items], "total": total,
            "page": page, "limit": limit}


class InviteIn(BaseModel):
    email: EmailStr
    role: str = "staff"

    @field_validator("email")
    @classmethod
    def _em(cls, v):
        return _valid_email(v)


@router.post("/users/invite")
def invite(body: InviteIn, owner: User = Depends(require_roles("owner")),
           db: Session = Depends(get_db)):
    if body.role not in ("owner", "staff", "teknisi"):
        raise HTTPException(400, "Peran tidak valid")
    email = body.email.lower().strip()
    if db.query(User).filter(User.email == email).first():
        raise HTTPException(400, "Email sudah terdaftar")
    raw = secrets.token_urlsafe(24)
    inv = db.get(Invite, email)
    if inv is None:
        inv = Invite(email=email, token_hash="", role=body.role,
                      expires_at=utcnow() + timedelta(hours=72))
        db.add(inv)
    inv.token_hash = hashlib.sha256(raw.encode()).hexdigest()
    inv.role = body.role
    inv.expires_at = utcnow() + timedelta(hours=72)
    inv.accepted_at = None
    audit(db, "invite", owner.id, "user", email, {"role": body.role})
    notify_role(db, "owner", "invite", f"Undangan ke {email}",
                f"{owner.name} mengundang {email} sebagai {body.role}.", "/dashboard/users.html")
    db.commit()
    print(f"[mailer] invite link for {email}: /accept-invite.html?token={raw}", flush=True)
    return {"invite_link": f"/accept-invite.html?token={raw}", "invite_token_debug": raw}


class AcceptIn(BaseModel):
    token: str
    name: str
    password: str


@router.post("/users/accept-invite")
def accept(body: AcceptIn, db: Session = Depends(get_db)):
    if len(body.password) < 8:
        raise HTTPException(400, "Kata sandi minimal 8 karakter")
    h = hashlib.sha256(body.token.encode()).hexdigest()
    inv = db.query(Invite).filter(Invite.token_hash == h).first()
    if inv is None or inv.accepted_at or utcnow() > _aware(inv.expires_at):
        raise HTTPException(400, "Undangan tidak valid / kedaluwarsa")
    u = User(name=body.name.strip(), email=inv.email,
             password_hash=security.hash_pw(body.password), role=inv.role)
    db.add(u)
    inv.accepted_at = utcnow()
    audit(db, "accept_invite", None, "user", inv.email, {"role": inv.role})
    db.commit()
    return {"access_token": security.make_access(u),
            "refresh_token": security.make_refresh(u), "user": user_out(u, db)}


class RoleIn(BaseModel):
    role: str


@router.patch("/users/{uid}/role")
def set_role(uid: str, body: RoleIn, owner: User = Depends(require_roles("owner")),
             db: Session = Depends(get_db)):
    if body.role not in ("owner", "staff", "teknisi"):
        raise HTTPException(400, "Peran tidak valid")
    u = db.get(User, uid)
    if u is None:
        raise HTTPException(404, "Pengguna tidak ditemukan")
    old = u.role
    u.role = body.role
    audit(db, "change_role", owner.id, "user", uid, {"from": old, "to": body.role})
    db.commit()
    return user_out(u, db)


class ActiveIn(BaseModel):
    is_active: bool


@router.patch("/users/{uid}/active")
def set_active(uid: str, body: ActiveIn, owner: User = Depends(require_roles("owner")),
               db: Session = Depends(get_db)):
    u = db.get(User, uid)
    if u is None:
        raise HTTPException(404, "Pengguna tidak ditemukan")
    if u.id == owner.id and not body.is_active:
        raise HTTPException(400, "Tidak dapat menonaktifkan akun sendiri")
    u.is_active = body.is_active
    if not body.is_active:
        u.token_version += 1
    audit(db, "set_active", owner.id, "user", uid, {"is_active": body.is_active})
    db.commit()
    return user_out(u, db)
