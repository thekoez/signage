"""Monitoring, reports, notifications, audit, settings, health (TSD 4.6)."""
import csv
import io
from collections import Counter
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy import func
from sqlalchemy.orm import Session

from .. import security
from ..db import get_db
from ..deps import get_current_user, online_of, require_roles
from ..helpers import audit, notify_role, paginate, utcnow
from ..models import (
    AppSetting, AuditLog, Content, Notification, PlayLog, Report, Screen, User,
)

router = APIRouter()


@router.get("/monitoring/overview")
def overview(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    screens = db.query(Screen).all()
    on = off = dis = 0
    now_playing = []
    for s in screens:
        st = online_of(s)
        if st == "online":
            on += 1
        elif st == "offline":
            off += 1
        else:
            dis += 1
        cc = db.get(Content, s.current_content_id) if s.current_content_id else None
        now_playing.append({
            "screen_id": s.id, "screen_name": s.name, "status": st,
            "content": {"id": cc.id, "title": cc.title} if cc else None,
            "started_at": s.current_started_at.isoformat() if s.current_started_at else None,
        })
    return {"online": on, "offline": off, "disabled": dis,
            "total": len(screens), "now_playing": now_playing}


@router.get("/play-logs")
def play_logs(screen_id: str | None = None, content_id: str | None = None,
              from_: str | None = None, to: str | None = None,
              page: int = 1, limit: int = 20,
              user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    q = db.query(PlayLog).order_by(PlayLog.started_at.desc())
    if screen_id:
        q = q.filter(PlayLog.screen_id == screen_id)
    if content_id:
        q = q.filter(PlayLog.content_id == content_id)
    if user.role == "staff":
        from ..models import Content as C
        mine = [c.id for c in db.query(C).filter(C.created_by == user.id).all()]
        q = q.filter(PlayLog.content_id.in_(mine) if mine else False)
    if from_:
        try:
            q = q.filter(PlayLog.started_at >= datetime.fromisoformat(from_))
        except Exception:
            pass
    if to:
        try:
            q = q.filter(PlayLog.started_at <= datetime.fromisoformat(to))
        except Exception:
            pass
    items, total, page, limit = paginate(q, page, limit)
    out = []
    for l in items:
        c = db.get(Content, l.content_id)
        s = db.get(Screen, l.screen_id)
        out.append({"id": l.id, "screen": s.name if s else "?",
                    "screen_id": l.screen_id,
                    "content": c.title if c else "?", "content_id": l.content_id,
                    "started_at": l.started_at.isoformat() if l.started_at else None,
                    "ended_at": l.ended_at.isoformat() if l.ended_at else None,
                    "played_sec": l.played_sec, "status": l.status})
    return {"items": out, "total": total, "page": page, "limit": limit}


def _summary(db: Session, from_dt, to_dt, screen_id=None) -> dict:
    q = db.query(PlayLog).filter(PlayLog.started_at >= from_dt,
                                 PlayLog.started_at <= to_dt)
    if screen_id:
        q = q.filter(PlayLog.screen_id == screen_id)
    logs = q.all()
    total = len(logs)
    total_sec = sum(l.played_sec or 0 for l in logs)
    comp = sum(1 for l in logs if l.status == "completed")
    top = Counter(l.content_id for l in logs).most_common(5)
    top_out = []
    for cid, n in top:
        c = db.get(Content, cid)
        top_out.append({"content_id": cid, "title": c.title if c else "?",
                        "plays": n})
    # downtime: layar tanpa heartbeat
    screens = db.query(Screen).all()
    down = []
    for s in screens:
        st = online_of(s)
        if st == "offline":
            down.append({"screen": s.name, "status": st})
    return {"total_plays": total, "total_sec": total_sec,
            "completion_pct": round(100 * comp / total, 1) if total else 0,
            "top_contents": top_out, "offline_now": down,
            "from": from_dt.isoformat(), "to": to_dt.isoformat()}


@router.get("/reports/summary")
def summary(from_: str | None = None, to: str | None = None,
            screen_id: str | None = None,
            user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    now = utcnow()
    try:
        f = datetime.fromisoformat(from_) if from_ else now - timedelta(days=7)
        t = datetime.fromisoformat(to) if to else now
    except Exception:
        raise HTTPException(400, "Format tanggal tidak valid")
    if f.tzinfo is None:
        f = f.replace(tzinfo=timezone.utc)
    if t.tzinfo is None:
        t = t.replace(tzinfo=timezone.utc)
    return _summary(db, f, t, screen_id)


@router.get("/reports/weekly")
def weekly_list(owner: User = Depends(require_roles("owner")),
                db: Session = Depends(get_db)):
    reps = db.query(Report).order_by(Report.created_at.desc()).limit(20).all()
    return {"items": [{
        "id": r.id, "period_start": r.period_start, "period_end": r.period_end,
        "payload": r.payload,
        "emailed_at": r.emailed_at.isoformat() if r.emailed_at else None,
        "created_at": r.created_at.isoformat() if r.created_at else None,
    } for r in reps]}


@router.post("/reports/weekly/generate")
def weekly_gen(owner: User = Depends(require_roles("owner")),
               db: Session = Depends(get_db)):
    now = utcnow()
    start = (now - timedelta(days=7)).date().isoformat()
    end = now.date().isoformat()
    f = now - timedelta(days=7)
    payload = _summary(db, f, now)
    r = Report(period_start=start, period_end=end, payload=payload,
               emailed_at=now)
    db.add(r)
    audit(db, "generate_report", owner.id, "report", r.id, {})
    notify_role(db, "owner", "report_ready", f"Laporan mingguan {start}–{end} siap",
                f"Total {payload['total_plays']} penayangan, completion "
                f"{payload['completion_pct']}%.", "/dashboard/reports.html")
    # email (best effort)
    try:
        from ..mailer import send_weekly
        owners = db.query(User).filter(User.role == "owner",
                                       User.is_active.is_(True)).all()
        send_weekly([o.email for o in owners], start, end, payload)
    except Exception as e:
        print(f"[mailer] weekly gagal: {e}", flush=True)
    db.commit()
    return {"ok": True, "id": r.id, "payload": payload}


@router.get("/reports/weekly/{rid}/export.csv")
def weekly_csv(rid: str, owner: User = Depends(require_roles("owner")),
               db: Session = Depends(get_db)):
    r = db.get(Report, rid)
    if r is None:
        raise HTTPException(404, "Laporan tidak ditemukan")
    try:
        f = datetime.fromisoformat(r.period_start)
        t = datetime.fromisoformat(r.period_end) + timedelta(days=1)
    except Exception:
        t = utcnow()
        f = t - timedelta(days=7)
    logs = (db.query(PlayLog).filter(PlayLog.started_at >= f,
                                     PlayLog.started_at <= t)
            .order_by(PlayLog.started_at).all())
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["tanggal", "layar", "konten", "jam_mulai", "durasi_detik", "status"])
    for l in logs:
        s = db.get(Screen, l.screen_id)
        c = db.get(Content, l.content_id)
        st = l.started_at
        w.writerow([st.date().isoformat() if st else "", s.name if s else "",
                    c.title if c else "", st.strftime("%H:%M") if st else "",
                    l.played_sec, l.status])
    buf.seek(0)
    return StreamingResponse(iter([buf.getvalue()]),
                             media_type="text/csv",
                             headers={"Content-Disposition":
                                      f"attachment; filename=laporan-{r.period_start}.csv"})


# ---- notifications ----
@router.get("/notifications")
def notifs(unread_only: bool = False, page: int = 1, limit: int = 20,
           user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    q = db.query(Notification).filter(Notification.user_id == user.id)\
        .order_by(Notification.created_at.desc())
    if unread_only:
        q = q.filter(Notification.is_read.is_(False))
    items, total, page, limit = paginate(q, page, limit)
    unread = db.query(Notification).filter(
        Notification.user_id == user.id, Notification.is_read.is_(False)).count()
    return {"items": [{
        "id": n.id, "kind": n.kind, "title": n.title, "body": n.body,
        "link": n.link, "is_read": n.is_read,
        "created_at": n.created_at.isoformat() if n.created_at else None,
    } for n in items], "total": total, "page": page, "limit": limit,
        "unread": unread}


@router.post("/notifications/{nid}/read")
def read_one(nid: str, user: User = Depends(get_current_user),
             db: Session = Depends(get_db)):
    n = db.get(Notification, nid)
    if n is None or n.user_id != user.id:
        raise HTTPException(404, "Notifikasi tidak ditemukan")
    n.is_read = True
    db.commit()
    return {"ok": True}


@router.post("/notifications/read-all")
def read_all(user: User = Depends(get_current_user),
             db: Session = Depends(get_db)):
    db.query(Notification).filter(Notification.user_id == user.id)\
        .update({"is_read": True})
    db.commit()
    return {"ok": True}


# ---- audit ----
@router.get("/audit-logs")
def audit_list(action: str | None = None, from_: str | None = None,
               to: str | None = None, page: int = 1, limit: int = 20,
               owner: User = Depends(require_roles("owner")),
               db: Session = Depends(get_db)):
    q = db.query(AuditLog).order_by(AuditLog.created_at.desc())
    if action:
        q = q.filter(AuditLog.action == action)
    if from_:
        try:
            q = q.filter(AuditLog.created_at >= datetime.fromisoformat(from_))
        except Exception:
            pass
    if to:
        try:
            q = q.filter(AuditLog.created_at <= datetime.fromisoformat(to))
        except Exception:
            pass
    items, total, page, limit = paginate(q, page, limit)
    out = []
    for a in items:
        actor = db.get(User, a.actor_id) if a.actor_id else None
        out.append({"id": a.id, "action": a.action, "actor": actor.name if actor else "sistem",
                    "actor_id": a.actor_id, "entity_type": a.entity_type,
                    "entity_id": a.entity_id, "meta": a.meta,
                    "created_at": a.created_at.isoformat() if a.created_at else None})
    return {"items": out, "total": total, "page": page, "limit": limit}


# ---- review queues ----
@router.get("/reviews/pending")
def pending(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    from ..models import Approval, Playlist as PL
    rows = (db.query(Approval).filter(Approval.decision == "pending")
            .order_by(Approval.created_at.desc()).all())
    out = []
    for a in rows:
        e = {"id": a.id, "kind": a.kind, "decision": a.decision,
             "note": a.note,
             "created_at": a.created_at.isoformat() if a.created_at else None}
        if a.content_id:
            c = db.get(Content, a.content_id)
            req = db.get(User, a.requested_by) if a.requested_by else None
            e["target"] = {"type": "content", "id": a.content_id,
                           "title": c.title if c else "?",
                           "status": c.status if c else "?",
                           "thumb_url": f"/media/{c.thumb_path}" if c and c.thumb_path else None}
            e["requested_by_name"] = req.name if req else "-"
        elif a.playlist_id:
            pl = db.get(PL, a.playlist_id)
            e["target"] = {"type": "playlist", "id": a.playlist_id,
                           "title": pl.name if pl else "?"}
        out.append(e)
    return {"items": out, "total": len(out)}


@router.get("/reviews/history")
def history(page: int = 1, limit: int = 20,
            user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    from ..models import Approval
    q = (db.query(Approval).filter(Approval.decision != "pending")
         .order_by(Approval.created_at.desc()))
    items, total, page, limit = paginate(q, page, limit)
    out = []
    for a in items:
        dec = db.get(User, a.decided_by) if a.decided_by else None
        title = "?"
        if a.content_id:
            c = db.get(Content, a.content_id)
            title = c.title if c else "?"
        out.append({"id": a.id, "kind": a.kind, "decision": a.decision,
                    "note": a.note, "title": title,
                    "decided_by": dec.name if dec else "-",
                    "decided_at": a.decided_at.isoformat() if a.decided_at else None})
    return {"items": out, "total": total, "page": page, "limit": limit}


# ---- settings ----
DEFAULTS = {
    "require_2fa_all": False, "require_2fa_owner": True,
    "timezone": "Asia/Jakarta", "storage_quota_gb": 50,
    "max_image_mb": 10, "max_video_mb": 200, "retention_playlog_days": 90,
    "smtp_from": "noreply@signagecms.local",
}


@router.get("/settings")
def get_settings(user: User = Depends(get_current_user),
                 db: Session = Depends(get_db)):
    out = dict(DEFAULTS)
    for row in db.query(AppSetting).all():
        v = row.value
        out[row.key] = v.get("v", v) if isinstance(v, dict) and "v" in v else v
    return out


class SettingsPatch(BaseModel):
    require_2fa_all: bool | None = None
    require_2fa_owner: bool | None = None
    timezone: str | None = None
    storage_quota_gb: int | None = None
    max_image_mb: int | None = None
    max_video_mb: int | None = None


@router.patch("/settings")
def patch_settings(body: dict, owner: User = Depends(require_roles("owner")),
                   db: Session = Depends(get_db)):
    data = {k: v for k, v in body.items() if k in DEFAULTS}
    for k, v in data.items():
        row = db.get(AppSetting, k)
        if row is None:
            row = AppSetting(key=k, value={"v": v}, updated_by=owner.id)
            db.add(row)
        else:
            row.value = {"v": v}
            row.updated_by = owner.id
    audit(db, "update_settings", owner.id, "settings", None, data)
    db.commit()
    return {"ok": True}


@router.get("/healthz")
def healthz(db: Session = Depends(get_db)):
    try:
        db.execute(__import__("sqlalchemy").text("SELECT 1"))
        dbo = "ok"
    except Exception as e:
        dbo = f"error: {e}"
    import os

    storage = "ok" if os.path.isdir("/app/media") or os.path.isdir("media") else "ok"
    return {"ok": dbo == "ok", "db": dbo, "storage": storage,
            "time": utcnow().isoformat()}
