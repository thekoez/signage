"""All SQLAlchemy models (TSD section 3). UUIDs stored as str(36)."""
import uuid
from datetime import datetime, timezone

from sqlalchemy import (
    Boolean, Column, DateTime, ForeignKey, Index, Integer,
    String, Text,
)
from sqlalchemy import JSON
from sqlalchemy.orm import relationship

from .db import Base


def _uid():
    return str(uuid.uuid4())


def _now():
    return datetime.now(timezone.utc)


class User(Base):
    __tablename__ = "users"
    id = Column(String(36), primary_key=True, default=_uid)
    name = Column(String(100), nullable=False, default="")
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(20), nullable=False, default="staff")
    is_active = Column(Boolean, default=True)
    token_version = Column(Integer, default=0)
    avatar_url = Column(String(500), nullable=True)
    last_login_at = Column(DateTime(timezone=True), nullable=True)
    totp_secret_enc = Column(Text, nullable=True)
    is_2fa_enabled = Column(Boolean, default=False)
    twofa_enrolled_at = Column(DateTime(timezone=True), nullable=True)
    twofa_failed_attempts = Column(Integer, default=0)
    twofa_locked_until = Column(DateTime(timezone=True), nullable=True)
    reset_token_hash = Column(String(255), nullable=True)
    reset_expires_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=_now)
    updated_at = Column(DateTime(timezone=True), default=_now, onupdate=_now)


class BackupCode(Base):
    __tablename__ = "user_backup_codes"
    id = Column(String(36), primary_key=True, default=_uid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), index=True)
    code_hash = Column(String(255), nullable=False)
    used_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=_now)


class AppSetting(Base):
    __tablename__ = "app_settings"
    key = Column(String(80), primary_key=True)
    value = Column(JSON, nullable=False)
    updated_by = Column(String(36), ForeignKey("users.id"), nullable=True)
    updated_at = Column(DateTime(timezone=True), default=_now, onupdate=_now)


class ScreenGroup(Base):
    __tablename__ = "screen_groups"
    id = Column(String(36), primary_key=True, default=_uid)
    name = Column(String(100), unique=True, nullable=False)
    location = Column(String(200), default="")
    description = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=_now)
    updated_at = Column(DateTime(timezone=True), default=_now, onupdate=_now)


class Screen(Base):
    __tablename__ = "screens"
    id = Column(String(36), primary_key=True, default=_uid)
    name = Column(String(120), nullable=False)
    group_id = Column(String(36), ForeignKey("screen_groups.id", ondelete="SET NULL"), nullable=True, index=True)
    location_detail = Column(String(200), default="")
    orientation = Column(String(20), default="landscape")
    resolution = Column(String(20), default="1920x1080")
    device_token_hash = Column(String(255), unique=True, nullable=False)
    is_enabled = Column(Boolean, default=True)
    last_heartbeat_at = Column(DateTime(timezone=True), nullable=True)
    last_ip = Column(String(64), nullable=True)
    player_version = Column(String(20), nullable=True)
    current_content_id = Column(String(36), ForeignKey("contents.id"), nullable=True)
    current_started_at = Column(DateTime(timezone=True), nullable=True)
    pending_commands = Column(JSON, default=list)
    created_at = Column(DateTime(timezone=True), default=_now)
    updated_at = Column(DateTime(timezone=True), default=_now, onupdate=_now)


class PairingCode(Base):
    __tablename__ = "pairing_codes"
    code = Column(String(6), primary_key=True)
    screen_id = Column(String(36), ForeignKey("screens.id"), nullable=True)
    expires_at = Column(DateTime(timezone=True), nullable=False)
    consumed_at = Column(DateTime(timezone=True), nullable=True)
    created_by = Column(String(36), ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime(timezone=True), default=_now)


class Content(Base):
    __tablename__ = "contents"
    id = Column(String(36), primary_key=True, default=_uid)
    title = Column(String(200), nullable=False)
    type = Column(String(20), nullable=False, default="image")
    file_path = Column(String(500), nullable=True)
    thumb_path = Column(String(500), nullable=True)
    mime = Column(String(100), nullable=True)
    size_bytes = Column(Integer, default=0)
    duration_sec = Column(Integer, default=10)
    width = Column(Integer, nullable=True)
    height = Column(Integer, nullable=True)
    text_payload = Column(JSON, nullable=True)
    status = Column(String(30), default="draft", index=True)
    version = Column(Integer, default=1)
    created_by = Column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    rejection_note = Column(Text, nullable=True)
    published_at = Column(DateTime(timezone=True), nullable=True)
    delete_reason = Column(Text, nullable=True)
    archived_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=_now)
    updated_at = Column(DateTime(timezone=True), default=_now, onupdate=_now)


class ContentVersion(Base):
    __tablename__ = "content_versions"
    id = Column(String(36), primary_key=True, default=_uid)
    content_id = Column(String(36), ForeignKey("contents.id", ondelete="CASCADE"), index=True)
    version = Column(Integer, nullable=False)
    snapshot = Column(JSON, nullable=False)
    created_at = Column(DateTime(timezone=True), default=_now)


class Approval(Base):
    __tablename__ = "approvals"
    id = Column(String(36), primary_key=True, default=_uid)
    kind = Column(String(20), nullable=False, default="publish")
    content_id = Column(String(36), ForeignKey("contents.id", ondelete="CASCADE"), nullable=True)
    playlist_id = Column(String(36), ForeignKey("playlists.id", ondelete="CASCADE"), nullable=True)
    requested_by = Column(String(36), ForeignKey("users.id"), nullable=True)
    decided_by = Column(String(36), ForeignKey("users.id"), nullable=True)
    decision = Column(String(20), default="pending", index=True)
    note = Column(Text, nullable=True)
    decided_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=_now)


class Playlist(Base):
    __tablename__ = "playlists"
    id = Column(String(36), primary_key=True, default=_uid)
    name = Column(String(150), nullable=False)
    description = Column(Text, nullable=True)
    status = Column(String(30), default="draft", index=True)
    created_by = Column(String(36), ForeignKey("users.id"), nullable=True)
    transition = Column(String(20), default="fade")
    rejection_note = Column(Text, nullable=True)
    published_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=_now)
    updated_at = Column(DateTime(timezone=True), default=_now, onupdate=_now)


class PlaylistItem(Base):
    __tablename__ = "playlist_items"
    id = Column(String(36), primary_key=True, default=_uid)
    playlist_id = Column(String(36), ForeignKey("playlists.id", ondelete="CASCADE"), index=True)
    content_id = Column(String(36), ForeignKey("contents.id"), nullable=False)
    position = Column(Integer, nullable=False, default=0)
    override_duration_sec = Column(Integer, nullable=True)


class Assignment(Base):
    __tablename__ = "screen_assignments"
    id = Column(String(36), primary_key=True, default=_uid)
    playlist_id = Column(String(36), ForeignKey("playlists.id", ondelete="CASCADE"))
    screen_id = Column(String(36), ForeignKey("screens.id", ondelete="CASCADE"), nullable=True)
    group_id = Column(String(36), ForeignKey("screen_groups.id", ondelete="CASCADE"), nullable=True)
    is_default = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), default=_now)


class Schedule(Base):
    __tablename__ = "schedules"
    id = Column(String(36), primary_key=True, default=_uid)
    name = Column(String(150), nullable=False)
    playlist_id = Column(String(36), ForeignKey("playlists.id", ondelete="CASCADE"))
    screen_id = Column(String(36), ForeignKey("screens.id", ondelete="CASCADE"), nullable=True)
    group_id = Column(String(36), ForeignKey("screen_groups.id", ondelete="CASCADE"), nullable=True)
    starts_at = Column(DateTime(timezone=True), nullable=False)
    ends_at = Column(DateTime(timezone=True), nullable=False)
    daily_start = Column(String(5), nullable=True)
    daily_end = Column(String(5), nullable=True)
    days_of_week = Column(JSON, nullable=True)
    priority = Column(Integer, default=0)
    timezone = Column(String(50), default="Asia/Jakarta")
    is_active = Column(Boolean, default=True)
    created_by = Column(String(36), ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime(timezone=True), default=_now)
    updated_at = Column(DateTime(timezone=True), default=_now, onupdate=_now)


class PlayLog(Base):
    __tablename__ = "play_logs"
    id = Column(Integer, primary_key=True, autoincrement=True)
    screen_id = Column(String(36), ForeignKey("screens.id"), index=True)
    content_id = Column(String(36), ForeignKey("contents.id"), index=True)
    playlist_id = Column(String(36), ForeignKey("playlists.id"), nullable=True)
    schedule_id = Column(String(36), ForeignKey("schedules.id"), nullable=True)
    started_at = Column(DateTime(timezone=True), nullable=False, index=True)
    ended_at = Column(DateTime(timezone=True), nullable=True)
    played_sec = Column(Integer, default=0)
    status = Column(String(20), default="completed")
    created_at = Column(DateTime(timezone=True), default=_now)


class Heartbeat(Base):
    __tablename__ = "heartbeats"
    id = Column(Integer, primary_key=True, autoincrement=True)
    screen_id = Column(String(36), ForeignKey("screens.id"), index=True)
    at = Column(DateTime(timezone=True), default=_now, index=True)
    ip = Column(String(64), nullable=True)
    player_version = Column(String(20), nullable=True)


class Notification(Base):
    __tablename__ = "notifications"
    id = Column(String(36), primary_key=True, default=_uid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), index=True)
    kind = Column(String(40), default="review_requested")
    title = Column(String(200), nullable=False)
    body = Column(Text, nullable=True)
    link = Column(String(500), nullable=True)
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), default=_now)


class Report(Base):
    __tablename__ = "reports"
    id = Column(String(36), primary_key=True, default=_uid)
    period_start = Column(String(10), nullable=False)
    period_end = Column(String(10), nullable=False)
    payload = Column(JSON, nullable=False, default=dict)
    csv_path = Column(String(500), nullable=True)
    emailed_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=_now)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True, autoincrement=True)
    actor_id = Column(String(36), ForeignKey("users.id"), nullable=True)
    action = Column(String(80), nullable=False, index=True)
    entity_type = Column(String(40), default="")
    entity_id = Column(String(80), nullable=True)
    meta = Column(JSON, default=dict)
    created_at = Column(DateTime(timezone=True), default=_now, index=True)


class Invite(Base):
    __tablename__ = "invites"
    email = Column(String(255), primary_key=True)
    token_hash = Column(String(255), unique=True, nullable=False)
    role = Column(String(20), default="staff")
    expires_at = Column(DateTime(timezone=True), nullable=False)
    accepted_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=_now)
