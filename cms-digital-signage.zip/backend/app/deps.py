"""Auth dependencies: current user, roles, device, 2FA policy."""
from datetime import datetime, timezone

from fastapi import Depends, Header, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from . import config, security
from .db import get_db
from .models import AppSetting, Screen

_bearer = HTTPBearer(auto_error=False)


def _setting(db: Session, key: str, default):
    row = db.get(AppSetting, key)
    if row is None:
        return default
    v = row.value
    if isinstance(v, dict):
        if key in v:
            return v[key]
        if "v" in v:
            return v["v"]
    return v


def require_2fa_all(db: Session) -> bool:
    return bool(_setting(db, "require_2fa_all", config.REQUIRE_2FA_ALL))


def must_have_2fa(user, db: Session) -> bool:
    if require_2fa_all(db):
        return True
    if config.REQUIRE_2FA_OWNER and user.role == "owner":
        return True
    row = db.get(AppSetting, "require_2fa_owner")
    if row is not None:
        try:
            v = row.value
            if isinstance(v, dict):
                flag = v.get("require_2fa_owner", v.get("v", config.REQUIRE_2FA_OWNER))
            else:
                flag = bool(v)
            if flag and user.role == "owner":
                return True
        except Exception:
            pass
    return False


def get_current_user(
    creds: HTTPAuthorizationCredentials | None = Depends(_bearer),
    db: Session = Depends(get_db),
):
    from .models import User

    if creds is None:
        raise HTTPException(401, "Belum login / Unauthorized")
    try:
        data = security.decode(creds.credentials)
    except Exception:
        raise HTTPException(401, "Token tidak valid")
    if data.get("typ") != "access":
        raise HTTPException(401, "Token tidak valid untuk API ini")
    user = db.get(User, data.get("sub"))
    if user is None or not user.is_active:
        raise HTTPException(401, "Akun nonaktif")
    if user.token_version != data.get("tv", -1):
        raise HTTPException(401, "Sesi kedaluwarsa, silakan login ulang")
    return user


def enforce_2fa_policy(user=Depends(get_current_user), db: Session = Depends(get_db)):
    if must_have_2fa(user, db) and not user.is_2fa_enabled:
        raise HTTPException(403, "Wajib aktifkan 2FA terlebih dahulu")
    return user


def require_roles(*roles):
    def _check(user=Depends(get_current_user)):
        if user.role not in roles:
            raise HTTPException(403, "Akses ditolak untuk peran Anda")
        return user

    return _check


def get_device(
    token: str | None = Header(default=None, alias="X-Device-Token"),
    db: Session = Depends(get_db),
):
    if not token:
        raise HTTPException(401, "Device token wajib")
    from .models import Screen

    h = security.hash_device_token(token)
    scr = db.query(Screen).filter(Screen.device_token_hash == h).first()
    if scr is None or not scr.is_enabled:
        raise HTTPException(401, "Device token tidak valid / layar dinonaktifkan")
    return scr


def online_of(scr, now=None) -> str:
    if not scr.is_enabled:
        return "disabled"
    if scr.last_heartbeat_at is None:
        return "offline"
    last = scr.last_heartbeat_at
    if last.tzinfo is None:
        last = last.replace(tzinfo=timezone.utc)
    now = now or datetime.now(timezone.utc)
    return "online" if (now - last).total_seconds() <= config.OFFLINE_SEC else "offline"
