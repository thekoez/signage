"""2FA TOTP helpers: secret, otpauth URL, QR, verify, Fernet encrypt, backup codes."""
import base64
import hashlib
import io
import secrets

import pyotp
import qrcode

from . import config

try:
    from cryptography.fernet import Fernet, InvalidToken

    def _fernet() -> Fernet:
        raw = config.FERNET_KEY_RAW
        key = raw.encode()
        # accept raw 32-byte urlsafe key or derive one deterministically
        try:
            base64.urlsafe_b64decode(key)
            if len(base64.urlsafe_b64decode(key)) == 32:
                return Fernet(key if len(key) == 44 else base64.urlsafe_b64encode(hashlib.sha256(key).digest()))
        except Exception:
            pass
        return Fernet(base64.urlsafe_b64encode(hashlib.sha256(key).digest()))
except Exception:  # pragma: no cover
    _fernet = None  # type: ignore


def enc_secret(plain: str) -> str:
    if _fernet is None:
        return "v0:" + plain
    return "v1:" + _fernet().encrypt(plain.encode()).decode()


def dec_secret(stored: str) -> str:
    if stored.startswith("v1:") and _fernet is not None:
        return _fernet().decrypt(stored[3:].encode()).decode()
    if stored.startswith("v0:"):
        return stored[3:]
    return stored  # legacy plaintext


def new_secret() -> str:
    return pyotp.random_base32()


def otpauth_url(secret: str, email: str) -> str:
    return pyotp.totp.TOTP(secret).provisioning_uri(
        name=email, issuer_name=config.TOTP_ISSUER
    )


def qr_data_url(otpauth: str) -> str:
    img = qrcode.make(otpauth)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


def verify(secret: str, code: str) -> bool:
    code = (code or "").replace(" ", "").replace("-", "").strip()
    if not code.isdigit() or len(code) != 6:
        return False
    try:
        return pyotp.TOTP(secret).verify(code, valid_window=config.TOTP_WINDOW)
    except Exception:
        return False


def new_backup_codes(n: int = 10) -> list[str]:
    codes = []
    for _ in range(n):
        codes.append(
            secrets.token_hex(2).upper() + "-" + secrets.token_hex(2).upper()
        )
    return codes
