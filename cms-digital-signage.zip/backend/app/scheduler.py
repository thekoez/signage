"""APScheduler: laporan mingguan Minggu 18:00 WIB + purge harian."""
import logging
import sys
from datetime import timedelta

logging.basicConfig(level=logging.INFO, stream=sys.stdout)
log = logging.getLogger("scheduler")


def weekly_job():
    try:
        from .db import SessionLocal
        from .helpers import notify_role, utcnow
        from .models import Report, User
        from .routers.misc import _summary

        db = SessionLocal()
        try:
            now = utcnow()
            payload = _summary(db, now - timedelta(days=7), now)
            r = Report(period_start=(now - timedelta(days=7)).date().isoformat(),
                       period_end=now.date().isoformat(), payload=payload,
                       emailed_at=now)
            db.add(r)
            notify_role(db, "owner", "report_ready",
                        f"Laporan mingguan {r.period_start}–{r.period_end} siap",
                        f"Total {payload['total_plays']} penayangan.",
                        "/dashboard/reports.html")
            try:
                from .mailer import send_weekly
                owners = db.query(User).filter(
                    User.role == "owner", User.is_active.is_(True)).all()
                send_weekly([o.email for o in owners], r.period_start,
                            r.period_end, payload)
            except Exception as e:
                print(f"[scheduler] email gagal: {e}", flush=True)
            db.commit()
            log.info("weekly report generated")
        finally:
            db.close()
    except Exception as e:
        log.exception(f"weekly_job gagal: {e}")


def purge_job():
    try:
        from .db import SessionLocal
        from .helpers import utcnow
        from .models import AuditLog, Heartbeat, PlayLog

        db = SessionLocal()
        try:
            now = utcnow()
            db.query(Heartbeat).filter(
                Heartbeat.at < now - timedelta(days=14)).delete()
            db.query(PlayLog).filter(
                PlayLog.started_at < now - timedelta(days=90)).delete()
            db.query(AuditLog).filter(
                AuditLog.created_at < now - timedelta(days=180)).delete()
            db.commit()
            log.info("purge selesai")
        finally:
            db.close()
    except Exception as e:
        log.exception(f"purge_job gagal: {e}")


def start():
    from apscheduler.schedulers.background import BackgroundScheduler

    sch = BackgroundScheduler(timezone="Asia/Jakarta")
    sch.add_job(weekly_job, "cron", day_of_week="sun", hour=18, minute=0,
                id="weekly")
    sch.add_job(purge_job, "cron", hour=3, minute=0, id="purge")
    sch.start()
    log.info("scheduler aktif (weekly Min 18:00 WIB)")
    return sch
