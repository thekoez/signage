"""Email best-effort via SMTP env. Tanpa SMTP: log ke stdout."""
import smtplib
from email.mime.text import MIMEText

from . import config


def _send(to: list[str], subject: str, html: str):
    if not config.SMTP_HOST:
        print(f"[mailer:mock] to={to} subject={subject}", flush=True)
        return False
    msg = MIMEText(html, "html")
    msg["Subject"] = subject
    msg["From"] = config.SMTP_FROM
    msg["To"] = ", ".join(to)
    with smtplib.SMTP(config.SMTP_HOST, config.SMTP_PORT, timeout=15) as s:
        s.starttls()
        if config.SMTP_USER:
            s.login(config.SMTP_USER, config.SMTP_PASS)
        s.sendmail(config.SMTP_FROM, to, msg.as_string())
    return True


def send_weekly(to: list[str], start: str, end: str, payload: dict):
    top = "".join(
        f"<li>{t.get('title')}: {t.get('plays')}x</li>"
        for t in payload.get("top_contents", [])[:5]
    )
    html = (f"<h2>Laporan Mingguan SignageCMS {start} – {end}</h2>"
            f"<p>Total penayangan: <b>{payload.get('total_plays')}</b>, "
            f"completion: <b>{payload.get('completion_pct')}%</b></p>"
            f"<ol>{top}</ol>"
            f"<p><a href='/dashboard/reports.html'>Buka dashboard</a></p>")
    return _send(to, f"Laporan Mingguan {start}–{end}", html)
