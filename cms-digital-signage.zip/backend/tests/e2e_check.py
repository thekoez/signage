"""E2E contract check (stdlib only). Run: python tests/e2e_check.py [base_url]."""
import json
import sys
import urllib.request

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8000"
N = [0]


def call(method, path, body=None, token=None, device=None):
    req = urllib.request.Request(BASE + path, method=method)
    if token:
        req.add_header("Authorization", "Bearer " + token)
    if device:
        req.add_header("X-Device-Token", device)
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=20) as r:
            return r.status, json.loads(r.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode() or "{}")
        except Exception:
            return e.code, {}


def check(name, cond, extra=""):
    N[0] += 1
    print(("PASS " if cond else "FAIL ") + name, extra)
    if not cond:
        check.failed = True


check.failed = False

# --- auth ---
s, r = call("POST", "/api/auth/login", {"email": "owner@demo.local", "password": "Signage123!"})
OWNER_RESET = r.get("access_token")
# isolasi: kembalikan kebijakan default agar run idempoten
call("PATCH", "/api/settings",
     {"require_2fa_all": False, "require_2fa_owner": True}, token=OWNER_RESET)
s, r = call("POST", "/api/auth/login", {"email": "marketing@demo.local", "password": "Signage123!"})
if "access_token" not in r:  # sisa state 2FA run lama → reset paksa
    s, ul = call("GET", "/api/users?q=marketing", token=OWNER_RESET)
    mid = ul["items"][0]["id"]
    call("POST", f"/api/users/{mid}/reset-2fa", {"reason": "reset uji e2e"}, token=OWNER_RESET)
    s, r = call("POST", "/api/auth/login", {"email": "marketing@demo.local", "password": "Signage123!"})
check("staff login", s == 200 and "access_token" in r, str(s))
STAFF = r.get("access_token")
s, r = call("POST", "/api/auth/login", {"email": "teknisi@demo.local", "password": "Signage123!"})
TEK = r.get("access_token")
s, r = call("POST", "/api/auth/login", {"email": "owner@demo.local", "password": "Signage123!"})
OWNER = r.get("access_token")
check("owner login (need_enroll ok)", s == 200 and "access_token" in r)
s, _ = call("POST", "/api/auth/login", {"email": "owner@demo.local", "password": "salah123"})
check("wrong pw 401", s == 401)
s, _ = call("GET", "/api/contents")
check("unauth 401", s == 401)
s, _ = call("GET", "/api/users", token=STAFF)
check("staff blocked from users 403", s == 403)
s, _ = call("GET", "/api/audit-logs", token=STAFF)
check("staff blocked from audit 403", s == 403)
H_O, H_S, H_T = {"": ""}, None, None
HO = OWNER
HS = STAFF
HT = TEK

# --- contents (staff) ---
s, c = call("POST", "/api/contents/text", {"title": "Uji Ticker E2E", "type": "ticker",
    "text_payload": {"text": "halo dunia", "bg_color": "#111"}, "duration_sec": 12}, token=HS)
check("create text content", s == 201, str(s))
CID = c.get("id")
s, r = call("GET", f"/api/contents/{CID}", token=HS)
check("detail + used_in", s == 200 and "used_in" in r)
s, _ = call("POST", f"/api/contents/{CID}/submit-review", {}, token=HS)
check("submit review", s == 200)
s, _ = call("GET", "/api/reviews/pending", token=HO)
check("owner sees pending", s == 200 and r.get("total", 0) >= 0 or s == 200)
# teknisi cannot submit
s, _ = call("POST", f"/api/contents/{CID}/approve", {}, token=HT)
check("teknisi approve 403", s == 403)
s, _ = call("POST", f"/api/contents/{CID}/approve", {"note": "ok"}, token=HO)
check("owner approve", s == 200 and _.get("status") == "approved")

# --- playlist + assign + schedule ---
s, p = call("POST", "/api/playlists", {"name": "E2E Loop"}, token=HS)
check("create playlist", s == 201, str(s))
PID = p.get("id")
s, _ = call("POST", f"/api/playlists/{PID}/items", {"content_id": CID}, token=HS)
check("add approved item", s == 201, str(s))
s, _ = call("POST", f"/api/playlists/{PID}/items", {"content_id": "00000000-0000-0000-0000-000000000000"}, token=HS)
check("add missing content 404", s == 404)
s, sc = call("GET", "/api/screens?limit=1", token=HO)
SID = sc["items"][0]["id"]
s, _ = call("POST", "/api/assignments", {"playlist_id": PID, "screen_id": SID}, token=HS)
check("assign default", s == 201, str(s))
s, _ = call("POST", "/api/schedules", {"name": "E2E Promo", "playlist_id": PID,
    "screen_id": SID, "starts_at": "2026-10-01T00:00:00+07:00",
    "ends_at": "2026-10-30T00:00:00+07:00", "priority": 5}, token=HS)
check("create schedule", s == 201, str(s))

# --- delete flow ---
s, _ = call("POST", f"/api/contents/{CID}/request-delete", {"reason": "e2e"}, token=HS)
check("request-delete blocked (in playlist)", s == 400, str(s)[:80])
s, c2 = call("POST", "/api/contents/text", {"title": "Hapus Saya", "type": "notice",
    "text_payload": {"text": "x"}, "duration_sec": 10}, token=HS)
DID = c2.get("id")
call("POST", f"/api/contents/{DID}/submit-review", {}, token=HS)
call("POST", f"/api/contents/{DID}/approve", {}, token=HO)
s, _ = call("POST", f"/api/contents/{DID}/request-delete", {"reason": "usang"}, token=HS)
check("request-delete ok", s == 200, str(s))
s, _ = call("POST", f"/api/contents/{DID}/approve-delete", {}, token=HO)
check("approve-delete archived", s == 200 and _.get("status") == "archived")

# --- screens/pairing (teknisi) ---
s, ns = call("POST", "/api/screens", {"name": "E2E TV 99"}, token=HT)
check("teknisi create screen + token", s == 201 and "device_token" in ns, str(s))
DEV = ns.get("device_token")
NSID = ns.get("id")
s, pc = call("POST", "/api/screens/pairing-code", {}, token=HT)
check("pairing code", s == 201 and len(pc.get("code", "")) == 6)
s, _ = call("POST", f"/api/screens/{NSID}/commands", {"command": "identify"}, token=HT)
check("remote command", s == 200)
s, _ = call("POST", "/api/screens", {"name": "Nope"}, token=HS)
check("staff create screen 403", s == 403)

# --- player (device) ---
s, m = call("GET", "/api/player/manifest", device=DEV)
check("manifest ok", s == 200 and "items" in m, str(s))
bad = [i for i in m.get("items", []) if i.get("content_id") == DID]
check("archived never in manifest", not bad)
s, _ = call("POST", "/api/player/heartbeat", {"now_playing_content_id": CID}, device=DEV)
check("heartbeat", s == 200)
import datetime
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
s, _ = call("POST", "/api/player/proof", {"content_id": CID, "started_at": now,
    "ended_at": now, "played_sec": 10}, device=DEV)
check("proof", s == 201, str(s))
s, _ = call("GET", "/api/player/manifest", device="scr_salah")
check("bad device 401", s == 401)

# --- monitoring/reports/notif/audit ---
s, ov = call("GET", "/api/monitoring/overview", token=HT)
check("overview", s == 200 and "online" in ov)
s, _ = call("GET", "/api/play-logs?page=1&limit=5", token=HO)
check("play-logs", s == 200)
s, _ = call("GET", "/api/reports/summary", token=HO)
check("summary", s == 200 and "total_plays" in _)
s, _ = call("POST", "/api/reports/weekly/generate", {}, token=HO)
check("weekly generate", s == 200)
s, _ = call("GET", "/api/notifications", token=HO)
check("notifications", s == 200 and "unread" in _)
if _.get("items"):
    s, _ = call("POST", f"/api/notifications/{_['items'][0]['id']}/read", {}, token=HO)
    check("mark read", s == 200)
s, _ = call("GET", "/api/audit-logs?limit=5", token=HO)
check("audit", s == 200 and _["total"] > 0)
s, _ = call("GET", "/api/settings", token=HO)
check("settings get", s == 200)
s, _ = call("PATCH", "/api/settings", {"timezone": "Asia/Jakarta"}, token=HO)
check("settings patch", s == 200)
s, _ = call("PATCH", "/api/settings", {"timezone": "X"}, token=HT)
check("teknisi settings 403", s == 403)

# --- 2FA ---
s, st = call("POST", "/api/auth/2fa/setup", {}, token=HS)
check("2fa setup", s == 200 and "otpauth_url" in st)
import re
sec = re.search(r"secret=([A-Z2-7]+)", st["otpauth_url"]).group(1)
import pyotp  # tersedia di image backend
code = pyotp.TOTP(sec).now()
s, cf = call("POST", "/api/auth/2fa/confirm", {"code": code}, token=HS)
check("2fa confirm → backup codes", s == 200 and len(cf.get("backup_codes", [])) == 10, str(s))
BC = cf["backup_codes"][0]
s, st2 = call("GET", "/api/auth/2fa/status", token=HS)
check("2fa status enabled", s == 200 and st2.get("enabled") is True)
s, lg = call("POST", "/api/auth/login", {"email": "marketing@demo.local", "password": "Signage123!"})
check("2fa login need_2fa", s == 200 and lg.get("need_2fa") is True)
CH = lg.get("challenge_token")
s, _ = call("POST", "/api/auth/2fa/verify-login", {"challenge_token": CH, "code": "000000"})
check("wrong totp rejected", s == 401, str(s))
code2 = pyotp.TOTP(sec).now()
s, vf = call("POST", "/api/auth/2fa/verify-login", {"challenge_token": CH, "code": code2})
check("totp verify ok", s == 200 and "access_token" in vf, str(s))
# backup code sekali pakai
s, lg2 = call("POST", "/api/auth/login", {"email": "marketing@demo.local", "password": "Signage123!"})
s, vb = call("POST", "/api/auth/2fa/verify-login",
             {"challenge_token": lg2.get("challenge_token"), "code": BC})
check("backup code ok", s == 200, str(s))
s, lg3 = call("POST", "/api/auth/login", {"email": "marketing@demo.local", "password": "Signage123!"})
s, _ = call("POST", "/api/auth/2fa/verify-login",
            {"challenge_token": lg3.get("challenge_token"), "code": BC})
check("backup code reuse rejected", s == 401, str(s))
# lockout: 5x salah (gunakan akun staff lain agar tidak mengunci akun uji utama)
import time as _t
lock_email = f"lock{_t.time_ns() % 1000000}@demo.local"
s, rg = call("POST", "/api/users/invite", {"email": lock_email, "role": "staff"}, token=HO)
tok_raw = rg.get("invite_token_debug")
s, _ = call("POST", "/api/users/accept-invite",
            {"token": tok_raw, "name": "Lock", "password": "Signage123!"})
LOCKT = _["access_token"]
s, stp = call("POST", "/api/auth/2fa/setup", {}, token=LOCKT)
lsec = re.search(r"secret=([A-Z2-7]+)", stp["otpauth_url"]).group(1)
call("POST", "/api/auth/2fa/confirm", {"code": pyotp.TOTP(lsec).now()}, token=LOCKT)
s, ll = call("POST", "/api/auth/login", {"email": lock_email, "password": "Signage123!"})
LCH = ll.get("challenge_token")
codes = ["111111", "222222", "333333", "444444", "555555"]
last = 0
for cd in codes:
    last, _ = call("POST", "/api/auth/2fa/verify-login",
                   {"challenge_token": LCH, "code": cd})
check("lockout after 5x (429)", last == 429, str(last))
# reset 2FA oleh owner
s, _ = call("POST", f"/api/users/{cf.get('user', {}).get('id') or ''}/reset-2fa",
            {"reason": "x"}, token=HO)
# (gunakan id dari /users/me staff)
s, me2 = call("GET", "/api/users/me", token=HS)
s, _ = call("POST", f"/api/users/{me2['id']}/reset-2fa",
            {"reason": "HP hilang, identitas terverifikasi"}, token=HO)
check("owner reset 2fa", s == 200, str(s))
s, st3 = call("GET", "/api/auth/2fa/status", token=HS)
check("2fa disabled after reset", s == 200 and st3.get("enabled") is False)
# invite + role + policy
s, _ = call("PATCH", "/api/settings", {"require_2fa_all": True}, token=HO)
check("enable require_2fa_all", s == 200)

print(f"\n{N[0]} checks, {'FAILED' if check.failed else 'ALL PASS'}")
sys.exit(1 if check.failed else 0)
