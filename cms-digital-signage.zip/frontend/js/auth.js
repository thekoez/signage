/* Auth guard + session. Dipakai semua halaman dashboard. */
const Auth = {
  user: null,
  async init(required = true) {
    if (!Api.token) {
      if (required) location.href = "/login.html?next=" + encodeURIComponent(location.pathname);
      return null;
    }
    try {
      this.user = await Api.get("/api/users/me");
      return this.user;
    } catch (e) {
      Api.token = "";
      if (required) location.href = "/login.html";
      return null;
    }
  },
  logout(silent) {
    Api.post("/api/auth/logout", {}).catch(() => {});
    Api.token = "";
    localStorage.removeItem("sc_refresh");
    if (!silent) location.href = "/login.html";
    else location.href = "/login.html";
  },
  needEnroll() {
    return this.user && this.user.required_by_policy && !this.user.is_2fa_enabled;
  },
};
