/* i18n: Indonesia (default) + English. Persist di localStorage. */
const I18N = {
  id: {
    app_sub: "CMS PAPAN INFORMASI DIGITAL",
    home: "Beranda", monitoring: "Monitoring", notifications: "Notifikasi",
    sec_main: "UTAMA", sec_manage: "KELOLA TAYANG", sec_moderation: "MODERASI PEMILIK",
    sec_reports: "LAPORAN", sec_admin: "ADMIN",
    contents: "Konten / Library", playlists: "Playlist", schedules: "Jadwal Promo",
    screens: "Layar & Grup", review_queue: "Antrean Review", review_history: "Riwayat Review",
    reports: "Laporan Tayang", weekly: "Laporan Mingguan", audit: "Audit Log",
    users: "Pengguna", settings: "Pengaturan", profile: "Profil & 2FA",
    search_ph: "Cari konten, layar, playlist…", server_ok: "Server Normal",
    logout: "Keluar", login: "Masuk", cancel: "Batal", confirm: "Ya, lanjutkan",
    save: "Simpan", add: "Tambah", edit: "Ubah", del: "Hapus", detail: "Detail",
    approve: "Setujui", reject: "Tolak", back: "Kembali", retry: "Coba lagi",
    create: "Buat baru", upload: "Upload Konten", all: "Semua",
    st_approved: "Disetujui", st_pending: "Menunggu", st_pending_delete: "Minta hapus",
    st_rejected: "Ditolak", st_draft: "Draft", st_archived: "Diarsip",
    st_online: "● ONLINE", st_offline: "● OFFLINE", st_disabled: "NONAKTIF",
    st_completed: "Selesai", st_failed: "Gagal", st_skipped: "Dilewati",
    error_generic: "Terjadi kesalahan. Coba lagi.",
    err_conn: "Koneksi terputus. Periksa jaringan lalu coba lagi.",
    err_auth: "Sesi berakhir. Silakan login ulang.",
    empty_title: "Belum ada data",
    empty_hint: "Belum ada data di sini. Yuk buat yang pertama!",
    loading: "Memuat…",
    storage: "Penyimpanan",
    confirm_delete: "Hapus data ini?",
  },
  en: {
    app_sub: "DIGITAL SIGNAGE CMS",
    home: "Home", monitoring: "Monitoring", notifications: "Notifications",
    sec_main: "MAIN", sec_manage: "MANAGE", sec_moderation: "OWNER MODERATION",
    sec_reports: "REPORTS", sec_admin: "ADMIN",
    contents: "Content / Library", playlists: "Playlists", schedules: "Promo Schedules",
    screens: "Screens & Groups", review_queue: "Review Queue", review_history: "Review History",
    reports: "Playout Reports", weekly: "Weekly Reports", audit: "Audit Log",
    users: "Users", settings: "Settings", profile: "Profile & 2FA",
    search_ph: "Search content, screens, playlists…", server_ok: "Server OK",
    logout: "Log out", login: "Log in", cancel: "Cancel", confirm: "Yes, continue",
    save: "Save", add: "Add", edit: "Edit", del: "Delete", detail: "Details",
    approve: "Approve", reject: "Reject", back: "Back", retry: "Retry",
    create: "Create new", upload: "Upload Content", all: "All",
    st_approved: "Approved", st_pending: "Pending", st_pending_delete: "Delete requested",
    st_rejected: "Rejected", st_draft: "Draft", st_archived: "Archived",
    st_online: "● ONLINE", st_offline: "● OFFLINE", st_disabled: "DISABLED",
    st_completed: "Completed", st_failed: "Failed", st_skipped: "Skipped",
    error_generic: "Something went wrong. Try again.",
    err_conn: "Connection lost. Check network and retry.",
    err_auth: "Session expired. Please log in again.",
    empty_title: "No data yet",
    empty_hint: "Nothing here yet. Let's create the first one!",
    loading: "Loading…",
    storage: "Storage",
    confirm_delete: "Delete this item?",
  },
};
function lang() { return localStorage.getItem("sc_lang") || "id"; }
function t(key) {
  const L = I18N[lang()] || I18N.id;
  return L[key] !== undefined ? L[key] : (I18N.id[key] || key);
}
function setLang(l) {
  localStorage.setItem("sc_lang", l);
  document.documentElement.lang = l;
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    el.textContent = t(el.dataset.i18n);
  });
  document.querySelectorAll("[data-i18n-ph]").forEach((el) => {
    el.placeholder = t(el.dataset.i18nPh);
  });
  document.querySelectorAll(".lang-btn").forEach((b) => {
    const on = b.dataset.lang === l;
    b.classList.toggle("bg-slate-900", on);
    b.classList.toggle("text-white", on);
    b.classList.toggle("text-slate-500", !on);
  });
  if (typeof onLangChange === "function") { try { onLangChange(); } catch (e) {} }
}
