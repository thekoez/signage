/* Layout bersama: topbar + sidebar hybrid, identik di semua halaman dashboard. */
const NAV = [
  { group: "sec_main", items: [
    { href: "/dashboard/index.html", icon: "fa-grid-2", label: "home", roles: ["owner", "staff", "teknisi"] },
    { href: "/dashboard/monitoring.html", icon: "fa-tower-broadcast", label: "monitoring", roles: ["owner", "staff", "teknisi"] },
    { href: "/dashboard/notifications.html", icon: "fa-bell", label: "notifications", roles: ["owner", "staff", "teknisi"], badge: "notif" },
  ]},
  { group: "sec_manage", items: [
    { href: "/dashboard/contents.html", icon: "fa-images", label: "contents", roles: ["owner", "staff", "teknisi"] },
    { href: "/dashboard/playlists.html", icon: "fa-list-ul", label: "playlists", roles: ["owner", "staff", "teknisi"] },
    { href: "/dashboard/schedules.html", icon: "fa-calendar-days", label: "schedules", roles: ["owner", "staff", "teknisi"] },
    { href: "/dashboard/screens.html", icon: "fa-tv", label: "screens", roles: ["owner", "staff", "teknisi"] },
  ]},
  { group: "sec_moderation", ownerOnly: true, items: [
    { href: "/dashboard/review.html", icon: "fa-clipboard-check", label: "review_queue", roles: ["owner"], badge: "review" },
    { href: "/dashboard/history.html", icon: "fa-clock-rotate-left", label: "review_history", roles: ["owner"] },
  ]},
  { group: "sec_reports", items: [
    { href: "/dashboard/reports.html", icon: "fa-chart-column", label: "reports", roles: ["owner", "staff", "teknisi"] },
    { href: "/dashboard/weekly.html", icon: "fa-envelope", label: "weekly", roles: ["owner"] },
    { href: "/dashboard/audit.html", icon: "fa-file-lines", label: "audit", roles: ["owner"] },
  ]},
  { group: "sec_admin", items: [
    { href: "/dashboard/users.html", icon: "fa-users", label: "users", roles: ["owner"] },
    { href: "/dashboard/settings.html", icon: "fa-gear", label: "settings", roles: ["owner"] },
    { href: "/dashboard/profile.html", icon: "fa-shield-halved", label: "profile", roles: ["owner", "staff", "teknisi"] },
  ]},
];

async function renderLayout(activeLabel) {
  const user = Auth.user;
  const role = user ? user.role : "staff";
  const initials = (user ? user.name : "?").split(" ").map((w) => w[0]).slice(0, 2).join("").toUpperCase();
  const roleName = { owner: "Owner", staff: "Staff", teknisi: "Teknisi" }[role] || role;

  let navHtml = "";
  for (const g of NAV) {
    const vis = g.items.filter((i) => i.roles.includes(role));
    if (!vis.length) continue;
    navHtml += `<div><p class="px-2 mb-1.5 text-[10.5px] font-bold tracking-[0.12em] text-slate-400" data-i18n="${g.group}">${t(g.group)}</p>`;
    for (const i of vis) {
      const act = i.label === activeLabel ? " active" : "";
      navHtml += `<a href="${i.href}" class="navlink${act}"><i class="fa-solid ${i.icon} w-4 text-center text-slate-400"></i><span data-i18n="${i.label}">${t(i.label)}</span>${i.badge ? `<span data-badge="${i.badge}" class="ml-auto text-[10px] font-bold px-1.5 py-0.5 rounded bg-sky-600 text-white hidden"></span>` : ""}</a>`;
    }
    navHtml += `</div>`;
  }

  document.getElementById("app-shell").innerHTML = `
  <header class="h-14 bg-white border-b border-slate-200 sticky top-0 z-40">
    <div class="h-full px-3 md:px-5 flex items-center gap-3">
      <button id="btnMenu" class="w-9 h-9 grid place-items-center border border-slate-200 rounded text-slate-500 hover:bg-slate-50" aria-label="Menu"><i class="fa-solid fa-bars text-sm"></i></button>
      <a href="/dashboard/index.html" class="flex items-center gap-2.5 shrink-0">
        <span class="w-8 h-8 rounded bg-sky-600 text-white grid place-items-center shadow-sm"><i class="fa-solid fa-display text-sm"></i></span>
        <span class="leading-none">
          <span class="block font-extrabold tracking-tight text-[16px] text-slate-900">SignageCMS</span>
          <span class="block text-[11px] text-slate-500 font-medium tracking-wide" data-i18n="app_sub">${t("app_sub")}</span>
        </span>
        <span class="hidden sm:inline-block text-[11px] font-bold px-1.5 py-0.5 rounded bg-slate-100 border border-slate-200 text-slate-500">v1.1</span>
      </a>
      <div class="hidden md:flex flex-1 max-w-md mx-4">
        <div class="relative w-full">
          <i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs"></i>
          <input id="globalSearch" type="search" data-i18n-ph="search_ph" placeholder="${t("search_ph")}" class="w-full h-9 pl-9 pr-3 text-[13px] border border-slate-200 rounded bg-slate-50 placeholder:text-slate-400 focus:outline-none focus:border-sky-500 focus:bg-white">
        </div>
      </div>
      <div class="flex-1 md:hidden"></div>
      <span class="hidden lg:inline-flex items-center gap-1.5 text-[12px] font-semibold text-slate-600 border border-slate-200 rounded px-2.5 py-1.5 bg-white"><span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span><span data-i18n="server_ok">${t("server_ok")}</span></span>
      <div class="hidden sm:flex border border-slate-200 rounded overflow-hidden" role="group" aria-label="Language">
        <button class="lang-btn px-2 h-9 text-[12px] font-bold" data-lang="id" onclick="setLang('id')">ID</button>
        <button class="lang-btn px-2 h-9 text-[12px] font-bold" data-lang="en" onclick="setLang('en')">EN</button>
      </div>
      <a href="/dashboard/notifications.html" class="relative w-9 h-9 grid place-items-center border border-slate-200 rounded text-slate-500 hover:bg-slate-50" aria-label="Notifikasi">
        <i class="fa-regular fa-bell text-[15px]"></i>
        <span data-badge="notif" class="hidden absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded bg-sky-600 text-white text-[10px] font-bold grid place-items-center"></span>
      </a>
      <div class="relative">
        <button id="userBtn" class="flex items-center gap-2 pl-1 border-l border-slate-200 ml-1">
          <span class="w-9 h-9 rounded bg-slate-900 text-white grid place-items-center text-[12px] font-bold">${initials}</span>
          <span class="hidden xl:block leading-tight text-left">
            <span class="block text-[13px] font-bold text-slate-900">${esc(user.name)}</span>
            <span class="block text-[11px] text-slate-500 font-medium">${roleName} · ${user.is_2fa_enabled ? '<span class="text-sky-700 font-bold">2FA Aktif</span>' : '<span class="text-amber-600 font-bold">2FA Mati</span>'}</span>
          </span>
        </button>
        <div id="userMenu" class="hidden absolute right-0 mt-2 w-52 card p-1.5 z-50">
          <a href="/dashboard/profile.html" class="navlink"><i class="fa-solid fa-user w-4 text-center text-slate-400"></i><span data-i18n="profile">${t("profile")}</span></a>
          <button id="btnLogout" class="navlink w-full text-left"><i class="fa-solid fa-right-from-bracket w-4 text-center text-slate-400"></i><span data-i18n="logout">${t("logout")}</span></button>
        </div>
      </div>
    </div>
  </header>
  <div id="scrim" class="hidden fixed inset-0 bg-slate-900/30 z-40 lg:hidden"></div>
  <div class="flex items-start">
    <aside id="sidebar" class="w-60 shrink-0 bg-white border-r border-slate-200 min-h-[calc(100vh-3.5rem)] sticky top-14 flex flex-col">
      <nav class="flex-1 overflow-y-auto thin-scroll px-3 py-4 space-y-5 text-[13px]">${navHtml}</nav>
      <div class="p-3 border-t border-slate-200">
        <div class="flex items-center gap-2">
          <span class="w-8 h-8 rounded bg-slate-900 text-white grid place-items-center text-[11px] font-bold">${initials}</span>
          <div class="leading-tight flex-1"><p class="text-[12.5px] font-bold text-slate-900 truncate">${esc(user.name)}</p><p class="text-[11px] text-slate-500">${esc(user.email)}</p></div>
        </div>
      </div>
    </aside>
    <main id="page" class="flex-1 min-w-0 px-4 md:px-6 py-5 max-w-[1200px] mx-auto w-full"></main>
  </div>`;
  setLang(lang());
  document.getElementById("btnMenu").onclick = () => {
    document.getElementById("sidebar").classList.toggle("open");
    document.getElementById("scrim").classList.toggle("hidden");
  };
  document.getElementById("scrim").onclick = () => {
    document.getElementById("sidebar").classList.remove("open");
    document.getElementById("scrim").classList.add("hidden");
  };
  document.getElementById("userBtn").onclick = (e) => {
    e.stopPropagation();
    document.getElementById("userMenu").classList.toggle("hidden");
  };
  document.addEventListener("click", () => document.getElementById("userMenu")?.classList.add("hidden"));
  document.getElementById("btnLogout").onclick = () => Auth.logout();
  const gs = document.getElementById("globalSearch");
  if (gs) gs.addEventListener("keydown", (e) => {
    if (e.key === "Enter") location.href = "/dashboard/contents.html?q=" + encodeURIComponent(gs.value);
  });
  refreshBadges();
}
function esc(s) { return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }

async function refreshBadges() {
  try {
    const me = await Api.get("/api/users/me");
    document.querySelectorAll('[data-badge="notif"]').forEach((el) => {
      if (me.unread_notifications > 0) { el.textContent = me.unread_notifications; el.classList.remove("hidden"); }
      else el.classList.add("hidden");
    });
  } catch (e) {}
  if (Auth.user && Auth.user.role === "owner") {
    try {
      const p = await Api.get("/api/reviews/pending");
      document.querySelectorAll('[data-badge="review"]').forEach((el) => {
        if (p.total > 0) { el.textContent = p.total; el.classList.remove("hidden"); }
      });
    } catch (e) {}
  }
}

function pageHead(kicker, title, desc, actionsHtml = "") {
  return `
  <div class="flex flex-wrap items-start gap-3">
    <div class="flex-1 min-w-[220px]">
      <p class="text-[11px] font-bold tracking-[0.12em] text-slate-400 uppercase">${esc(kicker)}</p>
      <h1 class="text-[22px] md:text-[26px] font-extrabold tracking-tight text-slate-900">${esc(title)}</h1>
      <p class="text-[13.5px] text-slate-500">${esc(desc)}</p>
    </div>
    <div class="flex flex-wrap gap-2">${actionsHtml}</div>
  </div>`;
}
function emptyState(icon, actionHtml = "") {
  return `<div class="card p-10 text-center">
    <span class="mx-auto w-12 h-12 rounded bg-sky-50 border border-sky-100 text-sky-600 grid place-items-center"><i class="fa-solid ${icon} text-lg"></i></span>
    <h3 class="mt-3 text-[15px] font-extrabold text-slate-900">${t("empty_title")}</h3>
    <p class="mt-1 text-[13px] text-slate-500">${t("empty_hint")}</p>
    <div class="mt-4 flex justify-center gap-2">${actionHtml}</div></div>`;
}
function skelCards(n = 4) {
  let h = `<div class="grid grid-cols-2 xl:grid-cols-4 gap-3">`;
  for (let i = 0; i < n; i++) h += `<div class="card p-4"><div class="skel h-5 w-2/3 rounded"></div><div class="skel h-8 w-1/2 rounded mt-2"></div><div class="skel h-3 w-full rounded mt-2"></div></div>`;
  return h + `</div>`;
}
