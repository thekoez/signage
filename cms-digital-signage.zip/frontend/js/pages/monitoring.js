/* Monitoring wall: grid status semua layar + Now Playing, poll 30 dtk. */
(async () => {
  await Auth.init(true);
  await renderLayout("monitoring");
  const page = document.getElementById("page");
  page.innerHTML = `
    ${pageHead("Operasional", "Monitoring Layar", "Konten apa sedang tayang? Layar mana online / mati?", `<span class="text-[11px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 rounded px-2 py-1.5">LIVE · poll 30 dtk</span>`)}
    <div id="sum" class="mt-4 grid grid-cols-3 gap-3"></div>
    <div class="card mt-3 p-3 flex flex-wrap gap-2 items-center">
      <div class="relative flex-1 min-w-[160px]"><i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs"></i>
        <input id="fQ" placeholder="Cari nama / lokasi…" class="inp pl-9"></div>
      <div class="flex gap-1.5" id="fBtns">
        <button data-f="" class="btn btn-dark btn-sm">Semua</button>
        <button data-f="online" class="btn btn-sec btn-sm">Online</button>
        <button data-f="offline" class="btn btn-sec btn-sm">Offline</button>
      </div>
    </div>
    <div id="wall" class="mt-3 grid sm:grid-cols-2 xl:grid-cols-3 gap-3"></div>`;
  let f = "", q = "";
  document.getElementById("fBtns").querySelectorAll("[data-f]").forEach((b) => b.onclick = () => {
    f = b.dataset.f;
    document.getElementById("fBtns").querySelectorAll("button").forEach((x) => x.className = "btn btn-sec btn-sm");
    b.className = "btn btn-dark btn-sm";
    load();
  });
  document.getElementById("fQ").oninput = (e) => { q = e.target.value.toLowerCase(); load(false); };

  let cache = [];
  async function load(spin = true) {
    try {
      const p = new URLSearchParams({ limit: 100 });
      if (f) p.set("status", f);
      const r = await Api.get("/api/screens?" + p);
      cache = r.items;
      paint();
      const ov = await Api.get("/api/monitoring/overview");
      document.getElementById("sum").innerHTML = `
        <div class="card p-4"><p class="text-[12px] font-bold text-slate-500">ONLINE</p><p class="text-[24px] font-extrabold text-emerald-600">${ov.online}</p></div>
        <div class="card p-4"><p class="text-[12px] font-bold text-slate-500">OFFLINE</p><p class="text-[24px] font-extrabold text-red-600">${ov.offline}</p></div>
        <div class="card p-4"><p class="text-[12px] font-bold text-slate-500">NONAKTIF</p><p class="text-[24px] font-extrabold text-slate-500">${ov.disabled}</p></div>`;
    } catch (e) { toast(errMsg(e), "error"); }
  }
  function paint() {
    const rows = cache.filter((s) => !q || (s.name + " " + s.location_detail).toLowerCase().includes(q));
    document.getElementById("wall").innerHTML = rows.length ? rows.map((s) => `
      <article class="card overflow-hidden ${s.status === "offline" ? "border-red-300" : ""}">
        <div class="p-3.5">
          <div class="flex items-center gap-2">${statusBadge(s.status)}
            <span class="ml-auto font-mono text-[10px] text-slate-400">${s.orientation === "portrait" ? "9:16" : "16:9"} · ${esc(s.resolution)}</span></div>
          <h3 class="mt-1.5 text-[14.5px] font-extrabold text-slate-900">${esc(s.name)}</h3>
          <p class="text-[12px] text-slate-500">${esc(s.group_name)} · heartbeat ${s.last_heartbeat_at ? relTime(s.last_heartbeat_at) : "-"}</p>
          <div class="mt-2 border border-slate-100 rounded bg-slate-50 px-2.5 py-2 text-[12.5px]">
            <span class="text-slate-400 font-bold text-[11px]">NOW PLAYING</span><br>
            <strong class="text-slate-800">${esc(s.now_playing?.title || "—")}</strong>
          </div>
          <div class="mt-2.5 flex gap-1.5">
            <a class="btn btn-sec btn-sm flex-1" href="/dashboard/screens.html">Detail</a>
            ${["owner", "teknisi"].includes(Auth.user.role) ? `<button class="btn btn-dark btn-sm flex-1" data-rl="${s.id}"><i class="fa-solid fa-rotate-right"></i>Reload</button>` : ""}
          </div>
        </div>
      </article>`).join("") : emptyState("fa-tower-broadcast");
    document.getElementById("wall").querySelectorAll("[data-rl]").forEach((b) => b.onclick = async () => {
      try { await Api.post(`/api/screens/${b.dataset.rl}/commands`, { command: "reload" }); toast("Reload dikirim.", "success"); }
      catch (e) { toast(errMsg(e), "error"); }
    });
  }
  load();
  setInterval(() => load(false), 30000);
})();
