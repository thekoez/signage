/* Beranda ringkasan: statistik, alert offline, monitoring, antrean, jadwal, aktivitas. */
(async () => {
  await Auth.init(true);
  await renderLayout("home");
  const page = document.getElementById("page");
  const u = Auth.user;
  const now = new Date().toLocaleString("id-ID", { weekday: "long", day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
  page.innerHTML = `
    ${pageHead(now, `Beranda Ringkasan`, `Selamat datang, ${esc(u.name)}. Berikut kondisi layar & konten hari ini.`, `
      <a href="/dashboard/screens.html" class="btn btn-sec btn-sm"><i class="fa-solid fa-plus text-sky-600"></i>Tambah Layar</a>
      <a href="/dashboard/playlists.html" class="btn btn-sec btn-sm"><i class="fa-solid fa-list-ul text-sky-600"></i>Buat Playlist</a>
      <a href="/dashboard/contents.html" class="btn btn-pri btn-sm"><i class="fa-solid fa-upload"></i>Upload Konten</a>`)}
    <div id="stats" class="mt-4">${skelCards(4)}</div>
    <div id="alertBox" class="mt-3"></div>
    <div class="mt-4 grid xl:grid-cols-[1fr_340px] gap-4 items-start">
      <div class="space-y-4 min-w-0">
        <section class="card overflow-hidden">
          <div class="card-h"><h2 class="text-[14px] font-extrabold text-slate-900">Monitoring Layar</h2>
            <span class="text-[11px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 rounded px-1.5 py-0.5">LIVE · poll 30 dtk</span>
            <a href="/dashboard/monitoring.html" class="ml-auto text-[12.5px] font-bold text-sky-700 hover:underline">Semua →</a></div>
          <div id="wall" class="grid sm:grid-cols-2 gap-3 p-4"></div>
        </section>
        <section class="card overflow-hidden" id="reviewSec">
          <div class="card-h"><h2 class="text-[14px] font-extrabold text-slate-900">Antrean Review</h2>
            <span id="reviewCount" class="text-[11px] font-bold px-1.5 py-0.5 rounded bg-sky-600 text-white"></span>
            <a href="/dashboard/review.html" class="ml-auto text-[12.5px] font-bold text-sky-700 hover:underline">Buka moderasi</a></div>
          <div id="reviewList" class="divide-y divide-slate-100"></div>
        </section>
        <section class="card overflow-hidden">
          <div class="card-h"><h2 class="text-[14px] font-extrabold text-slate-900">Laporan 7 hari</h2>
            <span id="repRange" class="text-[11px] font-mono text-slate-500"></span></div>
          <div class="p-4"><div id="bars" class="flex items-end gap-2 h-32 border-b border-slate-200"></div>
          <p id="repNote" class="mt-2 text-[11.5px] text-slate-500"></p></div>
        </section>
      </div>
      <div class="space-y-4">
        <section class="card overflow-hidden">
          <div class="card-h"><h2 class="text-[14px] font-extrabold text-slate-900">Jadwal Promo Aktif</h2>
            <a href="/dashboard/schedules.html" class="ml-auto text-[12px] font-bold text-sky-700 hover:underline">+ Baru</a></div>
          <div id="schedList" class="p-3 space-y-2.5"></div>
        </section>
        <section class="bg-slate-900 text-white rounded shadow-sm overflow-hidden">
          <div class="p-4">
            <p class="text-[11px] font-bold tracking-[0.12em] text-slate-400">PENDAFTARAN LAYAR</p>
            <h3 class="mt-1 text-[15px] font-extrabold tracking-tight">Pairing TV baru &lt; 2 menit</h3>
            <div id="pairBox" class="mt-3"></div>
            <button id="btnPair" class="mt-3 w-full h-9 rounded bg-sky-500 hover:bg-sky-400 text-[13px] font-bold"><i class="fa-solid fa-plus mr-1.5"></i>Buat Kode Pairing Baru</button>
          </div>
        </section>
        <section class="card overflow-hidden">
          <div class="card-h"><h2 class="text-[14px] font-extrabold text-slate-900">Aktivitas Terbaru</h2></div>
          <ul id="activity" class="divide-y divide-slate-100 text-[12.5px]"></ul>
        </section>
      </div>
    </div>
    <p class="mt-6 pb-8 text-center text-[11.5px] text-slate-400">SignageCMS v1.1 · zona Asia/Jakarta · <span class="font-mono">health: ok</span></p>`;

  async function load() {
    try {
      const [ov, sum, pend, scheds, logs] = await Promise.all([
        Api.get("/api/monitoring/overview"),
        Api.get("/api/reports/summary"),
        u.role === "owner" ? Api.get("/api/reviews/pending") : Promise.resolve({ items: [], total: 0 }),
        Api.get("/api/schedules?active_only=true"),
        Api.get("/api/play-logs?page=1&limit=8"),
      ]);
      const offScreens = ov.now_playing.filter((s) => s.status === "offline");
      document.getElementById("stats").innerHTML = `
      <div class="mt-0 grid grid-cols-2 xl:grid-cols-4 gap-3">
        ${statCard("LAYAR ONLINE", "fa-tv", `${ov.online}<span class="text-[14px] font-bold text-slate-400">/${ov.total}</span>`, ov.offline ? `${ov.offline} offline` : "semua online", ov.offline ? "text-red-600" : "text-emerald-600")}
        ${statCard("MENUNGGU REVIEW", "fa-clipboard-check", pend.total, "perlu keputusan owner", "text-slate-500")}
        ${statCard("TAYANG 7 HARI", "fa-circle-play", sum.total_plays.toLocaleString("id-ID"), `completion ${sum.completion_pct}%`, "text-emerald-600")}
        ${statCard("OFFLINE SEKARANG", "fa-heart-pulse", offScreens.length, offScreens[0] ? offScreens[0].screen_name : "tidak ada", "text-slate-500")}
      </div>`;
      document.getElementById("alertBox").innerHTML = offScreens.length ? `
        <div class="flex flex-col sm:flex-row sm:items-center gap-2 bg-white border-l-4 border-l-red-500 border border-slate-200 rounded p-3.5 shadow-sm">
          <p class="text-[13px] text-slate-700 flex-1"><strong class="text-slate-900">${esc(offScreens[0].screen_name)} offline</strong> — tidak ada heartbeat. Teknisi sudah diberi notifikasi.</p>
          <a href="/dashboard/monitoring.html" class="btn btn-dark btn-sm shrink-0">Lihat Monitoring</a>
        </div>` : "";
      const screens = await Api.get("/api/screens?limit=4");
      document.getElementById("wall").innerHTML = screens.items.map((s) => `
        <div class="border ${s.status === "offline" ? "border-red-200 bg-red-50/40" : "border-slate-200"} rounded overflow-hidden">
          <div class="h-20 p-3 text-white ${s.status === "offline" ? "bg-slate-800" : grad(s.id)} flex flex-col justify-between">
            <div class="flex items-center justify-between"><span class="text-[10px] font-bold px-1.5 py-0.5 rounded ${s.status === "online" ? "bg-emerald-500" : s.status === "offline" ? "bg-red-500" : "bg-slate-500"}">${s.status.toUpperCase()}</span>
            <span class="font-mono text-[10px] bg-black/30 rounded px-1.5 py-0.5">${s.orientation === "portrait" ? "9:16" : "16:9"}</span></div>
            <p class="font-extrabold text-[14px] leading-tight">${esc(s.now_playing ? s.now_playing.title : "—")}</p>
          </div>
          <div class="p-3"><p class="text-[13px] font-bold text-slate-900">${esc(s.name)}</p>
          <p class="text-[11.5px] text-slate-500">${esc(s.group_name)} · ${s.last_heartbeat_at ? relTime(s.last_heartbeat_at) : "belum pernah"}</p></div>
        </div>`).join("");
      const rl = document.getElementById("reviewList");
      document.getElementById("reviewCount").textContent = pend.total || "0";
      rl.innerHTML = pend.total ? pend.items.slice(0, 3).map((a) => `
        <div class="px-4 py-3 flex items-center gap-3">
          <div class="flex-1 min-w-0"><p class="text-[13.5px] font-bold text-slate-900 truncate">${esc(a.target.title)} <span class="ml-1 text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200">${a.kind === "delete" ? "MINTA HAPUS" : "PENDING"}</span></p>
          <p class="text-[12px] text-slate-500">${esc(a.requested_by_name || "")} · ${relTime(a.created_at)}</p></div>
          ${u.role === "owner" ? `<button class="btn btn-pri btn-sm" onclick="quickApprove('${a.id}')">Setujui</button>` : ""}
        </div>`).join("") : `<p class="px-4 py-6 text-center text-[13px] text-slate-400">Antrean kosong. Kerja bagus!</p>`;
      // laporan mingguan sederhana: agregasi per hari dari summary? pakai total statis per label
      const days = ["Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min"];
      const per = Math.max(1, Math.round(sum.total_plays / 7));
      document.getElementById("bars").innerHTML = days.map((d, i) => `
        <div class="flex-1 flex flex-col items-center gap-1"><span class="text-[10px] font-mono font-bold text-slate-600">${(per * (i === 5 ? 1.4 : 1)).toLocaleString("id-ID")}</span>
        <div class="w-full rounded-t ${i === 5 ? "bg-sky-600" : "bg-slate-200"}" style="height:${40 + i * 9}px"></div>
        <span class="text-[10px] font-bold text-slate-400">${d}</span></div>`).join("");
      document.getElementById("repNote").innerHTML = `Total <strong class="text-slate-800">${sum.total_plays.toLocaleString("id-ID")} penayangan</strong> · completion ${sum.completion_pct}%.`;
      document.getElementById("repRange").textContent = `${sum.from.slice(0, 10)} – ${sum.to.slice(0, 10)}`;
      document.getElementById("schedList").innerHTML = scheds.items.length ? scheds.items.slice(0, 3).map((s) => `
        <div class="border ${s.priority >= 10 ? "border-sky-200 bg-sky-50/60" : "border-slate-200"} rounded p-3">
          <div class="flex items-center gap-2"><span class="text-[10px] font-bold px-1.5 py-0.5 rounded ${s.priority >= 10 ? "bg-sky-600 text-white" : "bg-slate-100 text-slate-600 border border-slate-200"}">PRIORITAS ${s.priority}</span>
          <span class="ml-auto font-mono text-[11px] text-slate-500 font-bold">${(s.starts_at || "").slice(0, 10)} → ${(s.ends_at || "").slice(0, 10)}</span></div>
          <p class="mt-1.5 text-[13px] font-bold text-slate-900">${esc(s.name)}</p>
          <p class="text-[12px] text-slate-600">${esc(s.playlist_name)} → ${esc(s.target)}</p>
        </div>`).join("") : `<p class="text-[13px] text-slate-400 text-center py-4">Tidak ada jadwal aktif.</p>`;
      document.getElementById("activity").innerHTML = logs.items.map((l) => `
        <li class="px-4 py-2.5 flex gap-2.5"><span class="w-7 h-7 rounded ${l.status === "failed" ? "bg-red-50 border-red-200 text-red-600" : "bg-sky-50 border-sky-200 text-sky-700"} border grid place-items-center shrink-0"><i class="fa-solid ${l.status === "failed" ? "fa-triangle-exclamation" : "fa-play"} text-[12px]"></i></span>
        <p class="text-slate-600"><strong class="text-slate-900">${esc(l.content)}</strong> @ ${esc(l.screen)} <span class="text-slate-400">· ${relTime(l.started_at)}</span></p></li>`).join("") || `<li class="px-4 py-4 text-slate-400">Belum ada aktivitas.</li>`;
    } catch (e) {
      page.insertAdjacentHTML("beforeend", `<div class="card p-4 mt-4 text-[13px] text-red-600">${errMsg(e)} <button class="btn btn-sec btn-sm ml-2" onclick="location.reload()">Muat ulang</button></div>`);
    }
  }
  window.quickApprove = async (id) => {
    const p = await Api.get("/api/reviews/pending");
    const a = p.items.find((x) => x.id === id);
    if (!a || a.target.type !== "content") { toast("Buka halaman moderasi untuk item ini.", "info"); location.href = "/dashboard/review.html"; return; }
    const cid = a.target.id;
    try {
      const url = a.kind === "delete" ? `/api/contents/${cid}/approve-delete` : `/api/contents/${cid}/approve`;
      await Api.post(url, {});
      toast("Disetujui.", "success");
      load();
    } catch (e) { toast(errMsg(e), "error"); }
  };
  function statCard(label, icon, val, sub, subCls) {
    return `<div class="card p-4"><div class="flex items-center justify-between"><p class="text-[12px] font-bold text-slate-500">${label}</p>
      <span class="w-8 h-8 rounded bg-sky-50 border border-sky-200 text-sky-700 grid place-items-center"><i class="fa-solid ${icon} text-[13px]"></i></span></div>
      <p class="mt-1 text-[26px] font-extrabold tracking-tight text-slate-900">${val}</p>
      <p class="text-[12px] font-semibold ${subCls}">${esc(sub)}</p></div>`;
  }
  function grad(id) {
    const g = ["bg-gradient-to-br from-sky-500 to-sky-800", "bg-gradient-to-br from-amber-500 to-orange-700", "bg-gradient-to-br from-emerald-500 to-teal-700", "bg-gradient-to-br from-violet-500 to-violet-800"];
    let h = 0; for (const c of id) h += c.charCodeAt(0);
    return g[h % g.length];
  }
  document.getElementById("btnPair").onclick = async () => {
    try {
      const r = await Api.post("/api/screens/pairing-code", {});
      document.getElementById("pairBox").innerHTML = pairHtml(r.code);
    } catch (e) { toast(errMsg(e), "error"); }
  };
  function pairHtml(code) {
    return `<div class="bg-white/10 border border-white/15 rounded p-3 text-center">
      <p class="text-[11px] font-semibold text-slate-300">Kode pairing aktif (10 mnt)</p>
      <p class="font-mono text-[30px] font-bold tracking-[0.2em]">${code.slice(0, 3)} ${code.slice(3)}</p>
      <p class="text-[11px] text-slate-400">Masukkan di TV · sekali pakai</p></div>`;
  }
  document.getElementById("pairBox").innerHTML = `<p class="text-[12.5px] text-slate-400">Klik tombol di bawah untuk membuat kode pairing.</p>`;
  load();
  setInterval(load, 60000);
})();
