/* Arsip laporan mingguan: daftar rekap + generate manual + unduh CSV. */
(async () => {
  await Auth.init(true);
  if (Auth.user.role !== "owner") { location.href = "/dashboard/index.html"; return; }
  await renderLayout("weekly");
  const page = document.getElementById("page");
  page.innerHTML = `
    ${pageHead("Laporan", "Laporan Mingguan", "Rekap otomatis tiap Minggu 18:00 WIB + kirim email ke pemilik.", `<button id="btnGen" class="btn btn-pri btn-sm"><i class="fa-solid fa-rotate"></i>Generate Sekarang</button>`)}
    <div id="list" class="mt-4 space-y-3"></div>`;
  document.getElementById("btnGen").onclick = async () => {
    try {
      const r = await Api.post("/api/reports/weekly/generate", {});
      toast(`Laporan ${r.payload.total_plays} tayangan dibuat + email dikirim.`, "success");
      load();
    } catch (e) { toast(errMsg(e), "error"); }
  };
  async function load() {
    const list = document.getElementById("list");
    try {
      const r = await Api.get("/api/reports/weekly");
      list.innerHTML = r.items.length ? r.items.map((w) => `
        <article class="card p-4">
          <div class="flex flex-wrap items-center gap-2">
            <h3 class="text-[15px] font-extrabold">Periode ${w.period_start} – ${w.period_end}</h3>
            <span class="ml-auto text-[11.5px] ${w.emailed_at ? "text-emerald-600 font-bold" : "text-amber-600 font-bold"}">${w.emailed_at ? "Email terkirim " + fmtDate(w.emailed_at) : "Email tertunda"}</span>
          </div>
          <p class="mt-1 text-[13px] text-slate-600">Total <strong>${(w.payload.total_plays || 0).toLocaleString("id-ID")}</strong> tayangan · completion <strong>${w.payload.completion_pct || 0}%</strong> · top: <strong>${esc(w.payload.top_contents?.[0]?.title || "-")}</strong></p>
          <div class="mt-2"><a class="btn btn-sec btn-sm" href="/api/reports/weekly/${w.id}/export.csv"><i class="fa-solid fa-download"></i>Unduh CSV</a></div>
        </article>`).join("") : emptyState("fa-envelope", `<button class="btn btn-pri btn-sm" onclick="document.getElementById('btnGen').click()">Generate pertama</button>`);
      // CSV butuh token: fetch manual dengan auth
      list.querySelectorAll('a[href*="export.csv"]').forEach((a) => a.onclick = async (e) => {
        e.preventDefault();
        try {
          const res = await fetch(a.href, { headers: { Authorization: "Bearer " + Api.token } });
          if (!res.ok) throw new Error("HTTP " + res.status);
          const blob = await res.blob();
          const u = document.createElement("a");
          u.href = URL.createObjectURL(blob);
          u.download = "laporan-mingguan.csv";
          u.click();
          toast("CSV diunduh.", "success");
        } catch (ex) { toast(errMsg(ex), "error"); }
      });
    } catch (e) { list.innerHTML = `<div class="card p-6 text-red-600 text-[13px]">${errMsg(e)}</div>`; }
  }
  load();
})();
