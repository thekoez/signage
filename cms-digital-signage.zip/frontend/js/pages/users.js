/* Pengguna: daftar, undang, peran, nonaktif, reset 2FA + alasan. */
(async () => {
  await Auth.init(true);
  if (Auth.user.role !== "owner") { location.href = "/dashboard/index.html"; return; }
  await renderLayout("users");
  const page = document.getElementById("page");
  page.innerHTML = `
    ${pageHead("Admin", "Manajemen Pengguna", "Undang staff/teknisi, ubah peran, nonaktifkan, reset 2FA.", `<button id="btnInv" class="btn btn-pri btn-sm"><i class="fa-solid fa-paper-plane"></i>Undang Pengguna</button>`)}
    <div class="card mt-4 p-3 flex flex-wrap gap-2 items-center">
      <div class="relative flex-1 min-w-[160px]"><i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs"></i>
        <input id="fQ" placeholder="Cari nama / email…" class="inp pl-9"></div>
      <select id="fR" class="inp"><option value="">Semua peran</option><option value="owner">Owner</option><option value="staff">Staff</option><option value="teknisi">Teknisi</option></select>
    </div>
    <div class="card mt-3 overflow-hidden"><div class="overflow-x-auto"><table class="tbl w-full">
      <thead><tr><th>Pengguna</th><th>Peran</th><th>Status</th><th>2FA</th><th>Aksi</th></tr></thead>
      <tbody id="rows"></tbody></table></div></div>`;
  let q = "", role = "";
  document.getElementById("fQ").oninput = (e) => { q = e.target.value; load(); };
  document.getElementById("fR").onchange = (e) => { role = e.target.value; load(); };
  document.getElementById("btnInv").onclick = () => {
    openModal("Undang pengguna", `
      <div class="space-y-2">
        <div><label class="text-[12px] font-bold" for="iEm">Email</label><input id="iEm" type="email" class="inp mt-1" placeholder="nama@perusahaan.id"></div>
        <div><label class="text-[12px] font-bold" for="iRo">Peran</label>
          <select id="iRo" class="inp mt-1 w-full"><option value="staff">Staff Marketing</option><option value="teknisi">Teknisi</option><option value="owner">Owner</option></select></div>
        <button id="iGo" class="btn btn-pri w-full">Kirim undangan</button>
        <p id="iLink" class="hidden text-[12px] font-mono bg-slate-50 border border-slate-200 rounded p-2 break-all"></p>
      </div>`, (body) => {
      body.querySelector("#iGo").onclick = async () => {
        try {
          const r = await Api.post("/api/users/invite", { email: body.querySelector("#iEm").value.trim(), role: body.querySelector("#iRo").value });
          const l = body.querySelector("#iLink");
          l.textContent = "Tautan undangan: " + location.origin + r.invite_link;
          l.classList.remove("hidden");
          toast("Undangan dibuat + email dikirim.", "success");
          load();
        } catch (e) { toast(errMsg(e), "error"); }
      };
    });
  };
  async function load() {
    const p = new URLSearchParams({ limit: 50 });
    if (q) p.set("q", q);
    if (role) p.set("role", role);
    try {
      const r = await Api.get("/api/users?" + p);
      document.getElementById("rows").innerHTML = r.items.map((x) => `
        <tr class="${x.is_active ? "" : "opacity-60"}">
          <td data-l="Pengguna"><strong>${esc(x.name)}</strong><br><span class="font-mono text-[11.5px] text-slate-500">${esc(x.email)}</span></td>
          <td data-l="Peran"><select data-role="${x.id}" class="inp !h-9 !text-[12.5px]" ${x.id === Auth.user.id ? "disabled" : ""}>
            ${["owner", "staff", "teknisi"].map((o) => `<option ${x.role === o ? "selected" : ""}>${o}</option>`).join("")}</select></td>
          <td data-l="Status"><span class="badge ${x.is_active ? "bg-emerald-50 text-emerald-700 border-emerald-200" : "bg-slate-100 text-slate-500 border-slate-200"}">${x.is_active ? "Aktif" : "Nonaktif"}</span></td>
          <td data-l="2FA"><span class="badge ${x.is_2fa_enabled ? "bg-sky-50 text-sky-700 border-sky-200" : "bg-amber-50 text-amber-700 border-amber-200"}">${x.is_2fa_enabled ? `Aktif (${x.backup_remaining})` : "Mati"}</span></td>
          <td data-l="Aksi"><div class="flex flex-wrap gap-1.5">
            ${x.id !== Auth.user.id ? `<button class="btn btn-sec btn-sm" data-tg="${x.id}">${x.is_active ? "Nonaktifkan" : "Aktifkan"}</button>` : ""}
            ${x.is_2fa_enabled ? `<button class="btn btn-sec btn-sm" data-rs="${x.id}">Reset 2FA</button>` : ""}
          </div></td>
        </tr>`).join("");
      document.getElementById("rows").querySelectorAll("[data-role]").forEach((s) => s.onchange = async () => {
        try { await Api.patch(`/api/users/${s.dataset.role}/role`, { role: s.value }); toast("Peran diubah + tercatat audit.", "success"); }
        catch (e) { toast(errMsg(e), "error"); load(); }
      });
      document.getElementById("rows").querySelectorAll("[data-tg]").forEach((b) => b.onclick = async () => {
        const row = r.items.find((x) => x.id === b.dataset.tg);
        if (row.is_active && !await confirmModal({ title: "Nonaktifkan akun?", message: "Token langsung dicabut, akses terputus.", confirmText: "Ya, nonaktifkan", danger: true })) return;
        try { await Api.patch(`/api/users/${b.dataset.tg}/active`, { is_active: !row.is_active }); toast("Status diubah.", "success"); load(); }
        catch (e) { toast(errMsg(e), "error"); }
      });
      document.getElementById("rows").querySelectorAll("[data-rs]").forEach((b) => b.onclick = async () => {
        const reason = await inputModal({ title: "Reset 2FA pengguna", label: "Alasan reset (wajib, tercatat audit)", placeholder: "cth. HP hilang, sudah verifikasi identitas", required: true, multiline: true });
        if (!reason) return;
        try { await Api.post(`/api/users/${b.dataset.rs}/reset-2fa`, { reason }); toast("2FA direset + secret lama hangus.", "success"); load(); }
        catch (e) { toast(errMsg(e), "error"); }
      });
    } catch (e) { toast(errMsg(e), "error"); }
  }
  load();
})();
