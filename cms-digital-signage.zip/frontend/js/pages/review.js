/* Moderasi owner: antrean terbit + hapus (≤3 klik), setujui/tolak + catatan. */
(async () => {
  await Auth.init(true);
  if (Auth.user.role !== "owner") { location.href = "/dashboard/index.html"; return; }
  await renderLayout("review_queue");
  const page = document.getElementById("page");
  page.innerHTML = `
    ${pageHead("Moderasi Pemilik", "Antrean Review", "Preview cepat, Setujui / Tolak + catatan. Konten non-approved tidak diputar player.")}
    <div class="mt-4 border-b border-slate-200 flex gap-1 text-[13px] font-bold">
      <button id="tabP" class="px-4 py-2.5 border-b-2 border-sky-600 text-sky-700">Terbit <span id="cP" class="ml-1 text-[10px] px-1.5 py-0.5 rounded bg-sky-600 text-white"></span></button>
      <button id="tabD" class="px-4 py-2.5 border-b-2 border-transparent text-slate-500">Hapus <span id="cD" class="ml-1 text-[10px] px-1.5 py-0.5 rounded bg-white text-slate-600 border border-slate-300"></span></button>
    </div>
    <div id="list" class="mt-3 divide-y divide-slate-100 card overflow-hidden"></div>`;
  let items = [];
  document.getElementById("tabP").onclick = () => paint("publish");
  document.getElementById("tabD").onclick = () => paint("delete");

  async function load() {
    try {
      const r = await Api.get("/api/reviews/pending");
      items = r.items;
      const p = items.filter((x) => x.kind === "publish").length;
      const d = items.filter((x) => x.kind === "delete").length;
      document.getElementById("cP").textContent = p;
      document.getElementById("cD").textContent = d;
      paint("publish");
      refreshBadges();
    } catch (e) {
      document.getElementById("list").innerHTML = `<p class="p-6 text-center text-red-600 text-[13px]">${errMsg(e)}</p>`;
    }
  }
  function paint(kind) {
    const isP = kind === "publish";
    document.getElementById("tabP").className = "px-4 py-2.5 border-b-2 " + (isP ? "border-sky-600 text-sky-700" : "border-transparent text-slate-500");
    document.getElementById("tabD").className = "px-4 py-2.5 border-b-2 " + (!isP ? "border-sky-600 text-sky-700" : "border-transparent text-slate-500");
    const rows = items.filter((x) => x.kind === kind);
    document.getElementById("list").innerHTML = rows.length ? rows.map((a) => `
      <div class="px-4 py-3 flex flex-wrap items-center gap-3">
        ${a.target.thumb_url ? `<img src="${a.target.thumb_url}" class="w-16 h-11 object-cover rounded border border-slate-200" alt="">` : `<span class="w-16 h-11 rounded bg-slate-800 text-white grid place-items-center text-[10px] font-bold">${esc(a.target.type)}</span>`}
        <div class="flex-1 min-w-[200px]"><p class="text-[13.5px] font-bold text-slate-900">${esc(a.target.title)}
          <span class="ml-1 text-[10px] font-bold px-1.5 py-0.5 rounded ${kind === "delete" ? "bg-red-50 text-red-700 border border-red-200" : "bg-amber-50 text-amber-700 border border-amber-200"}">${kind === "delete" ? "MINTA HAPUS" : "PENDING"}</span></p>
          <p class="text-[12px] text-slate-500">oleh <strong>${esc(a.requested_by_name || "-")}</strong> · ${relTime(a.created_at)} · <a class="text-sky-700 font-bold hover:underline" href="/dashboard/contents.html">preview</a></p></div>
        <div class="flex gap-1.5">
          <button class="btn btn-sec btn-sm" data-rj="${a.id}">Tolak</button>
          <button class="btn ${kind === "delete" ? "btn-danger" : "btn-pri"} btn-sm" data-ap="${a.id}">${kind === "delete" ? "Setujui Hapus" : "Setujui"}</button>
        </div>
      </div>`).join("") : `<p class="p-8 text-center text-[13px] text-slate-400">Antrean kosong. Kerja bagus!</p>`;
    document.getElementById("list").querySelectorAll("[data-ap]").forEach((b) => b.onclick = async () => {
      const a = items.find((x) => x.id === b.dataset.ap);
      try {
        if (a.target.type !== "content") { toast("Approval playlist: kelola manual.", "info"); return; }
        const url = a.kind === "delete" ? `/api/contents/${a.target.id}/approve-delete` : `/api/contents/${a.target.id}/approve`;
        await Api.post(url, {});
        toast("Disetujui.", "success"); load();
      } catch (e) { toast(errMsg(e), "error"); }
    });
    document.getElementById("list").querySelectorAll("[data-rj]").forEach((b) => b.onclick = async () => {
      const a = items.find((x) => x.id === b.dataset.rj);
      const note = await inputModal({ title: "Tolak pengajuan", label: "Catatan untuk staff", placeholder: "cth. Perbaiki teks…", required: true, multiline: true });
      if (!note) return;
      try {
        if (a.target.type !== "content") { toast("Approval playlist: kelola manual.", "info"); return; }
        const url = a.kind === "delete" ? `/api/contents/${a.target.id}/reject-delete` : `/api/contents/${a.target.id}/reject`;
        await Api.post(url, { note });
        toast("Ditolak dengan catatan.", "success"); load();
      } catch (e) { toast(errMsg(e), "error"); }
    });
  }
  load();
})();
