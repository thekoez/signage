/* Riwayat review: semua keputusan + catatan + aktor. */
(async () => {
  await Auth.init(true);
  if (Auth.user.role !== "owner") { location.href = "/dashboard/index.html"; return; }
  await renderLayout("review_history");
  const page = document.getElementById("page");
  page.innerHTML = `
    ${pageHead("Moderasi Pemilik", "Riwayat Review", "Semua keputusan approve / reject beserta catatan dan aktor.")}
    <div id="list" class="card mt-4 overflow-hidden"></div>
    <div id="pager" class="mt-4 flex items-center justify-center gap-2"></div>`;
  let pg = 1;
  async function load() {
    try {
      const r = await Api.get(`/api/reviews/history?page=${pg}&limit=20`);
      document.getElementById("list").innerHTML = `
        <table class="tbl w-full"><thead><tr><th>Judul</th><th>Jenis</th><th>Keputusan</th><th>Oleh</th><th>Waktu</th></tr></thead>
        <tbody>${r.items.map((a) => `<tr>
          <td data-l="Judul"><strong>${esc(a.title)}</strong><br><span class="text-[11.5px] text-slate-500">${esc(a.note || "")}</span></td>
          <td data-l="Jenis">${a.kind === "delete" ? "Hapus" : "Terbit"}</td>
          <td data-l="Keputusan">${statusBadge(a.decision === "approved" ? "approved" : "rejected")}</td>
          <td data-l="Oleh">${esc(a.decided_by)}</td>
          <td data-l="Waktu" class="whitespace-nowrap">${fmtDate(a.decided_at)}</td></tr>`).join("") || `<tr><td colspan="5" class="text-center text-slate-400 py-6">Belum ada riwayat.</td></tr>`}</tbody></table>`;
      const pages = Math.max(1, Math.ceil(r.total / r.limit));
      document.getElementById("pager").innerHTML = `<button class="btn btn-sec btn-sm" ${pg <= 1 ? "disabled" : ""} data-p="-1">←</button><span class="text-[12.5px] font-bold">${pg} / ${pages}</span><button class="btn btn-sec btn-sm" ${pg >= pages ? "disabled" : ""} data-p="1">→</button>`;
      document.getElementById("pager").querySelectorAll("[data-p]").forEach((b) => b.onclick = () => { pg += +b.dataset.p; load(); });
    } catch (e) { document.getElementById("list").innerHTML = `<p class="p-6 text-red-600 text-[13px]">${errMsg(e)}</p>`; }
  }
  load();
})();
