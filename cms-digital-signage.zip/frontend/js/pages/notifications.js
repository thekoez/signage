/* Notifikasi: daftar + tandai dibaca. */
(async () => {
  await Auth.init(true);
  await renderLayout("notifications");
  const page = document.getElementById("page");
  page.innerHTML = `
    ${pageHead("Utama", "Notifikasi", "Pengajuan review, hasil, layar offline, laporan mingguan.", `<button id="btnAll" class="btn btn-sec btn-sm">Tandai semua dibaca</button>`)}
    <div id="list" class="mt-4 space-y-2"></div>`;
  document.getElementById("btnAll").onclick = async () => {
    await Api.post("/api/notifications/read-all", {});
    load(); refreshBadges();
  };
  async function load() {
    try {
      const r = await Api.get("/api/notifications?limit=50");
      const icons = { review_requested: "fa-hourglass-half text-amber-600", review_decided: "fa-check text-emerald-600", delete_requested: "fa-trash text-red-500", delete_decided: "fa-trash text-slate-500", screen_offline: "fa-plug-circle-xmark text-red-600", report_ready: "fa-envelope text-sky-600", invite: "fa-paper-plane text-sky-600" };
      document.getElementById("list").innerHTML = r.items.length ? r.items.map((n) => `
        <article class="card p-3.5 flex gap-3 ${n.is_read ? "opacity-70" : ""}">
          <span class="w-9 h-9 rounded bg-slate-50 border border-slate-200 grid place-items-center shrink-0"><i class="fa-solid ${icons[n.kind] || "fa-bell"}"></i></span>
          <div class="flex-1 min-w-0"><p class="text-[13.5px] font-bold text-slate-900">${esc(n.title)}</p>
            <p class="text-[12.5px] text-slate-500">${esc(n.body || "")}</p>
            <p class="text-[11.5px] text-slate-400 mt-0.5">${relTime(n.created_at)}
            ${n.link ? ` · <a class="text-sky-700 font-bold hover:underline" href="${esc(n.link)}">Buka →</a>` : ""}</p></div>
          ${n.is_read ? "" : `<button class="btn btn-sec btn-sm self-start" data-rd="${n.id}">Tandai dibaca</button>`}
        </article>`).join("") : emptyState("fa-bell");
      document.getElementById("list").querySelectorAll("[data-rd]").forEach((b) => b.onclick = async () => {
        await Api.post(`/api/notifications/${b.dataset.rd}/read`, {});
        load(); refreshBadges();
      });
    } catch (e) { toast(errMsg(e), "error"); }
  }
  load();
})();
