/* Playlist: daftar, buat, editor item (tambah/hapus/geser), assign layar/grup. */
(async () => {
  await Auth.init(true);
  await renderLayout("playlists");
  const page = document.getElementById("page");
  const canEdit = ["owner", "staff"].includes(Auth.user.role);
  page.innerHTML = `
    ${pageHead("Kelola Tayang", "Playlist", "Susun urutan putar dan tentukan layar tujuan.", canEdit ? `<button id="btnNew" class="btn btn-pri btn-sm"><i class="fa-solid fa-plus"></i>Buat Playlist</button>` : "")}
    <div id="list" class="mt-4 grid md:grid-cols-2 gap-3"></div>`;
  document.getElementById("btnNew") && (document.getElementById("btnNew").onclick = async () => {
    const name = await inputModal({ title: "Playlist baru", label: "Nama playlist", placeholder: "cth. Loop Harian Lobi", required: true });
    if (!name) return;
    try {
      const pl = await Api.post("/api/playlists", { name });
      toast("Playlist dibuat.", "success");
      openEditor(pl.id);
    } catch (e) { toast(errMsg(e), "error"); }
  });

  async function load() {
    const list = document.getElementById("list");
    list.innerHTML = `<div class="skel h-40 rounded col-span-full"></div>`;
    try {
      const r = await Api.get("/api/playlists?limit=50");
      list.innerHTML = r.items.length ? r.items.map((p) => `
        <article class="card p-4">
          <div class="flex items-center gap-2"><h3 class="text-[15px] font-extrabold text-slate-900 flex-1 truncate">${esc(p.name)}</h3>${statusBadge(p.status)}</div>
          <p class="text-[12.5px] text-slate-500 mt-0.5">${p.item_count} item · transisi ${esc(p.transition)} · target: ${p.targets.length ? esc(p.targets.map((x) => x.name).join(", ")) : "belum di-assign"}</p>
          <div class="mt-2 flex gap-1.5 overflow-x-auto thin-scroll pb-1">
            ${p.items.slice(0, 6).map((it) => it.thumb_url ? `<img src="${it.thumb_url}" alt="" loading="lazy" class="w-16 h-10 object-cover rounded border border-slate-200">` : `<span class="w-16 h-10 rounded bg-slate-800 text-white grid place-items-center text-[10px] font-bold shrink-0">${esc(it.type)}</span>`).join("") || '<span class="text-[12px] text-slate-400">Kosong</span>'}
          </div>
          <div class="mt-3 flex flex-wrap gap-2">
            <button class="btn btn-sec btn-sm" data-ed="${p.id}"><i class="fa-solid fa-pen"></i>${canEdit ? "Kelola" : "Lihat"}</button>
            ${canEdit ? `<button class="btn btn-sec btn-sm" data-as="${p.id}"><i class="fa-solid fa-tv text-sky-600"></i>Assign</button>` : ""}
            ${canEdit ? `<button class="btn btn-sec btn-sm" data-del="${p.id}"><i class="fa-solid fa-trash text-red-500"></i></button>` : ""}
          </div>
        </article>`).join("") : emptyState("fa-list-ul", canEdit ? `<button class="btn btn-pri btn-sm" onclick="document.getElementById('btnNew').click()">Buat pertama</button>` : "");
      list.querySelectorAll("[data-ed]").forEach((b) => b.onclick = () => openEditor(b.dataset.ed));
      list.querySelectorAll("[data-as]").forEach((b) => b.onclick = () => openAssign(b.dataset.as));
      list.querySelectorAll("[data-del]").forEach((b) => b.onclick = async () => {
        if (!await confirmModal({ title: "Hapus playlist?", message: "Urutan putar ikut terhapus. Konten tidak ikut terhapus.", confirmText: "Ya, hapus", danger: true })) return;
        try { await Api.del("/api/playlists/" + b.dataset.del); toast("Playlist dihapus.", "success"); load(); }
        catch (e) { toast(errMsg(e), "error"); }
      });
    } catch (e) { list.innerHTML = `<div class="card p-6 text-center text-red-600 text-[13px] col-span-full">${errMsg(e)}</div>`; }
  }

  async function openEditor(pid) {
    let pl;
    try { pl = await Api.get("/api/playlists/" + pid); }
    catch (e) { toast(errMsg(e), "error"); return; }
    openModal("Playlist: " + pl.name, `
      <p class="text-[12.5px] text-slate-500 mb-3">Status: ${pl.status} ${pl.status === "approved" ? "(edit memicu approval ulang)" : ""} · drag tombol ↑↓ untuk urutan · durasi per item bisa dioverride.</p>
      <div id="edItems" class="space-y-2 max-h-72 overflow-y-auto thin-scroll"></div>
      ${canEdit ? `<div class="mt-3 border-t border-slate-200 pt-3">
        <p class="text-[12px] font-bold text-slate-700">Tambah konten (hanya approved)</p>
        <div class="mt-1.5 flex gap-2"><select id="addSel" class="inp flex-1"></select>
        <button id="addBtn" class="btn btn-pri btn-sm shrink-0">Tambah</button></div>
        <button id="subBtn" class="btn btn-sec btn-sm mt-2">Ajukan Review Playlist</button>
      </div>` : ""}`, async (body) => {
      const paint = (items) => {
        body.querySelector("#edItems").innerHTML = items.length ? items.map((it, i) => `
          <div class="flex items-center gap-2 border border-slate-200 rounded p-2">
            <span class="font-mono text-[12px] font-bold text-slate-400 w-6">${i + 1}</span>
            ${it.thumb_url ? `<img src="${it.thumb_url}" class="w-14 h-9 object-cover rounded" alt="">` : ""}
            <div class="flex-1 min-w-0"><p class="text-[13px] font-bold truncate">${esc(it.title)}</p>
            <p class="text-[11.5px] text-slate-500">${it.duration_sec} dtk ${it.status !== "approved" ? "· " + it.status : ""}</p></div>
            ${canEdit ? `<button class="btn btn-sec btn-sm" data-mv="-1" data-id="${it.item_id}" ${i === 0 ? "disabled" : ""}>↑</button>
            <button class="btn btn-sec btn-sm" data-mv="1" data-id="${it.item_id}" ${i === items.length - 1 ? "disabled" : ""}>↓</button>
            <button class="btn btn-sec btn-sm" data-rm="${it.item_id}"><i class="fa-solid fa-xmark text-red-500"></i></button>` : ""}
          </div>`).join("") : `<p class="text-[13px] text-slate-400 text-center py-4">Belum ada item.</p>`;
        if (canEdit) {
          body.querySelectorAll("[data-mv]").forEach((b) => b.onclick = async () => {
            const ids = items.map((x) => x.item_id);
            const ix = ids.indexOf(b.dataset.rm || b.dataset.id);
            const j = ix + (+b.dataset.mv);
            [ids[ix], ids[j]] = [ids[j], ids[ix]];
            await Api.patch(`/api/playlists/${pid}/items/reorder`, { ordered_ids: ids });
            pl = await Api.get("/api/playlists/" + pid);
            paint(pl.items);
          });
          body.querySelectorAll("[data-rm]").forEach((b) => b.onclick = async () => {
            await Api.del(`/api/playlists/${pid}/items/${b.dataset.rm}`);
            pl = await Api.get("/api/playlists/" + pid);
            paint(pl.items); load();
          });
        }
      };
      paint(pl.items);
      if (canEdit) {
        const lib = await Api.get("/api/contents?status=approved&limit=100");
        body.querySelector("#addSel").innerHTML = lib.items.map((c) => `<option value="${c.id}">${esc(c.title)} (${c.type})</option>`).join("");
        body.querySelector("#addBtn").onclick = async () => {
          const cid = body.querySelector("#addSel").value;
          if (!cid) { toast("Tidak ada konten approved.", "warn"); return; }
          try {
            pl = await Api.post(`/api/playlists/${pid}/items`, { content_id: cid });
            paint(pl.items); load();
          } catch (e) { toast(errMsg(e), "error"); }
        };
        body.querySelector("#subBtn").onclick = async () => {
          try { await Api.post(`/api/playlists/${pid}/submit-review`, {}); toast("Diajukan review.", "success"); closeModal(); load(); }
          catch (e) { toast(errMsg(e), "error"); }
        };
      }
    });
  }

  async function openAssign(pid) {
    const [screens, groups] = await Promise.all([
      Api.get("/api/screens?limit=100"), Api.get("/api/screen-groups")]);
    openModal("Assign playlist ke layar", `
      <div class="grid md:grid-cols-2 gap-3">
        <div><p class="text-[12px] font-bold text-slate-700 mb-1">Per layar</p>
          <div class="space-y-1 max-h-56 overflow-y-auto thin-scroll">${screens.items.map((s) => `
            <button class="w-full text-left border border-slate-200 rounded px-2.5 py-2 hover:bg-sky-50 text-[13px]" data-s="${s.id}"><strong>${esc(s.name)}</strong><br><span class="text-[11.5px] text-slate-500">${esc(s.group_name)} · ${s.status}</span></button>`).join("")}</div></div>
        <div><p class="text-[12px] font-bold text-slate-700 mb-1">Per grup</p>
          <div class="space-y-1">${groups.items.map((g) => `
            <button class="w-full text-left border border-slate-200 rounded px-2.5 py-2 hover:bg-sky-50 text-[13px]" data-g="${g.id}"><strong>${esc(g.name)}</strong><br><span class="text-[11.5px] text-slate-500">${g.screen_count} layar</span></button>`).join("") || '<p class="text-slate-400 text-[13px]">Belum ada grup.</p>'}</div></div>
      </div>`, (body) => {
      const go = async (payload) => {
        try { await Api.post("/api/assignments", Object.assign({ playlist_id: pid }, payload)); closeModal(); toast("Playlist di-assign sebagai default.", "success"); load(); }
        catch (e) { toast(errMsg(e), "error"); }
      };
      body.querySelectorAll("[data-s]").forEach((b) => b.onclick = () => go({ screen_id: b.dataset.s }));
      body.querySelectorAll("[data-g]").forEach((b) => b.onclick = () => go({ group_id: b.dataset.g }));
    });
  }
  load();
})();
