/* Jadwal promo: kalender list + form (tanggal, jam, hari, prioritas) + konflik. */
(async () => {
  await Auth.init(true);
  await renderLayout("schedules");
  const page = document.getElementById("page");
  const canEdit = ["owner", "staff"].includes(Auth.user.role);
  page.innerHTML = `
    ${pageHead("Kelola Tayang", "Jadwal Promo", "Promo/event menimpa loop default sementara. Prioritas tertinggi menang.", canEdit ? `<button id="btnNew" class="btn btn-pri btn-sm"><i class="fa-solid fa-plus"></i>Jadwal Baru</button>` : "")}
    <div id="warn"></div>
    <div id="list" class="mt-4 space-y-3"></div>`;
  if (canEdit) document.getElementById("btnNew").onclick = () => openForm(null);

  async function load() {
    const list = document.getElementById("list");
    list.innerHTML = `<div class="skel h-32 rounded"></div>`;
    try {
      const r = await Api.get("/api/schedules");
      const now = new Date().toISOString();
      const active = r.items.filter((s) => s.is_active && s.starts_at <= now && s.ends_at >= now);
      const conflictNames = new Set();
      document.getElementById("warn").innerHTML = "";
      list.innerHTML = r.items.length ? r.items.map((s) => {
        const isActive = s.is_active && s.starts_at <= now && s.ends_at >= now;
        return `<article class="card p-4 ${!s.is_active ? "opacity-60" : ""}">
        <div class="flex flex-wrap items-center gap-2">
          <span class="text-[10px] font-bold px-1.5 py-0.5 rounded ${s.priority >= 10 ? "bg-sky-600 text-white" : "bg-slate-100 text-slate-600 border border-slate-200"}">PRIORITAS ${s.priority}</span>
          ${isActive ? `<span class="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">AKTIF SEKARANG</span>` : ""}
          ${!s.is_active ? `<span class="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-500 border">NONAKTIF</span>` : ""}
          <span class="ml-auto font-mono text-[11.5px] text-slate-500">${fmtDate(s.starts_at)} → ${fmtDate(s.ends_at)}</span>
        </div>
        <h3 class="mt-1.5 text-[15px] font-extrabold text-slate-900">${esc(s.name)}</h3>
        <p class="text-[12.5px] text-slate-600">${esc(s.playlist_name)} → <strong>${esc(s.target)}</strong>${s.daily_start ? ` · ${s.daily_start}–${s.daily_end}` : " · seharian"}${s.days_of_week ? ` · hari ${s.days_of_week.join(",")}` : ""}</p>
        ${canEdit ? `<div class="mt-2.5 flex gap-2">
          <button class="btn btn-sec btn-sm" data-ed="${s.id}">Ubah</button>
          <button class="btn btn-sec btn-sm" data-tg="${s.id}">${s.is_active ? "Nonaktifkan" : "Aktifkan"}</button>
          <button class="btn btn-sec btn-sm" data-del="${s.id}"><i class="fa-solid fa-trash text-red-500"></i></button>
        </div>` : ""}
      </article>`; }).join("") : emptyState("fa-calendar-days", canEdit ? `<button class="btn btn-pri btn-sm" onclick="document.getElementById('btnNew').click()">Buat jadwal</button>` : "");
      if (canEdit) {
        list.querySelectorAll("[data-ed]").forEach((b) => b.onclick = () => openForm(b.dataset.ed));
        list.querySelectorAll("[data-tg]").forEach((b) => b.onclick = async () => {
          const cur = r.items.find((x) => x.id === b.dataset.tg);
          await Api.patch("/api/schedules/" + b.dataset.tg, { is_active: !cur.is_active });
          load();
        });
        list.querySelectorAll("[data-del]").forEach((b) => b.onclick = async () => {
          if (!await confirmModal({ title: "Hapus jadwal?", message: "Player kembali ke loop default.", confirmText: "Ya, hapus", danger: true })) return;
          await Api.del("/api/schedules/" + b.dataset.del);
          toast("Jadwal dihapus.", "success"); load();
        });
      }
    } catch (e) { list.innerHTML = `<div class="card p-6 text-center text-red-600 text-[13px]">${errMsg(e)}</div>`; }
  }

  async function openForm(sid) {
    let cur = null;
    if (sid) {
      const all = await Api.get("/api/schedules");
      cur = all.items.find((x) => x.id === sid);
    }
    const [pls, screens, groups] = await Promise.all([
      Api.get("/api/playlists?limit=100"), Api.get("/api/screens?limit=100"), Api.get("/api/screen-groups")]);
    const dt = (iso) => iso ? iso.slice(0, 16) : "";
    openModal(sid ? "Ubah jadwal" : "Jadwal promo baru", `
      <div class="grid md:grid-cols-2 gap-3">
        <div class="md:col-span-2"><label class="text-[12px] font-bold" for="sName">Nama jadwal</label>
          <input id="sName" class="inp mt-1" value="${esc(cur?.name || "")}" placeholder="cth. Promo Akhir Pekan"></div>
        <div><label class="text-[12px] font-bold" for="sPl">Playlist promo</label>
          <select id="sPl" class="inp mt-1 w-full">${pls.items.map((p) => `<option value="${p.id}" ${cur?.playlist_id === p.id ? "selected" : ""}>${esc(p.name)}</option>`).join("")}</select></div>
        <div><label class="text-[12px] font-bold" for="sTgt">Target layar / grup</label>
          <select id="sTgt" class="inp mt-1 w-full">
            ${screens.items.map((s) => `<option value="s:${s.id}" ${cur?.screen_id === s.id ? "selected" : ""}>${esc(s.name)}</option>`).join("")}
            ${groups.items.map((g) => `<option value="g:${g.id}" ${cur?.group_id === g.id ? "selected" : ""}>Grup: ${esc(g.name)}</option>`).join("")}
          </select></div>
        <div><label class="text-[12px] font-bold" for="sFrom">Mulai</label><input id="sFrom" type="datetime-local" class="inp mt-1" value="${dt(cur?.starts_at)}"></div>
        <div><label class="text-[12px] font-bold" for="sTo">Selesai</label><input id="sTo" type="datetime-local" class="inp mt-1" value="${dt(cur?.ends_at)}"></div>
        <div><label class="text-[12px] font-bold" for="sDs">Jam harian (opsional)</label>
          <div class="flex gap-2 mt-1"><input id="sDs" type="time" class="inp" value="${cur?.daily_start || ""}"><input id="sDe" type="time" class="inp" value="${cur?.daily_end || ""}"></div></div>
        <div><label class="text-[12px] font-bold" for="sPr">Prioritas (tertinggi menang)</label>
          <input id="sPr" type="number" class="inp mt-1" value="${cur?.priority ?? 0}"></div>
        <div class="md:col-span-2"><span class="text-[12px] font-bold">Hari (kosong = semua)</span>
          <div id="sDays" class="mt-1 flex flex-wrap gap-1.5">${[1, 2, 3, 4, 5, 6, 7].map((d) => `
            <label class="text-[12.5px] font-bold border border-slate-200 rounded px-2.5 py-1.5 cursor-pointer has-[:checked]:bg-sky-600 has-[:checked]:text-white has-[:checked]:border-sky-600">
            <input type="checkbox" value="${d}" class="sr-only" ${cur?.days_of_week?.includes(d) ? "checked" : ""}>${["Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min"][d - 1]}</label>`).join("")}</div></div>
      </div>
      <button id="sSave" class="btn btn-pri w-full mt-4">Simpan jadwal</button>`, (body) => {
      body.querySelector("#sSave").onclick = async () => {
        const tgt = body.querySelector("#sTgt").value.split(":");
        const days = [...body.querySelectorAll("#sDays input:checked")].map((x) => +x.value);
        const payload = {
          name: body.querySelector("#sName").value.trim(),
          playlist_id: body.querySelector("#sPl").value,
          screen_id: tgt[0] === "s" ? tgt[1] : null,
          group_id: tgt[0] === "g" ? tgt[1] : null,
          starts_at: new Date(body.querySelector("#sFrom").value).toISOString(),
          ends_at: new Date(body.querySelector("#sTo").value).toISOString(),
          daily_start: body.querySelector("#sDs").value || null,
          daily_end: body.querySelector("#sDe").value || null,
          days_of_week: days.length ? days : null,
          priority: +body.querySelector("#sPr").value || 0,
        };
        if (!payload.name) { toast("Nama wajib diisi.", "warn"); return; }
        try {
          const r = sid ? await Api.patch("/api/schedules/" + sid, payload)
            : await Api.post("/api/schedules", payload);
          closeModal(); load();
          if (r.conflicts && r.conflicts.length) {
            toast(`Tersimpan, tapi bertabrakan dengan: ${r.conflicts.map((c) => c.name).join(", ")}. Pemenang: prioritas tertinggi.`, "warn");
          } else toast("Jadwal tersimpan.", "success");
        } catch (e) { toast(errMsg(e), "error"); }
      };
    });
  }
  load();
})();
