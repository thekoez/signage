/* Profil saya: nama, avatar, ganti password, kelola 2FA + backup codes. */
(async () => {
  await Auth.init(true);
  await renderLayout("profile");
  const page = document.getElementById("page");
  const u = Auth.user;
  page.innerHTML = `
    ${pageHead("Akun", "Profil Saya", "Kelola identitas, kata sandi, dan autentikasi dua faktor.")}
    <div class="mt-4 grid md:grid-cols-2 gap-3 items-start">
      <section class="card p-5">
        <h2 class="text-[14px] font-extrabold">Identitas</h2>
        <div class="mt-3 space-y-2.5">
          <div><label class="text-[12px] font-bold" for="pName">Nama</label><input id="pName" class="inp mt-1" value="${esc(u.name)}"></div>
          <div><label class="text-[12px] font-bold">Email</label><input class="inp mt-1 bg-slate-50" value="${esc(u.email)}" disabled></div>
          <div><label class="text-[12px] font-bold" for="pAv">Avatar URL (opsional)</label><input id="pAv" class="inp mt-1" value="${esc(u.avatar_url || "")}"></div>
          <button id="btnProfile" class="btn btn-pri btn-sm">Simpan profil</button>
        </div>
        <h2 class="mt-5 text-[14px] font-extrabold">Ganti kata sandi</h2>
        <div class="mt-2 space-y-2.5">
          <input id="pwOld" type="password" class="inp" placeholder="Kata sandi lama" autocomplete="current-password">
          <input id="pwNew" type="password" class="inp" placeholder="Baru (min. 8)" autocomplete="new-password">
          <button id="btnPw" class="btn btn-sec btn-sm">Ganti kata sandi</button>
        </div>
      </section>
      <section class="card p-5">
        <h2 class="text-[14px] font-extrabold flex items-center gap-2"><i class="fa-solid fa-shield-halved text-sky-600"></i>Keamanan 2FA</h2>
        <div id="box2fa" class="mt-3"></div>
      </section>
    </div>`;
  document.getElementById("btnProfile").onclick = async () => {
    try {
      await Api.patch("/api/users/me", { name: document.getElementById("pName").value.trim(), avatar_url: document.getElementById("pAv").value.trim() });
      toast("Profil tersimpan.", "success");
      Auth.user = await Api.get("/api/users/me");
      renderLayout("profile").then(() => location.reload());
    } catch (e) { toast(errMsg(e), "error"); }
  };
  document.getElementById("btnPw").onclick = async () => {
    try {
      await Api.post("/api/users/change-password", { old_password: document.getElementById("pwOld").value, new_password: document.getElementById("pwNew").value });
      toast("Kata sandi diganti. Sesi lain ikut keluar.", "success");
    } catch (e) { toast(errMsg(e), "error"); }
  };
  async function load2fa() {
    const box = document.getElementById("box2fa");
    try {
      const s = await Api.get("/api/auth/2fa/status");
      box.innerHTML = s.enabled ? `
        <p class="text-[13px]"><span class="badge bg-emerald-50 text-emerald-700 border-emerald-200">AKTIF</span>
        <span class="text-slate-500 text-[12.5px]">sejak ${s.enrolled_at ? fmtDate(s.enrolled_at) : "-"} · sisa kode cadangan: <strong>${s.backup_remaining}</strong></span></p>
        ${s.required_by_policy ? `<p class="mt-1 text-[12px] text-amber-700 font-bold">Wajib oleh kebijakan — tidak dapat dinonaktifkan.</p>` : ""}
        <div class="mt-3 flex flex-wrap gap-2">
          <button id="btnRegen" class="btn btn-sec btn-sm">Regenerasi kode cadangan</button>
          ${s.required_by_policy ? "" : `<button id="btnOff" class="btn btn-sec btn-sm">Nonaktifkan 2FA</button>`}
        </div>
        <div id="codes" class="hidden mt-2 grid grid-cols-2 gap-1.5 font-mono text-[13px] font-bold"></div>` : `
        <p class="text-[13px] text-slate-500">Belum aktif. ${s.required_by_policy ? "<strong class='text-amber-700'>Wajib untuk akun Anda.</strong>" : "Sangat dianjurkan."}</p>
        <a href="/setup-2fa.html" class="btn btn-pri btn-sm mt-3">Aktifkan sekarang (≤ 5 langkah)</a>`;
      const regen = document.getElementById("btnRegen");
      if (regen) regen.onclick = async () => {
        const pw = await inputModal({ title: "Regenerasi kode", label: "Kata sandi Anda", placeholder: "••••••••", required: true });
        if (!pw) return;
        try {
          const r = await Api.post("/api/auth/2fa/backup-codes/regenerate", { password: pw });
          const c = document.getElementById("codes");
          c.innerHTML = r.backup_codes.map((x) => `<span class="bg-slate-50 border border-slate-200 rounded px-2 py-1 text-center">${x}</span>`).join("");
          c.classList.remove("hidden");
          toast("Batch lama hangus. Simpan yang baru!", "success");
          load2fa();
        } catch (e) { toast(errMsg(e), "error"); }
      };
      const off = document.getElementById("btnOff");
      if (off) off.onclick = async () => {
        const pw = await inputModal({ title: "Nonaktifkan 2FA", label: "Kata sandi Anda", required: true });
        if (!pw) return;
        const code = await inputModal({ title: "Nonaktifkan 2FA", label: "Kode authenticator terakhir", required: true });
        if (!code) return;
        try { await Api.post("/api/auth/2fa/disable", { password: pw, code }); toast("2FA nonaktif.", "success"); load2fa(); }
        catch (e) { toast(errMsg(e), "error"); }
      };
    } catch (e) { box.innerHTML = `<p class="text-red-600 text-[13px]">${errMsg(e)}</p>`; }
  }
  load2fa();
})();
