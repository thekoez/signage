/* Media Library: grid, filter, upload drag-drop + progres, teks, detail, review, hapus. */
(async () => {
  await Auth.init(true);
  await renderLayout("contents");
  const page = document.getElementById("page");
  const canEdit = ["owner", "staff"].includes(Auth.user.role);
  const q0 = new URLSearchParams(location.search).get("q") || "";
  page.innerHTML = `
    ${pageHead("Kelola Tayang", "Media Library", "Upload, cari, pratinjau, dan kelola gambar, video, dan teks.", canEdit ? `
      <button id="btnUpload" class="btn btn-sec btn-sm"><i class="fa-solid fa-upload text-sky-600"></i>Upload File</button>
      <button id="btnText" class="btn btn-pri btn-sm"><i class="fa-solid fa-font"></i>Teks / Pengumuman</button>` : "")}
    <div class="card mt-4 p-3 flex flex-wrap gap-2 items-center">
      <div class="relative flex-1 min-w-[180px]">
        <i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs"></i>
        <input id="fQ" value="${esc(q0)}" placeholder="Cari judul…" class="inp pl-9">
      </div>
      <select id="fType" class="inp"><option value="">Semua tipe</option>
        <option value="image">Gambar</option><option value="video">Video</option>
        <option value="ticker">Teks berjalan</option><option value="notice">Pengumuman</option></select>
      <select id="fStatus" class="inp"><option value="">Semua status</option>
        <option value="draft">Draft</option><option value="pending_review">Menunggu</option>
        <option value="approved">Disetujui</option><option value="rejected">Ditolak</option>
        <option value="pending_delete">Minta hapus</option><option value="archived">Arsip</option></select>
      <button id="btnMine" class="btn btn-sec btn-sm">Milik saya</button>
    </div>
    <p id="count" class="mt-3 text-[12.5px] text-slate-500"></p>
    <div id="grid" class="mt-2 grid sm:grid-cols-2 xl:grid-cols-3 gap-3"></div>
    <div id="pager" class="mt-4 flex items-center justify-center gap-2"></div>`;

  let state = { q: q0, type: "", status: "", mine: false, page: 1 };
  const grid = document.getElementById("grid");

  async function load() {
    grid.innerHTML = `<div class="skel h-40 rounded col-span-full"></div>`;
    const p = new URLSearchParams({ page: state.page, limit: 12 });
    if (state.q) p.set("q", state.q);
    if (state.type) p.set("type", state.type);
    if (state.status) p.set("status", state.status);
    if (state.mine) p.set("mine", "true");
    try {
      const r = await Api.get("/api/contents?" + p);
      document.getElementById("count").textContent = `${r.total} konten · hal. ${r.page}`;
      grid.innerHTML = r.items.length ? r.items.map(card).join("") : emptyState("fa-images", canEdit ? `<button class="btn btn-pri btn-sm" onclick="document.getElementById('btnUpload').click()">Upload pertama</button>` : "");
      grid.querySelectorAll("[data-open]").forEach((el) => el.onclick = () => openDetail(el.dataset.open));
      const pages = Math.max(1, Math.ceil(r.total / r.limit));
      document.getElementById("pager").innerHTML = `
        <button class="btn btn-sec btn-sm" ${r.page <= 1 ? "disabled" : ""} data-pg="-1">←</button>
        <span class="text-[12.5px] font-bold text-slate-600">${r.page} / ${pages}</span>
        <button class="btn btn-sec btn-sm" ${r.page >= pages ? "disabled" : ""} data-pg="1">→</button>`;
      document.getElementById("pager").querySelectorAll("[data-pg]").forEach((b) => b.onclick = () => { state.page += +b.dataset.pg; load(); });
    } catch (e) {
      grid.innerHTML = `<div class="card p-6 text-center text-[13px] text-red-600 col-span-full">${errMsg(e)} <button class="btn btn-sec btn-sm ml-2" onclick="location.reload()">Muat ulang</button></div>`;
    }
  }
  function card(c) {
    const thumb = c.thumb_url ? `<img src="${c.thumb_url}" alt="" loading="lazy" class="w-full h-32 object-cover">`
      : c.type === "ticker" ? `<div class="w-full h-32 bg-red-600 text-white grid place-items-center p-3 text-center text-[13px] font-bold ticker-wrap"><span class="ticker-move">${esc((c.text_payload || {}).text || "")}</span></div>`
      : c.type === "notice" ? `<div class="w-full h-32 grid place-items-center p-3 text-center text-[13px] font-bold" style="background:${esc((c.text_payload || {}).bg_color || "#0369A1")};color:#fff">${esc((c.text_payload || {}).text || c.title).slice(0, 60)}</div>`
      : `<div class="w-full h-32 bg-slate-800 text-white grid place-items-center"><i class="fa-solid fa-film"></i></div>`;
    return `<article class="card overflow-hidden hover:shadow-md transition cursor-pointer" data-open="${c.id}">
      <div class="relative">${thumb}
        <span class="absolute top-2 left-2 text-[10px] font-bold px-1.5 py-0.5 rounded bg-black/50 text-white uppercase">${c.type}</span>
        <span class="absolute bottom-2 right-2 font-mono text-[10px] bg-black/50 text-white rounded px-1.5 py-0.5">${c.duration_sec} dtk</span></div>
      <div class="p-3"><p class="text-[13.5px] font-bold text-slate-900 truncate">${esc(c.title)}</p>
        <div class="mt-1.5 flex items-center gap-2">${statusBadge(c.status)}
        <span class="text-[11px] text-slate-400 ml-auto">v${c.version} · ${esc(c.creator_name)}</span></div></div>
    </article>`;
  }

  let deb;
  document.getElementById("fQ").oninput = (e) => { clearTimeout(deb); deb = setTimeout(() => { state.q = e.target.value; state.page = 1; load(); }, 350); };
  document.getElementById("fType").onchange = (e) => { state.type = e.target.value; state.page = 1; load(); };
  document.getElementById("fStatus").onchange = (e) => { state.status = e.target.value; state.page = 1; load(); };
  document.getElementById("btnMine").onclick = (e) => { state.mine = !state.mine; e.target.classList.toggle("btn-pri", state.mine); state.page = 1; load(); };

  if (canEdit) {
    document.getElementById("btnUpload").onclick = () => {
      openModal("Upload Konten", `
        <div id="dz" class="border-2 border-dashed border-slate-300 rounded p-8 text-center cursor-pointer hover:border-sky-500 hover:bg-sky-50/50">
          <i class="fa-solid fa-cloud-arrow-up text-3xl text-sky-600"></i>
          <p class="mt-2 text-[14px] font-bold text-slate-800">Seret file ke sini / klik untuk pilih</p>
          <p class="text-[12px] text-slate-500">JPG, PNG, WebP (maks 10 MB) · MP4, WebM (maks 200 MB)</p>
          <input id="fileIn" type="file" class="hidden" accept=".jpg,.jpeg,.png,.webp,.mp4,.webm">
        </div>
        <div class="mt-3 space-y-2">
          <div><label class="text-[12px] font-bold text-slate-700" for="upTitle">Judul</label><input id="upTitle" class="inp mt-1"></div>
          <div><label class="text-[12px] font-bold text-slate-700" for="upDur">Durasi tampil gambar (5–120 dtk)</label><input id="upDur" type="number" value="10" min="5" max="120" class="inp mt-1 w-32"></div>
        </div>
        <div id="prog" class="hidden mt-3"><div class="h-2 rounded bg-slate-100 overflow-hidden"><div id="bar" class="h-full w-0 bg-sky-600"></div></div>
        <p id="plabel" class="mt-1 text-[12px] text-slate-500">Mengunggah…</p></div>`, (body) => {
        const dz = body.querySelector("#dz"), fi = body.querySelector("#fileIn");
        dz.onclick = () => fi.click();
        dz.ondragover = (e) => { e.preventDefault(); dz.classList.add("border-sky-500"); };
        dz.ondrop = (e) => { e.preventDefault(); if (e.dataTransfer.files[0]) doUpload(e.dataTransfer.files[0], body); };
        fi.onchange = () => { if (fi.files[0]) doUpload(fi.files[0], body); };
      });
    };
    document.getElementById("btnText").onclick = () => {
      openModal("Buat Teks / Pengumuman", `
        <div class="grid md:grid-cols-2 gap-4">
          <div class="space-y-2">
            <div><label class="text-[12px] font-bold" for="tTitle">Judul</label><input id="tTitle" class="inp mt-1"></div>
            <div><label class="text-[12px] font-bold" for="tType">Tipe</label>
              <select id="tType" class="inp mt-1 w-full"><option value="ticker">Teks berjalan (bawah layar)</option><option value="notice">Pengumuman (fullscreen)</option></select></div>
            <div><label class="text-[12px] font-bold" for="tText">Isi teks</label><textarea id="tText" rows="3" class="inp mt-1"></textarea></div>
            <div class="grid grid-cols-2 gap-2">
              <div><label class="text-[12px] font-bold" for="tBg">Warna latar</label><input id="tBg" type="color" value="#E11D48" class="inp mt-1 h-10"></div>
              <div><label class="text-[12px] font-bold" for="tDur">Durasi (dtk)</label><input id="tDur" type="number" value="15" min="5" max="120" class="inp mt-1"></div>
            </div>
            <button id="tSave" class="btn btn-pri w-full">Simpan</button>
          </div>
          <div><p class="text-[12px] font-bold text-slate-500 mb-1">PRATINJAU 16:9</p>
            <div class="aspect-video bg-slate-900 rounded overflow-hidden relative">
              <div id="pvNotice" class="absolute inset-0 hidden items-center justify-center p-4 text-center font-bold text-white text-[15px]"></div>
              <div id="pvTick" class="absolute bottom-0 inset-x-0 py-1 text-white text-[13px] font-bold ticker-wrap"><span id="pvTickIn" class="ticker-move"></span></div>
            </div></div>
        </div>`, (body) => {
        const paint = () => {
          const txt = body.querySelector("#tText").value || "Contoh teks pengumuman…";
          const bg = body.querySelector("#tBg").value;
          const isTick = body.querySelector("#tType").value === "ticker";
          body.querySelector("#pvTick").style.display = isTick ? "" : "none";
          const nt = body.querySelector("#pvNotice");
          nt.style.display = isTick ? "none" : "flex";
          if (isTick) { body.querySelector("#pvTickIn").textContent = txt; body.querySelector("#pvTick").style.background = bg; }
          else { nt.textContent = txt; nt.style.background = bg; }
        };
        ["#tText", "#tBg", "#tType"].forEach((s) => body.querySelector(s).oninput = paint);
        paint();
        body.querySelector("#tSave").onclick = async () => {
          const title = body.querySelector("#tTitle").value.trim();
          const text = body.querySelector("#tText").value.trim();
          if (!title || !text) { toast("Judul & isi teks wajib diisi.", "warn"); return; }
          try {
            await Api.post("/api/contents/text", { title, type: body.querySelector("#tType").value,
              text_payload: { text, bg_color: body.querySelector("#tBg").value, fg_color: "#FFFFFF", speed: "normal", position: "bottom" },
              duration_sec: +body.querySelector("#tDur").value || 15 });
            closeModal(); toast("Teks tersimpan sebagai draft.", "success"); load();
          } catch (e) { toast(errMsg(e), "error"); }
        };
      });
    };
  }

  async function doUpload(file, body) {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("title", body.querySelector("#upTitle").value || file.name);
    fd.append("duration_sec", body.querySelector("#upDur").value || "10");
    body.querySelector("#prog").classList.remove("hidden");
    try {
      const xhr = new XMLHttpRequest();
      xhr.open("POST", "/api/contents/upload");
      if (Api.token) xhr.setRequestHeader("Authorization", "Bearer " + Api.token);
      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) body.querySelector("#bar").style.width = Math.round(100 * e.loaded / e.total) + "%";
      };
      await new Promise((res, rej) => {
        xhr.onload = () => xhr.status < 300 ? res() : rej(new Error(JSON.parse(xhr.responseText || "{}").detail || "Upload gagal"));
        xhr.onerror = () => rej(new Error("conn"));
        xhr.send(fd);
      });
      closeModal(); toast("Upload selesai + thumbnail dibuat.", "success"); load();
    } catch (e) {
      body.querySelector("#plabel").textContent = "Gagal: " + errMsg(e);
      toast(errMsg(e), "error");
    }
  }

  window.openDetail = async (id) => {
    let c;
    try { c = await Api.get("/api/contents/" + id); }
    catch (e) { toast(errMsg(e), "error"); return; }
    const prev = c.file_url ? (c.type === "video" ? `<video src="${c.file_url}" controls class="w-full aspect-video bg-black rounded"></video>` : `<img src="${c.file_url}" alt="" class="w-full aspect-video object-contain bg-slate-900 rounded">`)
      : `<div class="aspect-video rounded grid place-items-center text-white font-bold p-4 text-center" style="background:${esc(((c.text_payload || {}).bg_color) || "#0369A1")}">${esc(((c.text_payload || {}).text) || c.title)}</div>`;
    const canAct = canEdit && (Auth.user.role === "owner" || c.created_by === Auth.user.id);
    openModal(c.title, `
      <div class="grid md:grid-cols-2 gap-4">
        <div>${prev}
          <div class="mt-2 flex items-center gap-2">${statusBadge(c.status)}<span class="text-[11.5px] text-slate-500">v${c.version} · ${c.duration_sec} dtk · ${esc(c.creator_name)}</span></div>
          ${c.rejection_note ? `<p class="mt-2 text-[12.5px] bg-red-50 border border-red-200 rounded p-2 text-red-700">Catatan: ${esc(c.rejection_note)}</p>` : ""}
        </div>
        <div class="text-[13px] space-y-2">
          <p class="text-slate-500">Dipakai di: <strong class="text-slate-800">${c.used_in.playlist_items} playlist</strong>${c.used_in.playlists.length ? ` (${esc(c.used_in.playlists.join(", "))})` : ""}</p>
          <div><p class="font-bold text-slate-700">Riwayat review</p>
            <ul class="mt-1 space-y-1 max-h-32 overflow-y-auto thin-scroll">${c.reviews.map((r) => `<li class="text-[12px] text-slate-600">• ${r.kind}/${r.decision} — ${esc(r.note || "-")} <span class="text-slate-400">${relTime(r.created_at)}</span></li>`).join("") || '<li class="text-slate-400">Belum ada.</li>'}</ul></div>
          ${canAct ? `<div class="flex flex-wrap gap-2 pt-2">
            ${(c.status === "draft" || c.status === "rejected") ? `<button class="btn btn-pri btn-sm" data-a="submit">Ajukan Review</button>` : ""}
            ${["approved", "rejected", "draft"].includes(c.status) ? `<button class="btn btn-sec btn-sm" data-a="del">Minta Hapus</button>` : ""}
          </div>` : ""}
          ${Auth.user.role === "owner" && c.status === "pending_review" ? `<div class="flex gap-2 pt-2">
            <button class="btn btn-pri btn-sm" data-a="approve">Setujui</button>
            <button class="btn btn-sec btn-sm" data-a="reject">Tolak + catatan</button></div>` : ""}
          ${Auth.user.role === "owner" && c.status === "pending_delete" ? `<div class="flex gap-2 pt-2">
            <button class="btn btn-danger btn-sm" data-a="adel">Setujui Hapus</button>
            <button class="btn btn-sec btn-sm" data-a="rdel">Tolak Hapus</button></div>` : ""}
        </div>
      </div>`, (body) => {
      body.querySelectorAll("[data-a]").forEach((b) => b.onclick = async () => {
        const a = b.dataset.a;
        try {
          if (a === "submit") await Api.post(`/api/contents/${id}/submit-review`, {});
          if (a === "del") {
            const reason = await inputModal({ title: "Minta hapus konten?", label: "Alasan penghapusan", placeholder: "cth. Sudah kedaluwarsa", required: true });
            if (!reason) return;
            await Api.post(`/api/contents/${id}/request-delete`, { reason });
          }
          if (a === "approve") await Api.post(`/api/contents/${id}/approve`, {});
          if (a === "reject") {
            const note = await inputModal({ title: "Tolak konten", label: "Catatan revisi untuk staff", placeholder: "cth. Teks typo, resolusi kurang", required: true, multiline: true });
            if (!note) return;
            await Api.post(`/api/contents/${id}/reject`, { note });
          }
          if (a === "adel") {
            const ok = await confirmModal({ title: "Arsipkan konten?", message: "Konten hilang dari pilihan playlist. File disimpan 30 hari.", confirmText: "Ya, arsipkan", danger: true });
            if (!ok) return;
            await Api.post(`/api/contents/${id}/approve-delete`, {});
          }
          if (a === "rdel") await Api.post(`/api/contents/${id}/reject-delete`, { note: "Ditolak owner" });
          closeModal(); toast("Berhasil.", "success"); load();
        } catch (e) { toast(errMsg(e), "error"); }
      });
    });
  };
  load();
})();
