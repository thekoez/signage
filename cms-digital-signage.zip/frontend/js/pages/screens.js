/* Layar: daftar + filter, tambah, pairing, detail (aksi jarak jauh, token), grup. */
(async () => {
  await Auth.init(true);
  await renderLayout("screens");
  const page = document.getElementById("page");
  const canManage = ["owner", "teknisi"].includes(Auth.user.role);
  page.innerHTML = `
    ${pageHead("Kelola Tayang", "Layar & Grup", "Daftarkan TV baru via pairing code, pantau, dan kendalikan dari jauh.", canManage ? `
      <button id="btnAdd" class="btn btn-sec btn-sm"><i class="fa-solid fa-plus text-sky-600"></i>Tambah Layar</button>
      <button id="btnPair" class="btn btn-pri btn-sm"><i class="fa-solid fa-key"></i>Pairing</button>` : "")}
    <div class="mt-4 border-b border-slate-200 flex gap-1 text-[13px] font-bold">
      <button id="tabL" class="px-4 py-2.5 border-b-2 border-sky-600 text-sky-700">Layar</button>
      <button id="tabG" class="px-4 py-2.5 border-b-2 border-transparent text-slate-500">Grup & Lokasi</button>
    </div>
    <div id="paneL">
      <div class="card mt-3 p-3 flex flex-wrap gap-2 items-center">
        <div class="relative flex-1 min-w-[160px]"><i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs"></i>
          <input id="fQ" placeholder="Cari nama layar…" class="inp pl-9"></div>
        <select id="fS" class="inp"><option value="">Semua status</option><option value="online">Online</option><option value="offline">Offline</option><option value="disabled">Nonaktif</option></select>
      </div>
      <div id="list" class="mt-3 grid sm:grid-cols-2 xl:grid-cols-3 gap-3"></div>
    </div>
    <div id="paneG" class="hidden">
      <div id="glist" class="mt-3 grid sm:grid-cols-2 gap-3"></div>
    </div>`;
  document.getElementById("tabL").onclick = () => switchTab(true);
  document.getElementById("tabG").onclick = () => switchTab(false);
  function switchTab(isL) {
    document.getElementById("paneL").classList.toggle("hidden", !isL);
    document.getElementById("paneG").classList.toggle("hidden", isL);
    document.getElementById("tabL").className = "px-4 py-2.5 border-b-2 " + (isL ? "border-sky-600 text-sky-700" : "border-transparent text-slate-500");
    document.getElementById("tabG").className = "px-4 py-2.5 border-b-2 " + (!isL ? "border-sky-600 text-sky-700" : "border-transparent text-slate-500");
    if (!isL) loadGroups();
  }

  let fQ = "", fS = "";
  document.getElementById("fQ").oninput = (e) => { fQ = e.target.value; load(); };
  document.getElementById("fS").onchange = (e) => { fS = e.target.value; load(); };

  async function load() {
    const list = document.getElementById("list");
    const p = new URLSearchParams({ limit: 50 });
    if (fQ) p.set("q", fQ);
    if (fS) p.set("status", fS);
    try {
      const r = await Api.get("/api/screens?" + p);
      list.innerHTML = r.items.length ? r.items.map((s) => `
        <article class="card overflow-hidden">
          <div class="p-3.5 flex items-center gap-2.5">
            <span class="w-9 h-9 rounded ${s.status === "online" ? "bg-emerald-50 border-emerald-200 text-emerald-600" : s.status === "offline" ? "bg-red-50 border-red-200 text-red-600" : "bg-slate-100 border-slate-200 text-slate-400"} border grid place-items-center shrink-0"><i class="fa-solid fa-tv"></i></span>
            <div class="flex-1 min-w-0"><p class="text-[13.5px] font-bold text-slate-900 truncate">${esc(s.name)}</p>
            <p class="text-[11.5px] text-slate-500">${esc(s.group_name)} · ${s.orientation} · ${s.last_heartbeat_at ? relTime(s.last_heartbeat_at) : "belum pernah"}</p></div>
            ${statusBadge(s.status)}
          </div>
          <div class="px-3.5 pb-3.5 flex gap-1.5">
            <button class="btn btn-sec btn-sm flex-1" data-d="${s.id}">Detail</button>
            ${canManage ? `<button class="btn btn-sec btn-sm flex-1" data-cmd="identify" data-id="${s.id}">Identifikasi</button>
            <button class="btn btn-sec btn-sm flex-1" data-cmd="reload" data-id="${s.id}">Reload</button>` : ""}
          </div>
        </article>`).join("") : emptyState("fa-tv", canManage ? `<button class="btn btn-pri btn-sm" onclick="document.getElementById('btnAdd').click()">Tambah layar</button>` : "");
      list.querySelectorAll("[data-d]").forEach((b) => b.onclick = () => openDetail(b.dataset.d));
      list.querySelectorAll("[data-cmd]").forEach((b) => b.onclick = () => sendCmd(b.dataset.id, b.dataset.cmd));
    } catch (e) { list.innerHTML = `<div class="card p-6 text-center text-red-600 text-[13px] col-span-full">${errMsg(e)}</div>`; }
  }

  async function sendCmd(id, cmd) {
    try {
      await Api.post(`/api/screens/${id}/commands`, { command: cmd });
      toast(cmd === "identify" ? "Nama layar berkedip di TV ≤ 5 dtk." : "Perintah reload dikirim.", "success");
    } catch (e) { toast(errMsg(e), "error"); }
  }

  async function openDetail(id) {
    let s;
    try { s = await Api.get("/api/screens/" + id); }
    catch (e) { toast(errMsg(e), "error"); return; }
    openModal(s.name, `
          <div class="grid md:grid-cols-2 gap-4 text-[13px]">
        <div>
          <p class="text-slate-500">Grup: <strong class="text-slate-800">${esc(s.group_name)}</strong> · ${esc(s.location_detail || "-")} · ${s.orientation} · ${s.resolution}</p>
          <p class="mt-1">Status: ${statusBadge(s.status)} · heartbeat: ${s.last_heartbeat_at ? fmtDate(s.last_heartbeat_at) : "-"}</p>
          <div class="mt-2"><p class="font-bold">Playlist aktif: ${esc(s.active_playlist?.name || "-")}</p>
            <ol class="mt-1 space-y-1">${(s.queue_next || []).map((q, i) => `<li class="border border-slate-200 rounded px-2 py-1.5 flex gap-2 items-center">${q.thumb_url ? `<img src="${q.thumb_url}" class="w-12 h-8 object-cover rounded" alt="">` : ""}<span class="flex-1 truncate"><strong>${i + 1}.</strong> ${esc(q.title)} (${q.duration_sec} dtk)</span></li>`).join("") || '<li class="text-slate-400">Tidak ada antrean.</li>'}</ol></div>
          <p class="mt-2 text-slate-500">Heartbeat 24 jam: <strong class="text-slate-800">${s.heartbeats_24h.length} sinyal</strong> · Now playing: <strong>${esc(s.now_playing?.title || "-")}</strong></p>
        </div>
        ${canManage ? `<div class="space-y-2">
          <p class="font-bold text-slate-700">Aksi jarak jauh</p>
          <div class="flex flex-wrap gap-2">
            <button class="btn btn-dark btn-sm" data-c="reload"><i class="fa-solid fa-rotate-right"></i>Reload</button>
            <button class="btn btn-sec btn-sm" data-c="identify">Identifikasi 10 dtk</button>
            <button class="btn btn-sec btn-sm" data-c="refresh_manifest">Refresh jadwal</button>
          </div>
          <p class="font-bold text-slate-700 pt-2">Perangkat</p>
          <div class="flex flex-wrap gap-2">
            <button class="btn btn-sec btn-sm" data-c="copy">Salin URL player</button>
            ${Auth.user.role === "owner" ? `<button class="btn btn-sec btn-sm" data-c="retoken">Regenerasi token</button>` : ""}
            <button class="btn btn-sec btn-sm" data-c="toggle">${s.is_enabled ? "Nonaktifkan" : "Aktifkan"}</button>
          </div>
          <p class="text-[11.5px] text-slate-500">URL player butuh token device (tampil sekali saat daftar/regenerasi).</p>
          <p id="tokOut" class="font-mono text-[12px] bg-slate-50 border border-slate-200 rounded p-2 break-all hidden"></p>
        </div>` : ""}
      </div>`, (body) => {
      const bad = body.querySelector('a[href="/player/?token=Del"]');
      if (bad) bad.remove();
      body.querySelectorAll("[data-c]").forEach((b) => b.onclick = async () => {
        const c = b.dataset.c;
        try {
          if (["reload", "identify", "refresh_manifest"].includes(c)) { await sendCmd(id, c); }
          if (c === "copy") {
            const tok = await inputModal({ title: "Salin URL player", label: "Tempel token device layar ini", placeholder: "scr_..." });
            if (tok) { await navigator.clipboard.writeText(location.origin + "/player/?token=" + tok.trim()); toast("URL player disalin.", "success"); }
          }
          if (c === "retoken") {
            if (!await confirmModal({ title: "Regenerasi token?", message: "Token lama di TV langsung hangus. Tempel token baru ke TV.", confirmText: "Ya, regenerasi", danger: true })) return;
            const r = await Api.post(`/api/screens/${id}/regenerate-token`, {});
            const o = body.querySelector("#tokOut");
            o.textContent = "Token baru (salin sekarang): " + r.device_token;
            o.classList.remove("hidden");
          }
          if (c === "toggle") {
            await Api.patch(`/api/screens/${id}/enable`, { is_enabled: !s.is_enabled });
            closeModal(); toast("Status layar diubah.", "success"); load();
          }
        } catch (e) { toast(errMsg(e), "error"); }
      });
    });
  }
  async function loadGroups() {
    const gl = document.getElementById("glist");
    try {
      const r = await Api.get("/api/screen-groups");
      gl.innerHTML = (Auth.user.role === "owner" ? `<button id="btnG" class="card p-4 border-dashed text-center text-sky-700 font-bold text-[13px] hover:bg-sky-50"><i class="fa-solid fa-plus mr-1"></i>Grup baru</button>` : "")
        + r.items.map((g) => `<article class="card p-4">
          <h3 class="text-[14px] font-extrabold">${esc(g.name)}</h3>
          <p class="text-[12px] text-slate-500">${esc(g.location || "-")} · ${g.screen_count} layar</p>
          ${Auth.user.role === "owner" ? `<div class="mt-2 flex gap-2"><button class="btn btn-sec btn-sm" data-gd="${g.id}"><i class="fa-solid fa-trash text-red-500"></i></button></div>` : ""}
        </article>`).join("");
      const b = document.getElementById("btnG");
      if (b) b.onclick = async () => {
        const name = await inputModal({ title: "Grup baru", label: "Nama grup", placeholder: "cth. Lobi", required: true });
        if (!name) return;
        const loc = await inputModal({ title: "Grup baru", label: "Lokasi", placeholder: "cth. Gedung A Lt.1" });
        try { await Api.post("/api/screen-groups", { name, location: loc || "" }); loadGroups(); toast("Grup dibuat.", "success"); }
        catch (e) { toast(errMsg(e), "error"); }
      };
      gl.querySelectorAll("[data-gd]").forEach((x) => x.onclick = async () => {
        if (!await confirmModal({ title: "Hapus grup?", message: "Layar di dalamnya tidak ikut terhapus.", confirmText: "Ya, hapus", danger: true })) return;
        await Api.del("/api/screen-groups/" + x.dataset.gd);
        loadGroups();
      });
    } catch (e) { gl.innerHTML = `<div class="card p-6 text-red-600 text-[13px]">${errMsg(e)}</div>`; }
  }

  if (canManage) {
    document.getElementById("btnAdd").onclick = async () => {
      const groups = await Api.get("/api/screen-groups");
      openModal("Tambah Layar", `
        <div class="space-y-2">
          <div><label class="text-[12px] font-bold" for="nName">Nama layar</label><input id="nName" class="inp mt-1" placeholder="cth. Lobi Lt.1 - TV 01"></div>
          <div class="grid grid-cols-2 gap-2">
            <div><label class="text-[12px] font-bold" for="nGrp">Grup</label><select id="nGrp" class="inp mt-1 w-full"><option value="">—</option>${groups.items.map((g) => `<option value="${g.id}">${esc(g.name)}</option>`).join("")}</select></div>
            <div><label class="text-[12px] font-bold" for="nOri">Orientasi</label><select id="nOri" class="inp mt-1 w-full"><option value="landscape">Landscape</option><option value="portrait">Portrait</option></select></div>
          </div>
          <button id="nSave" class="btn btn-pri w-full">Daftarkan layar</button>
          <p class="text-[12px] text-slate-500">Alternatif cepat: buat <strong>kode pairing</strong> lalu klaim dari TV.</p>
        </div>`, (body) => {
        body.querySelector("#nSave").onclick = async () => {
          const name = body.querySelector("#nName").value.trim();
          if (!name) { toast("Nama wajib diisi.", "warn"); return; }
          try {
            const s = await Api.post("/api/screens", { name, group_id: body.querySelector("#nGrp").value || null, orientation: body.querySelector("#nOri").value });
            openModal("Layar terdaftar", `
              <p class="text-[13px]">Buka di TV: <span class="font-mono font-bold">${location.origin}/player/</span></p>
              <p class="mt-2 text-[13px] font-bold">Token device (tampil sekali!):</p>
              <p class="font-mono text-[13px] bg-slate-900 text-emerald-300 rounded p-3 break-all select-all">${s.device_token}</p>
              <p class="mt-2 text-[12px] text-slate-500">Tempel sebagai <span class="font-mono">/player/?token=...</span> di browser TV.</p>`);
            load();
          } catch (e) { toast(errMsg(e), "error"); }
        };
      });
    };
    document.getElementById("btnPair").onclick = async () => {
      try {
        const r = await Api.post("/api/screens/pairing-code", {});
        const code = await inputModal({ title: `Kode pairing: ${r.code.slice(0, 3)} ${r.code.slice(3)}`, label: "Klaim ke layar baru — masukkan nama layar lalu Enter kode dikonfirmasi otomatis", placeholder: "Nama layar baru (opsional)" });
        const payload = { code: r.code };
        if (code) payload.name = code;
        const s = await Api.post("/api/screens/claim", payload);
        toast(`Layar “${s.name}” terdaftar.`, "success");
        if (s.device_token) {
          openModal("Token device", `<p class="font-mono text-[13px] bg-slate-900 text-emerald-300 rounded p-3 break-all select-all">${s.device_token}</p>`);
        }
        load();
      } catch (e) { toast(errMsg(e), "error"); }
    };
  }
  load();
})();
