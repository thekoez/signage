/* Audit log: jejak aksi + filter aksi/tanggal. */
(async () => {
  await Auth.init(true);
  if (Auth.user.role !== "owner") { location.href = "/dashboard/index.html"; return; }
  await renderLayout("audit");
  const page = document.getElementById("page");
  page.innerHTML = `
    ${pageHead("Laporan", "Audit Log", "Siapa-melakukan-apa. Retensi 180 hari, hanya Owner.")}
    <div class="card mt-4 p-3 flex flex-wrap gap-2 items-end">
      <div><label class="text-[11px] font-bold text-slate-500" for="fA">AKSI</label>
        <select id="fA" class="inp mt-0.5"><option value="">Semua</option>
        ${["login", "upload", "submit_review", "approve", "reject", "request_delete", "approve_delete", "assign", "screen_command", "2fa_enabled", "2fa_failed", "backup_used", "reset_2fa", "generate_report"].map((a) => `<option>${a}</option>`).join("")}</select></div>
      <button id="btnGo" class="btn btn-pri btn-sm">Filter</button>
    </div>
    <div class="card mt-3 overflow-hidden"><div class="overflow-x-auto"><table class="tbl w-full">
      <thead><tr><th>Waktu</th><th>Aktor</th><th>Aksi</th><th>Entitas</th><th>Detail</th></tr></thead>
      <tbody id="rows"></tbody></table></div>
      <div id="pager" class="p-3 flex items-center justify-center gap-2 border-t border-slate-200"></div></div>`;
  let pg = 1;
  async function load() {
    const a = document.getElementById("fA").value;
    try {
      const r = await Api.get(`/api/audit-logs?page=${pg}&limit=20${a ? "&action=" + a : ""}`);
      document.getElementById("rows").innerHTML = r.items.map((x) => `<tr>
        <td data-l="Waktu" class="whitespace-nowrap">${fmtDate(x.created_at)}</td>
        <td data-l="Aktor">${esc(x.actor)}</td>
        <td data-l="Aksi"><span class="font-mono text-[12px] bg-slate-100 rounded px-1.5 py-0.5">${esc(x.action)}</span></td>
        <td data-l="Entitas">${esc(x.entity_type)}${x.entity_id ? ` <span class="font-mono text-[11px] text-slate-400">${esc(String(x.entity_id).slice(0, 8))}</span>` : ""}</td>
        <td data-l="Detail" class="text-[12px] text-slate-500 max-w-[260px] truncate">${esc(JSON.stringify(x.meta || {}))}</td></tr>`).join("") || `<tr><td colspan="5" class="text-center text-slate-400 py-6">Tidak ada jejak.</td></tr>`;
      const pages = Math.max(1, Math.ceil(r.total / r.limit));
      document.getElementById("pager").innerHTML = `<button class="btn btn-sec btn-sm" ${pg <= 1 ? "disabled" : ""} data-p="-1">←</button><span class="text-[12.5px] font-bold">${pg} / ${pages}</span><button class="btn btn-sec btn-sm" ${pg >= pages ? "disabled" : ""} data-p="1">→</button>`;
      document.getElementById("pager").querySelectorAll("[data-p]").forEach((b) => b.onclick = () => { pg += +b.dataset.p; load(); });
    } catch (e) { toast(errMsg(e), "error"); }
  }
  document.getElementById("btnGo").onclick = () => { pg = 1; load(); };
  load();
})();
