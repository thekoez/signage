/* Laporan: filter tanggal/layar/konten + grafik + tabel + ekspor CSV. */
(async () => {
  await Auth.init(true);
  await renderLayout("reports");
  const page = document.getElementById("page");
  const isOwner = Auth.user.role === "owner";
  const today = new Date().toISOString().slice(0, 10);
  const week = new Date(Date.now() - 6 * 864e5).toISOString().slice(0, 10);
  page.innerHTML = `
    ${pageHead("Laporan", "Laporan Penayangan", "Bukti tayang per layar & konten. Hanya yang benar-benar diputar.", isOwner ? `<button id="btnCsvW" class="btn btn-sec btn-sm"><i class="fa-solid fa-download"></i>CSV Mingguan</button>` : "")}
    <div class="card mt-4 p-3 flex flex-wrap gap-2 items-end">
      <div><label class="text-[11px] font-bold text-slate-500" for="fFrom">DARI</label><input id="fFrom" type="date" value="${week}" class="inp mt-0.5"></div>
      <div><label class="text-[11px] font-bold text-slate-500" for="fTo">SAMPAI</label><input id="fTo" type="date" value="${today}" class="inp mt-0.5"></div>
      <div><label class="text-[11px] font-bold text-slate-500" for="fScr">LAYAR</label><select id="fScr" class="inp mt-0.5"><option value="">Semua layar</option></select></div>
      <button id="btnGo" class="btn btn-pri btn-sm">Tampilkan</button>
    </div>
    <div id="sum" class="mt-3 grid grid-cols-2 xl:grid-cols-4 gap-3"></div>
    <div class="mt-3 grid xl:grid-cols-[1fr_260px] gap-3 items-start">
      <div class="card overflow-hidden"><div class="card-h"><h2 class="text-[14px] font-extrabold">Grafik harian</h2></div>
        <div class="p-4"><div id="bars" class="flex items-end gap-1.5 h-36 border-b border-slate-200"></div></div></div>
      <div class="card overflow-hidden"><div class="card-h"><h2 class="text-[14px] font-extrabold">Top konten</h2></div>
        <div id="top" class="divide-y divide-slate-100"></div></div>
    </div>
    <div class="card mt-3 overflow-hidden"><div class="card-h"><h2 class="text-[14px] font-extrabold">Bukti tayang mentah</h2>
      <button id="btnCsv" class="btn btn-sec btn-sm ml-auto"><i class="fa-solid fa-download"></i>CSV</button></div>
      <div class="overflow-x-auto"><table class="tbl w-full"><thead><tr><th>Tanggal</th><th>Layar</th><th>Konten</th><th>Jam</th><th>Durasi</th><th>Status</th></tr></thead>
      <tbody id="rows"></tbody></table></div>
      <div id="pager" class="p-3 flex items-center justify-center gap-2 border-t border-slate-200"></div>
    </div>`;
  const screens = await Api.get("/api/screens?limit=100");
  document.getElementById("fScr").innerHTML = `<option value="">Semua layar</option>` + screens.items.map((s) => `<option value="${s.id}">${esc(s.name)}</option>`).join("");
  let pg = 1;

  async function load() {
    const f = document.getElementById("fFrom").value, tto = document.getElementById("fTo").value;
    const sid = document.getElementById("fScr").value;
    try {
      const sum = await Api.get(`/api/reports/summary?from=${f}T00:00:00%2B07:00&to=${tto}T23:59:59%2B07:00${sid ? "&screen_id=" + sid : ""}`);
      document.getElementById("sum").innerHTML = `
        <div class="card p-4"><p class="text-[12px] font-bold text-slate-500">TOTAL TAYANG</p><p class="text-[24px] font-extrabold">${sum.total_plays.toLocaleString("id-ID")}</p></div>
        <div class="card p-4"><p class="text-[12px] font-bold text-slate-500">TOTAL DURASI</p><p class="text-[24px] font-extrabold">${Math.round(sum.total_sec / 60).toLocaleString("id-ID")} <span class="text-[13px] text-slate-400">mnt</span></p></div>
        <div class="card p-4"><p class="text-[12px] font-bold text-slate-500">COMPLETION</p><p class="text-[24px] font-extrabold text-emerald-600">${sum.completion_pct}%</p></div>
        <div class="card p-4"><p class="text-[12px] font-bold text-slate-500">OFFLINE</p><p class="text-[24px] font-extrabold ${sum.offline_now.length ? "text-red-600" : ""}">${sum.offline_now.length}</p></div>`;
      document.getElementById("top").innerHTML = sum.top_contents.map((x) => `
        <div class="px-3 py-2 flex justify-between gap-2 text-[12.5px]"><span class="font-semibold text-slate-700 truncate">${esc(x.title)}</span><strong class="font-mono">${x.plays}×</strong></div>`).join("") || `<p class="p-4 text-[13px] text-slate-400">Belum ada data.</p>`;
      const logs = await Api.get(`/api/play-logs?from=${f}T00:00:00%2B07:00&to=${tto}T23:59:59%2B07:00${sid ? "&screen_id=" + sid : ""}&page=${pg}&limit=15`);
      const byDay = {};
      logs.items.forEach((l) => { const d = (l.started_at || "").slice(0, 10); byDay[d] = (byDay[d] || 0) + 1; });
      const vals = Object.entries(byDay).sort();
      const mx = Math.max(1, ...vals.map(([, v]) => v));
      document.getElementById("bars").innerHTML = vals.length ? vals.map(([d, v]) => `
        <div class="flex-1 flex flex-col items-center gap-1 min-w-[28px]"><span class="text-[10px] font-mono font-bold">${v}</span>
        <div class="w-full rounded-t bg-sky-600" style="height:${Math.max(6, 120 * v / mx)}px"></div>
        <span class="text-[9px] font-bold text-slate-400">${d.slice(5)}</span></div>`).join("") : `<p class="text-[13px] text-slate-400">Belum ada data periode ini.</p>`;
      document.getElementById("rows").innerHTML = logs.items.map((l) => `<tr>
        <td data-l="Tanggal">${(l.started_at || "").slice(0, 10)}</td>
        <td data-l="Layar">${esc(l.screen)}</td><td data-l="Konten">${esc(l.content)}</td>
        <td data-l="Jam" class="font-mono">${(l.started_at || "").slice(11, 16)}</td>
        <td data-l="Durasi" class="font-mono">${l.played_sec} dtk</td>
        <td data-l="Status">${statusBadge(l.status)}</td></tr>`).join("") || `<tr><td colspan="6" class="text-center text-slate-400 py-6">Tidak ada log periode ini.</td></tr>`;
      const pages = Math.max(1, Math.ceil(logs.total / logs.limit));
      document.getElementById("pager").innerHTML = `<button class="btn btn-sec btn-sm" ${pg <= 1 ? "disabled" : ""} data-p="-1">←</button><span class="text-[12.5px] font-bold">${pg} / ${pages} · ${logs.total} baris</span><button class="btn btn-sec btn-sm" ${pg >= pages ? "disabled" : ""} data-p="1">→</button>`;
      document.getElementById("pager").querySelectorAll("[data-p]").forEach((b) => b.onclick = () => { pg += +b.dataset.p; load(); });
      document.getElementById("btnCsv").onclick = () => {
        const rows = [["tanggal", "layar", "konten", "jam_mulai", "durasi_detik", "status"],
          ...logs.items.map((l) => [(l.started_at || "").slice(0, 10), l.screen, l.content, (l.started_at || "").slice(11, 16), l.played_sec, l.status])];
        const csv = rows.map((r) => r.map((x) => `"${String(x).replace(/"/g, '""')}"`).join(",")).join("\n");
        const a = document.createElement("a");
        a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
        a.download = `laporan-${f}-${tto}.csv`;
        a.click();
      };
    } catch (e) { toast(errMsg(e), "error"); }
  }
  document.getElementById("btnGo").onclick = () => { pg = 1; load(); };
  const bw = document.getElementById("btnCsvW");
  if (bw) bw.onclick = () => location.href = "/dashboard/weekly.html";
  load();
})();
