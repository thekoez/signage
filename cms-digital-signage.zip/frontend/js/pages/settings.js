/* Pengaturan umum: kebijakan 2FA, zona waktu, kuota, SMTP info. */
(async () => {
  await Auth.init(true);
  if (Auth.user.role !== "owner") { location.href = "/dashboard/index.html"; return; }
  await renderLayout("settings");
  const page = document.getElementById("page");
  page.innerHTML = `
    ${pageHead("Admin", "Pengaturan Umum", "Kebijakan keamanan, zona waktu, dan batasan media.")}
    <div class="mt-4 grid md:grid-cols-2 gap-3">
      <section class="card p-5">
        <h2 class="text-[14px] font-extrabold flex items-center gap-2"><i class="fa-solid fa-shield-halved text-sky-600"></i>Keamanan & 2FA</h2>
        <label class="mt-3 flex items-start gap-2.5 text-[13.5px] cursor-pointer">
          <input id="sAll" type="checkbox" class="w-5 h-5 accent-sky-600 mt-0.5">
          <span><strong>Wajibkan 2FA untuk semua peran</strong><br><span class="text-slate-500 text-[12.5px]">Pengguna tanpa 2FA langsung diblokir sampai enroll.</span></span></label>
        <label class="mt-3 flex items-start gap-2.5 text-[13.5px] cursor-pointer">
          <input id="sOwner" type="checkbox" class="w-5 h-5 accent-sky-600 mt-0.5">
          <span><strong>Wajibkan 2FA untuk Owner</strong><br><span class="text-slate-500 text-[12.5px]">Sangat dianjurkan tetap aktif.</span></span></label>
      </section>
      <section class="card p-5">
        <h2 class="text-[14px] font-extrabold flex items-center gap-2"><i class="fa-solid fa-gear text-sky-600"></i>Wilayah & Media</h2>
        <div class="mt-3 space-y-2.5">
          <div><label class="text-[12px] font-bold" for="sTz">Zona waktu</label>
            <select id="sTz" class="inp mt-1 w-full"><option>Asia/Jakarta</option><option>Asia/Makassar</option><option>Asia/Jayapura</option></select></div>
          <div class="grid grid-cols-3 gap-2">
            <div><label class="text-[12px] font-bold" for="sImg">Gambar (MB)</label><input id="sImg" type="number" class="inp mt-1"></div>
            <div><label class="text-[12px] font-bold" for="sVid">Video (MB)</label><input id="sVid" type="number" class="inp mt-1"></div>
            <div><label class="text-[12px] font-bold" for="sQ">Kuota (GB)</label><input id="sQ" type="number" class="inp mt-1"></div>
          </div>
        </div>
      </section>
    </div>
    <div class="mt-3 flex gap-2"><button id="btnSave" class="btn btn-pri">Simpan pengaturan</button></div>
    <section class="card mt-3 p-5">
      <h2 class="text-[14px] font-extrabold">Email & Laporan</h2>
      <p class="mt-1 text-[13px] text-slate-500">SMTP dikonfigurasi via environment server (<span class="font-mono">SMTP_HOST/PORT/USER/PASS</span>). Tanpa SMTP, email dicatat ke log server dan notifikasi in-app tetap jalan. Laporan mingguan otomatis tiap <strong>Minggu 18:00 WIB</strong> + retry 3x.</p>
    </section>`;
  try {
    const s = await Api.get("/api/settings");
    document.getElementById("sAll").checked = !!s.require_2fa_all;
    document.getElementById("sOwner").checked = s.require_2fa_owner !== false;
    document.getElementById("sTz").value = s.timezone || "Asia/Jakarta";
    document.getElementById("sImg").value = s.max_image_mb ?? 10;
    document.getElementById("sVid").value = s.max_video_mb ?? 200;
    document.getElementById("sQ").value = s.storage_quota_gb ?? 50;
  } catch (e) { toast(errMsg(e), "error"); }
  document.getElementById("btnSave").onclick = async () => {
    try {
      await Api.patch("/api/settings", {
        require_2fa_all: document.getElementById("sAll").checked,
        require_2fa_owner: document.getElementById("sOwner").checked,
        timezone: document.getElementById("sTz").value,
        max_image_mb: +document.getElementById("sImg").value || 10,
        max_video_mb: +document.getElementById("sVid").value || 200,
        storage_quota_gb: +document.getElementById("sQ").value || 50,
      });
      toast("Pengaturan tersimpan.", "success");
    } catch (e) { toast(errMsg(e), "error"); }
  };
})();
