/* Wrapper fetch: JWT, refresh, error handling, relative /api paths. */
const Api = {
  get token() { return localStorage.getItem("sc_token") || ""; },
  set token(v) { v ? localStorage.setItem("sc_token", v) : localStorage.removeItem("sc_token"); },
  get refresh() { return localStorage.getItem("sc_refresh") || ""; },

  async req(path, opts = {}) {
    const headers = Object.assign({}, opts.headers || {});
    if (this.token) headers["Authorization"] = "Bearer " + this.token;
    let res;
    try {
      res = await fetch(path, Object.assign({}, opts, { headers }));
    } catch (e) {
      throw new Error("conn");
    }
    if (res.status === 401 && this.token && !opts._retried && !path.includes("/auth/")) {
      // coba refresh sekali
      try {
        const r = await fetch("/api/auth/refresh", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ refresh_token: this.refresh }),
        });
        if (r.ok) {
          const j = await r.json();
          this.token = j.access_token;
          opts._retried = true;
          return this.req(path, opts);
        }
      } catch (e) { /* abaikan */ }
      Auth.logout(true);
      throw new Error("auth");
    }
    let data = null;
    try { data = await res.json(); } catch (e) { data = null; }
    if (!res.ok) {
      const msg = (data && data.detail) || ("HTTP " + res.status);
      const err = new Error(typeof msg === "string" ? msg : JSON.stringify(msg));
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data;
  },
  get(p) { return this.req(p); },
  post(p, b) { return this.req(p, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(b || {}) }); },
  patch(p, b) { return this.req(p, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(b || {}) }); },
  del(p) { return this.req(p, { method: "DELETE" }); },
  async upload(p, form) {
    const headers = {};
    if (this.token) headers["Authorization"] = "Bearer " + this.token;
    const res = await fetch(p, { method: "POST", headers, body: form });
    const data = await res.json().catch(() => null);
    if (!res.ok) throw new Error((data && data.detail) || ("HTTP " + res.status));
    return data;
  },
};

/* Toast kustom (pengganti alert) */
function toast(msg, type = "info") {
  const colors = { info: "border-sky-600", success: "border-emerald-500", error: "border-red-500", warn: "border-amber-500" };
  const icons = { info: "fa-circle-info text-sky-600", success: "fa-circle-check text-emerald-500", error: "fa-circle-exclamation text-red-500", warn: "fa-triangle-exclamation text-amber-500" };
  const box = document.getElementById("toasts");
  if (!box) { alert(msg); return; }
  const el = document.createElement("div");
  el.className = `toast-in bg-white border border-slate-200 border-l-4 ${colors[type]} rounded shadow-md px-3.5 py-3 flex items-start gap-2.5 max-w-sm`;
  el.setAttribute("role", "status");
  el.innerHTML = `<i class="fa-solid ${icons[type]} mt-0.5"></i><p class="text-[13px] text-slate-700 flex-1"></p>`;
  el.querySelector("p").textContent = msg;
  box.appendChild(el);
  setTimeout(() => { el.style.opacity = "0"; el.style.transition = "opacity .3s"; setTimeout(() => el.remove(), 320); }, 3800);
}

/* Modal konfirmasi kustom (pengganti confirm) */
function confirmModal({ title, message, confirmText, danger = false }) {
  return new Promise((resolve) => {
    const ov = document.createElement("div");
    ov.className = "modal-bg fixed inset-0 z-[100] grid place-items-center p-4";
    ov.innerHTML = `
      <div class="modal-in bg-white rounded shadow-lg max-w-md w-full" role="dialog" aria-modal="true">
        <div class="px-5 py-4 border-b border-slate-200"><h3 class="text-[15px] font-extrabold text-slate-900"></h3></div>
        <div class="px-5 py-4"><p class="text-[13.5px] text-slate-600"></p></div>
        <div class="px-5 py-3.5 bg-slate-50 border-t border-slate-200 rounded-b flex justify-end gap-2">
          <button class="btn btn-sec btn-sm" data-x="no">${t("cancel")}</button>
          <button class="btn btn-sm ${danger ? "btn-danger" : "btn-pri"}" data-x="yes"></button>
        </div>
      </div>`;
    ov.querySelector("h3").textContent = title;
    ov.querySelector("p").textContent = message;
    ov.querySelector('[data-x="yes"]').textContent = confirmText || t("confirm");
    const done = (v) => { ov.remove(); resolve(v); };
    ov.querySelector('[data-x="no"]').onclick = () => done(false);
    ov.querySelector('[data-x="yes"]').onclick = () => done(true);
    ov.addEventListener("click", (e) => { if (e.target === ov) done(false); });
    document.body.appendChild(ov);
    ov.querySelector('[data-x="no"]').focus();
  });
}

/* Modal input teks kustom (pengganti prompt) */
function inputModal({ title, label, placeholder = "", required = false, multiline = false }) {
  return new Promise((resolve) => {
    const ov = document.createElement("div");
    ov.className = "modal-bg fixed inset-0 z-[100] grid place-items-center p-4";
    ov.innerHTML = `
      <div class="modal-in bg-white rounded shadow-lg max-w-md w-full" role="dialog" aria-modal="true">
        <div class="px-5 py-4 border-b border-slate-200"><h3 class="text-[15px] font-extrabold text-slate-900"></h3></div>
        <div class="px-5 py-4">
          <label class="text-[12px] font-bold text-slate-700"></label>
          ${multiline ? `<textarea rows="3" class="inp mt-1"></textarea>` : `<input class="inp mt-1">`}
          <p class="hidden mt-1.5 text-[12.5px] font-semibold text-red-600" data-x="err"></p>
        </div>
        <div class="px-5 py-3.5 bg-slate-50 border-t border-slate-200 rounded-b flex justify-end gap-2">
          <button class="btn btn-sec btn-sm" data-x="no">${t("cancel")}</button>
          <button class="btn btn-pri btn-sm" data-x="yes">${t("save")}</button>
        </div>
      </div>`;
    ov.querySelector("h3").textContent = title;
    ov.querySelector("label").textContent = label;
    const inp = ov.querySelector(multiline ? "textarea" : "input");
    inp.placeholder = placeholder;
    const done = (v) => { ov.remove(); resolve(v); };
    ov.querySelector('[data-x="no"]').onclick = () => done(null);
    ov.querySelector('[data-x="yes"]').onclick = () => {
      const v = inp.value.trim();
      if (required && !v) {
        const e = ov.querySelector('[data-x="err"]');
        e.textContent = label + " wajib diisi.";
        e.classList.remove("hidden");
        return;
      }
      done(v);
    };
    ov.addEventListener("click", (e) => { if (e.target === ov) done(null); });
    document.body.appendChild(ov);
    inp.focus();
  });
}

/* Modal generik */
function openModal(title, bodyHtml, onMount) {
  closeModal();
  const ov = document.createElement("div");
  ov.id = "modal";
  ov.className = "modal-bg fixed inset-0 z-[100] grid place-items-center p-4 overflow-y-auto";
  ov.innerHTML = `
    <div class="modal-in bg-white rounded shadow-lg w-full max-w-2xl my-6" role="dialog" aria-modal="true">
      <div class="px-5 py-3.5 border-b border-slate-200 flex items-center gap-2">
        <h3 class="text-[15px] font-extrabold text-slate-900 flex-1"></h3>
        <button class="w-8 h-8 grid place-items-center text-slate-400 hover:text-slate-700" data-x="close" aria-label="Tutup"><i class="fa-solid fa-xmark"></i></button>
      </div>
      <div class="px-5 py-4" data-x="body"></div>
    </div>`;
  ov.querySelector("h3").textContent = title;
  ov.querySelector('[data-x="body"]').innerHTML = bodyHtml;
  ov.querySelector('[data-x="close"]').onclick = closeModal;
  ov.addEventListener("click", (e) => { if (e.target === ov) closeModal(); });
  document.addEventListener("keydown", escClose);
  document.body.appendChild(ov);
  if (onMount) onMount(ov.querySelector('[data-x="body"]'));
}
function escClose(e) { if (e.key === "Escape") closeModal(); }
function closeModal() {
  const m = document.getElementById("modal");
  if (m) m.remove();
  document.removeEventListener("keydown", escClose);
}

function errMsg(e, fallback) {
  if (!e) return fallback || t("error_generic");
  if (e.message === "conn") return t("err_conn");
  if (e.message === "auth") return t("err_auth");
  return e.message || fallback || t("error_generic");
}
function fmtDate(iso) {
  if (!iso) return "-";
  try {
    const d = new Date(iso);
    return d.toLocaleString(lang() === "id" ? "id-ID" : "en-GB",
      { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
  } catch (e) { return iso; }
}
function relTime(iso) {
  if (!iso) return "-";
  const s = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  const id = lang() === "id";
  if (s < 60) return id ? "baru saja" : "just now";
  if (s < 3600) return `${Math.floor(s / 60)} ${id ? "mnt lalu" : "min ago"}`;
  if (s < 86400) return `${Math.floor(s / 3600)} ${id ? "jam lalu" : "h ago"}`;
  return `${Math.floor(s / 86400)} ${id ? "hari lalu" : "d ago"}`;
}
function statusBadge(st) {
  const map = {
    approved: ["bg-emerald-50 text-emerald-700 border-emerald-200", "approved"],
    pending_review: ["bg-amber-50 text-amber-700 border-amber-200", "pending"],
    pending_delete: ["bg-red-50 text-red-700 border-red-200", "pending_delete"],
    rejected: ["bg-red-50 text-red-700 border-red-200", "rejected"],
    draft: ["bg-slate-100 text-slate-600 border-slate-200", "draft"],
    archived: ["bg-slate-100 text-slate-500 border-slate-200", "archived"],
    online: ["bg-emerald-500 text-white border-emerald-500", "online"],
    offline: ["bg-red-500 text-white border-red-500", "offline"],
    disabled: ["bg-slate-400 text-white border-slate-400", "disabled"],
    completed: ["bg-emerald-50 text-emerald-700 border-emerald-200", "completed"],
    failed: ["bg-red-50 text-red-700 border-red-200", "failed"],
    skipped: ["bg-slate-100 text-slate-600 border-slate-200", "skipped"],
  };
  const m = map[st] || ["bg-slate-100 text-slate-600 border-slate-200", st];
  return `<span class="badge ${m[0]}">${t("st_" + m[1]) || m[1]}</span>`;
}
