# SignageCMS — CMS Papan Informasi Digital

Aplikasi web terpusat untuk mengelola konten (gambar, video, teks berjalan/pengumuman)
dan menayangkannya ke banyak layar. Lihat `PRD.md` dan `TSD.md` untuk spesifikasi penuh.

## Arsitektur

- **cms-digital-signage-app** (nginx, `expose 80`): UI statis + reverse proxy `/api/*`
  ke backend. JS memanggil API via path relatif `/api/`.
- **cms-digital-signage-backend** (FastAPI, `expose 8000`): REST JSON + scheduler
  laporan mingguan (Minggu 18:00 WIB).
- **cms-digital-signage-db** (PostgreSQL 16): volume `cms-digital-signage_db_data`.

## Jalankan

```bash
cp .env.example .env   # sesuaikan secret + SMTP
docker compose build
docker compose up -d
```

Seed otomatis jalan saat backend pertama start (idempoten).
Buka UI via service `cms-digital-signage-app` port 80 di network `autodev-net`.

## Akun demo (password `Signage123!`, wajib diganti)

| Email | Peran |
|---|---|
| owner@demo.local | Owner (wajib 2FA) |
| marketing@demo.local | Staff |
| teknisi@demo.local | Teknisi |

## Player TV

Buka `/player/?token=scr_...` di browser TV. Token device tampil sekali saat
layar didaftarkan (atau regenerasi oleh Owner). Tanpa token tampil mode pairing.

## API

Dokumentasi interaktif: `/api/docs` (via proxy backend). Basis path: `/api`
dan `/api/v1`. Auth user: `Authorization: Bearer <JWT>`. Auth player:
header `X-Device-Token: scr_...`.

## Struktur

```
backend/app/{main,config,db,models,security,totp,deps,helpers,seed,scheduler,mailer}.py
backend/app/routers/{auth,contents,playlists,screens,player,misc}.py
frontend/{index,login,verify-2fa,setup-2fa,forgot-password,reset-password,accept-invite}.html
frontend/{css,js/{api,auth,i18n,layout,pages/*},dashboard/*.html,player/index.html}
nginx/nginx.conf  docker-compose.yml  .env.example
```
