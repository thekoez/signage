# PRD — CMS Digital Signage (Sistem Manajemen Papan Informasi Digital)

**Nama Produk:** SignageCMS (CMS Digital Signage untuk Kantor / Kampus / Rumah Sakit / Toko)
**Versi Dokumen:** v1.1 (revisi: tambah 2FA TOTP)
**Tanggal:** 8 Oktober 2026
**Bahasa:** Bahasa Indonesia
**Status:** Siap dikembangkan (MVP-first)

**Changelog v1.1:** Menambahkan autentikasi dua faktor (2FA) berbasis TOTP — setup via QR/app authenticator, kode cadangan (backup codes), kebijakan wajib untuk Owner, dan halaman/prioritas terkait.

---

## 1. Ringkasan Produk

### 1.1 Latar Belakang
Kantor, kampus, rumah sakit, dan toko membutuhkan papan informasi digital yang mudah dikelola tanpa harus datang ke tiap layar (colok USB / ganti flashdisk manual). Pengelolaan manual menyebabkan konten basi, tidak sinkron antar layar, tidak ada bukti tayang, dan tidak ketahuan saat layar mati.

### 1.2 Deskripsi Produk
SignageCMS adalah aplikasi web terpusat untuk mengelola **konten (gambar, video, teks berjalan/pengumuman)** dan menayangkannya ke **banyak layar** di satu gedung maupun 1–3 layar di lokasi toko. Aplikasi pengaturnya (dashboard admin) bergaya **modern dan penuh warna seperti aplikasi promosi**, sedangkan tampilan di layar (player) dibuat bersih, fullscreen, dan fokus ke konten.

Komponen utama:
1. **Dashboard CMS (web admin)** — upload konten, atur layar, buat playlist/jadwal, approval, monitoring, laporan.
2. **Player Layar (web fullscreen)** — halaman web ringan yang dibuka di TV/Android TV/STB/mini-PC dan memutar konten otomatis sesuai jadwal. Mendukung mode offline/cache.

### 1.3 Tujuan Produk
- Memungkinkan staff marketing membuat dan menjadwalkan konten promosi/informasi dalam hitungan menit.
- Memastikan setiap konten yang tayang sudah **di-review dan di-approve pemilik usaha**.
- Memberi visibilitas real-time: **konten apa sedang tayang, layar online/mati, bukti tayang**.
- Memberi **laporan penayangan mingguan otomatis** ke pemilik usaha setiap akhir pekan.
- Mengamankan penghapusan konten dengan **mekanisme approval hapus**.

### 1.4 Ruang Lingkup
**Masuk lingkup (In-scope):**
- Upload dan manajemen gambar (JPG/PNG/WebP), video (MP4/WebM), teks berjalan & pengumuman teks.
- Manajemen layar/device, grup layar, pairing code.
- Playlist + penjadwalan (default loop + jadwal khusus promo/event).
- Alur approval terbit & approval hapus oleh pemilik.
- Player fullscreen dengan auto-refresh, cache offline, heartbeat.
- Monitoring status online/offline + halaman Now Playing.
- Laporan bukti tayang (log penayangan) + rekap mingguan + kirim email ke pemilik.
- Manajemen 3 peran: Pemilik/Admin Utama, Staff Marketing, Teknisi.
- Autentikasi dua faktor (2FA) TOTP via aplikasi authenticator + kode cadangan (backup codes).

**Di luar lingkup awal (Out-of-scope / fase berikutnya):**
- Editor desain drag-and-drop ala Canva, template animasi kompleks.
- Video wall tersinkronisasi frame-perfect, interaktif touchscreen/kiosk.
- Analitik audiens dengan kamera/AI, integrasi sensor cuaca/IoT.
- Aplikasi mobile native (cukup web responsif).

### 1.5 Definisi Istilah
| Istilah | Arti |
|---|---|
| Konten | Satu aset: gambar / video / teks (ticker/pengumuman) |
| Layar (Screen/Device) | Satu titik tayang fisik (TV + player) |
| Playlist | Urutan konten yang diputar berulang di satu/grup layar |
| Jadwal (Schedule) | Aturan kapan playlist/promo tayang (tanggal, jam, hari) |
| Approval | Persetujuan pemilik sebelum konten terbit/dihapus |
| Bukti tayang (Proof-of-play) | Log tiap konten yang benar-benar diputar di layar |
| Heartbeat | Sinyal periodik dari player ke server sebagai tanda online |
| Ticker | Teks berjalan di bagian bawah layar |
| 2FA / TOTP | Verifikasi dua langkah memakai kode 6 digit berubah tiap 30 detik dari aplikasi authenticator (Google Authenticator, Authy, 1Password, dsb.), standar RFC 6238 |
| Backup codes | Kode cadangan sekali pakai untuk login darurat saat perangkat authenticator hilang |

---

## 2. Target Pengguna

### Persona 1 — Pemilik Usaha / Admin Utama (Owner)
- **Profil:** Pemilik toko/klinik/kampus, pengambil keputusan akhir. Tidak selalu paham teknis, butuh tampilan sederhana dan laporan ringkas.
- **Kebutuhan:** Pastikan hanya konten yang layak yang tayang; tahu kondisi layar tanpa harus cek fisik; terima laporan mingguan otomatis.
- **Perangkat:** Laptop/HP, akses kapan saja.
- **Pain point:** Takut konten salah tayang / konten belum dicek sudah tayang; tidak tahu layar mati.

### Persona 2 — Staff Marketing / Pembuat Konten Promosi
- **Profil:** Membuat materi promosi, pengumuman, jadwal event. Bekerja cepat, sering upload banyak file.
- **Kebutuhan:** Upload drag-and-drop, preview persis seperti di layar, atur layar tujuan + jadwal, ajukan approval sekali klik, lihat status (draft → menunggu review → approved → tayang → ditolak).
- **Pain point:** Revisi berulang via chat; tidak tahu konten sudah tayang atau belum.

### Persona 3 — Teknisi Lapangan
- **Profil:** Mengurus instalasi TV/STB, jaringan, pairing layar, restart saat bermasalah.
- **Kebutuhan:** Daftarkan layar baru dengan cepat ( pairing code ), lihat status online/offline, identifikasi layar bermasalah, restart/reload dari jarak jauh.
- **Pain point:** Harus datang ke lokasi hanya untuk cek layar mati atau ganti konten.

### Pengguna Tidak Langsung
- Pengunjung/pasien/mahasiswa/karyawan yang **melihat layar** (bukan login ke CMS).

---

## 3. Fitur Utama (dengan Acceptance Criteria)

### F1 — Manajemen Konten (Media Library)
**Deskripsi:** Pusat upload, simpan, cari, pratinjau, dan kelola gambar, video, dan teks.
- Mendukung JPG, PNG, WebP (maks 10 MB), MP4/WebM H.264 (maks 200 MB default, dapat dikonfigurasi), durasi video otomatis terdeteksi.
- Teks berjalan (ticker): input teks + kecepatan + warna + posisi. Pengumuman teks fullscreen/split: judul + isi + latar.
- Setiap konten punya: nama, tipe, file/thumbnail, durasi tampil (gambar/teks: default 10 detik, dapat diubah), status (draft / pending_review / approved / rejected / archived), pembuat, tanggal.
- Validasi otomatis: tolak format/ukuran berlebih dengan pesan jelas; video rusak ditandai gagal.
- Pencarian, filter tipe/status, tampilan grid penuh warna dengan thumbnail.

**Acceptance Criteria:**
1. Staff dapat mengunggah gambar/video via drag-and-drop dan melihat progres upload.
2. Sistem menolak file > batas dengan pesan error yang jelas dan tidak menyimpan file parsial.
3. Setiap konten gambar/teks wajib punya durasi tampil (5–120 detik); video memakai durasi asli kecuali dioverride.
4. Thumbnail otomatis dibuat untuk gambar & video (frame tengah) dan tampil di library < 3 detik setelah upload selesai.
5. Preview konten menampilkan tampilan mendekati kondisi layar (rasio 16:9 default).

### F2 — Manajemen Layar & Grup Layar
**Deskripsi:** Daftarkan, kelompokkan, dan kendalikan layar.
- Registrasi layar via **pairing code 6 digit** yang ditampilkan di TV (kedaluwarsa 10 menit).
- Data layar: nama (mis. "Lobi Lt.1 - TV 01"), lokasi/gedung/lantai, grup (mis. "Semua Lobi", "Toko A"), resolusi/orientasi (landscape/potrait), status.
- Aksi jarak jauh: reload player, restart playlist, identifikasi (tampilkan nama berkedip di layar 10 detik), nonaktifkan.
- Mendukung skala: banyak layar satu gedung + 1–3 layar per toko.

**Acceptance Criteria:**
1. Teknisi dapat mendaftarkan layar baru < 2 menit hanya dengan pairing code tanpa SSH/konfigurasi manual.
2. Pairing code kedaluwarsa otomatis dan tidak dapat dipakai ulang.
3. Admin dapat mengelompokkan layar dan menargetkan playlist ke 1 layar, banyak layar, atau grup.
4. Aksi "Identifikasi layar" menampilkan overlay nama layar di TV dalam ≤ 5 detik.

### F3 — Playlist & Penargetan Layar
**Deskripsi:** Susun urutan putar dan tentukan layar tujuan.
- Satu playlist berisi banyak item konten dengan urutan + durasi per item + transisi (fade/slide/none).
- Playlist di-assign ke layar/grup. Satu layar punya 1 playlist aktif default (fallback) + playlist promo terjadwal yang menimpa sementara.
- Drag-and-drop urutan, duplikasi playlist, preview urutan putar.

**Acceptance Criteria:**
1. Staff dapat membuat playlist, menambah ≥ 20 item, mengubah urutan via drag-and-drop.
2. Satu playlist dapat di-assign ke ≥ 1 layar/grup dalam sekali aksi.
3. Layar tanpa jadwal khusus selalu memutar playlist default (tidak pernah layar hitam jika ada konten approved).
4. Perubahan playlist yang sudah approved membutuhkan approval ulang (versi baru berstatus pending).

### F4 — Penjadwalan Tayang (Scheduling Khusus Promo/Event)
**Deskripsi:** Sesuai kebutuhan user: **penjadwalan hanya untuk promo/event tertentu**, selebihnya loop normal.
- Tipe jadwal: (a) Selalu tayang (default loop), (b) Rentang tanggal (mis. promo 10–17 Okt), (c) Slot jam harian (mis. 08:00–12:00), (d) Hari tertentu (Senin–Jumat / akhir pekan).
- Aturan prioritas: jadwal promo yang aktif menimpa playlist default; jika 2 jadwal bertabrakan, prioritas tertinggi / terbaru menang dan tercatat.
- Zona waktu: Asia/Jakarta default per layar.

**Acceptance Criteria:**
1. Staff dapat membuat jadwal promo dengan rentang tanggal + jam mulai/selesai + pilih layar.
2. Saat jadwal aktif, player beralih ke konten promo ≤ 60 detik tanpa reload manual.
3. Saat jadwal berakhir, player kembali ke playlist default otomatis.
4. Konflik jadwal ditampilkan sebagai peringatan dan sistem memilih 1 pemenang deterministik (prioritas tertinggi).

### F5 — Approval Terbit oleh Pemilik (Wajib Sebelum Tayang)
**Deskripsi:** Alur sesuai cerita user: staff ajukan → pemilik review → approve/reject → baru tayang.
- Status konten/playlist: `draft → pending_review → approved / rejected`.
- Pemilik melihat antrean review dengan preview, perbandingan versi, tombol Setujui/Tolak + catatan.
- Konten berstatus non-approved **tidak boleh** diputar player (player hanya fetch yang approved).
- Notifikasi ke pemilik saat ada pengajuan baru.

**Acceptance Criteria:**
1. Tombol "Ajukan Review" mengubah status menjadi pending dan mengunci edit (edit membuat versi baru draft).
2. Pemilik dapat approve/reject + catatan dalam ≤ 3 klik dari antrean.
3. Player tidak pernah memutar konten pending/ditolak (diverifikasi via API hanya mengembalikan approved).
4. Staff menerima notifikasi hasil review ≤ 1 menit (in-app + email opsional).

### F6 — Approval Hapus Konten
**Deskripsi:** Staff dapat mengusulkan hapus, eksekusi hapus hanya setelah pemilik menyetujui.
- Hapus bersifat dua tahap: `request_delete (pending_delete) → approved_delete → soft-delete/arsip`.
- Konten yang sedang tayang/terjadwal tidak dapat dihapus langsung; harus diganti/dijadwalkan berhenti dulu (sistem memperingatkan).
- Riwayat hapus tercatat (siapa minta, siapa setujui, kapan).

**Acceptance Criteria:**
1. Staff menekan Hapus → status menjadi pending_delete, file tidak hilang.
2. Pemilik menyetujui → konten menjadi archived dan hilang dari pilihan playlist, file disimpan 30 hari sebelum purge.
3. Sistem menolak pengajuan hapus konten yang sedang aktif tayang dengan pesan + saran (ganti dulu / hentikan jadwal).
4. Semua aksi hapus tercatat di log audit.

### F7 — Player Layar (Fullscreen Playback)
**Deskripsi:** Halaman `/player?token=...` fullscreen yang memutar konten otomatis.
- Layout: fullscreen video/gambar + ticker bawah opsional + jam/logo. Mendukung landscape & portrait.
- Perilaku: preload konten berikutnya, cache lokal (browser cache + localStorage manifest), auto-retry saat jaringan putus, tampilkan konten cache terakhir + overlay "Offline — menampilkan cache".
- Polling jadwal tiap 60 detik + heartbeat tiap 30 detik + kirim proof-of-play tiap item selesai diputar.

**Acceptance Criteria:**
1. Player dapat berjalan 24 jam tanpa interaksi dan berpindah konten otomatis sesuai durasi.
2. Saat internet putus 10 menit, player tetap memutar cache terakhir tanpa layar hitam.
3. Saat internet pulih, player sinkron ke jadwal terbaru ≤ 2 menit.
4. Setiap item yang diputar ≥ 90% durasi tercatat sebagai 1 proof-of-play.

### F8 — Monitoring: Now Playing + Status Online/Mati
**Deskripsi:** Dashboard teknisi & pemilik untuk menjawab: konten apa sedang tayang? layar online/mati?
- Kartu per layar: status (Online hijau / Offline merah / Tidak aktif abu), thumbnail Now Playing, nama konten + sisa durasi, terakhir heartbeat, uptime 24 jam.
- Status offline jika tidak ada heartbeat > 90 detik.
- Filter: semua / online / offline; cari per nama/lokasi.

**Acceptance Criteria:**
1. Dashboard menampilkan status ≤ 90 detik dari kondisi sebenarnya.
2. Klik layar menampilkan detail: playlist aktif, 5 konten berikutnya, riwayat heartbeat 24 jam.
3. Layar offline > 5 menit memicu penanda merah + notifikasi ke teknisi (in-app).
4. Halaman dapat menangani 100 layar tanpa lag (pagination/virtualisasi, polling efisien).

### F9 — Bukti Tayang & Laporan Penayangan (Harian + Mingguan Otomatis)
**Deskripsi:** Setiap pemutaran tercatat; pemilik menerima rekap tiap akhir pekan.
- Log proof-of-play: layar, konten, playlist/jadwal, mulai–selesai, durasi, status selesai/gagal.
- Laporan: per layar, per konten (total tayang, total durasi, % completion), periode harian/mingguan/bulanan, ekspor CSV/PDF.
- **Laporan mingguan otomatis tiap Minggu 18:00 (Asia/Jakarta)** dikirim via email ke pemilik + tersedia di dashboard. Berisi ringkasan sepekan: total penayangan, top konten, layar dengan downtime tertinggi, konten gagal.
- Laporan hanya menghitung konten approved yang benar-benar diputar (bukan sekadar terjadwal).

**Acceptance Criteria:**
1. Setiap pemutaran tercatat dengan timestamp mulai/selesai dan dapat dilihat ≤ 2 menit setelah terjadi.
2. Laporan mingguan terkirim otomatis tiap Minggu 18:00 ± 15 menit ke semua pemilik aktif.
3. Ekspor CSV mingguan berisi minimal kolom: tanggal, layar, konten, jam mulai, durasi, status.
4. Data log disimpan minimal 90 hari (dapat dikonfigurasi).

### F10 — Manajemen Pengguna & Peran
**Deskripsi:** Kelola akun 3 peran + undangan + nonaktifkan.
- Registrasi awal membuat Owner pertama; Owner mengundang Staff/Teknisi via email/link.
- Profil: nama, email, peran, avatar, status aktif/nonaktif.

**Acceptance Criteria:**
1. Hanya Owner dapat membuat/menonaktifkan akun dan mengubah peran.
2. Akun nonaktif langsung kehilangan akses (token dicabut).
3. Semua perubahan peran tercatat di audit log.

### F11 — Notifikasi (In-App + Email)
**Deskripsi:** Pemberitahuan untuk kejadian penting: pengajuan review, hasil approve/reject, pengajuan hapus, layar offline, laporan mingguan siap.
- In-app bell + daftar notifikasi; email via SMTP untuk: undangan, hasil review, laporan mingguan.

**Acceptance Criteria:**
1. Pemilik menerima notifikasi pengajuan baru ≤ 1 menit.
2. Pengguna dapat menandai sudah dibaca; badge count akurat.
3. Email laporan mingguan memiliki tautan langsung ke halaman laporan.

### F12 — Audit Log
**Deskripsi:** Jejak siapa-melakukan-apa (login, upload, ajukan, approve, assign, hapus, perintah layar).
- Disimpan minimal 180 hari, dapat difilter per pengguna/aksi/tanggal.

**Acceptance Criteria:**
1. Setiap aksi approval/hapus tercatat dengan aktor + waktu + objek.
2. Audit log hanya dapat dilihat Owner dan tidak dapat dihapus pengguna biasa.

### F13 — Autentikasi Dua Faktor (2FA) TOTP
**Deskripsi:** Lapisan keamanan tambahan saat login memakai kode 6 digit dari aplikasi authenticator (TOTP, RFC 6238) + kode cadangan darurat.
- Enroll mandiri: pengguna scan QR / input secret manual di aplikasi authenticator (Google Authenticator, Authy, 1Password, dsb.), lalu konfirmasi dengan 1 kode valid sebelum 2FA aktif.
- Kebijakan: **wajib aktif untuk peran Owner/Admin Utama**; opsional (sangat dianjurkan) untuk Staff dan Teknisi. Owner dapat mewajibkan 2FA untuk semua pengguna via Pengaturan Umum.
- Login dua tahap: email+password benar → jika 2FA aktif, sistem meminta kode TOTP (atau salah satu backup code) sebelum menerbitkan session JWT.
- Kode cadangan: 10 kode sekali pakai, ditampilkan sekali saat aktivasi, dapat digenerasi ulang; tiap pemakaian tercatat di audit log dan memicu notifikasi email keamanan.
- Pemulihan: pengguna yang kehilangan perangkat/authenticator mengajukan reset ke Owner; Owner mereset 2FA dari halaman Manajemen Pengguna (wajib catat alasan, tercatat di audit log). Tidak ada self-reset via email tanpa login.
- Kompatibel HP: proses enroll dan verifikasi sepenuhnya bisa dilakukan dari browser HP.

**Acceptance Criteria:**
1. Pengguna dapat mengaktifkan 2FA dari Profil Saya dalam ≤ 5 langkah (buka setup → scan QR → verifikasi kode → simpan backup codes) dan melihat status Aktif/Nonaktif.
2. Secret TOTP tidak pernah ditampilkan ulang setelah enroll; QR/setup hanya tersedia selama sesi setup yang belum dikonfirmasi (kedaluwarsa ≤ 10 menit).
3. Login akun ber-2FA tanpa kode valid **gagal** memperoleh JWT/session; 5x kode salah beruntun mengunci tahap verifikasi 15 menit + mencatat audit `2fa_failed`.
4. Setiap backup code hanya dapat dipakai sekali; setelah dipakai, kode tersebut hangus dan sisa kuota berkurang.
5. Jika kebijakan "wajib 2FA semua" diaktifkan, pengguna tanpa 2FA diarahkan wajib enroll sebelum dapat memakai dashboard (grace period 0 — langsung diblokir sampai enroll).
6. Reset 2FA oleh Owner menonaktifkan 2FA target + menghanguskan secret & backup codes lama, tercatat di audit log beserta aktor dan alasan.

---

## 4. User Roles & Permissions

| Kemampuan | Pemilik / Admin Utama | Staff Marketing | Teknisi |
|---|:---:|:---:|:---:|
| Login dashboard | ✅ | ✅ | ✅ |
| Upload & edit konten milik sendiri | ✅ | ✅ | ❌ (hanya lihat) |
| Ajukan review / ajukan hapus | ✅ | ✅ | ❌ |
| Approve / Reject terbit & hapus | ✅ | ❌ | ❌ |
| Buat/edit playlist & jadwal | ✅ (bisa) | ✅ | ❌ (hanya lihat) |
| Assign playlist ke layar/grup | ✅ | ✅ | ❌ |
| Daftarkan layar (pairing), edit info layar | ✅ | ❌ | ✅ |
| Perintah jarak jauh (reload/identifikasi) | ✅ | ❌ | ✅ |
| Lihat monitoring & Now Playing | ✅ | ✅ (lihat saja) | ✅ |
| Lihat laporan & ekspor CSV/PDF | ✅ penuh | ✅ terbatas (konten sendiri) | ✅ terbatas (status/uptime) |
| Kelola pengguna & peran | ✅ | ❌ | ❌ |
| Kelola/reset 2FA pengguna lain | ✅ | ❌ | ❌ |
| Aktif/nonaktifkan 2FA sendiri + kelola backup codes | ✅ | ✅ | ✅ |
| Lihat audit log | ✅ | ❌ | ❌ |
| Buka halaman Player TV | ✅ (token device) | ❌ | ✅ (setup) |

**Aturan tambahan:**
- Staff hanya bisa edit/hapus-ajukan konten yang ia buat, kecuali Owner dapat mengelola semua.
- Teknisi tidak dapat melihat isi file konten sensitif? Minimal dapat melihat nama/thumbnail untuk identifikasi, tetapi tidak dapat mengunduh file asli (opsional, default: boleh lihat thumbnail saja).
- Semua peran wajib login; halaman player memakai token device terpisah (bukan session user).
- 2FA wajib untuk Owner; Owner dapat mengaktifkan kebijakan "wajib 2FA untuk semua peran" dari Pengaturan Umum. Player TV tidak terkena 2FA (memakai token device terpisah).

---

## 5. User Flow (Alur Pengguna Utama)

### Flow A — Staff Membuat Konten → Tayang di Layar (alur inti)
1. Staff login → buka **Konten / Media Library** → klik **Upload**.
2. Upload gambar/video atau buat **Teks Berjalan/Pengumuman** → isi nama + durasi + thumbnail otomatis.
3. Staff buka **Playlist** → buat/salin playlist → susun urutan → **tentukan layar tujuan** (pilih layar/grup).
4. (Opsional) Tambah **Jadwal promo/event** (tanggal + jam + prioritas) jika bukan loop harian.
5. Klik **Ajukan Review** → status `pending_review` → pemilik dapat notifikasi.
6. Pemilik buka **Antrean Review** → preview → **Setujui** (atau Tolak + catatan).
7. Jika disetujui → status `approved` → player di layar tujuan otomatis mengambil konten baru ≤ 2 menit dan memutar sesuai setelan.
8. Staff memantau di **Monitoring** bahwa konten sudah "Now Playing".
9. Sistem mencatat proof-of-play setiap pemutaran.

### Flow B — Approval Ditolak (Revisi)
1. Pemilik menolak + catatan (mis. "teks typo, resolusi kurang").
2. Staff menerima notifikasi → duplikasi/perbaiki konten → ajukan ulang (versi bertambah).
3. Riwayat review versi lama tetap tersimpan.

### Flow C — Hapus Konten dengan Approval
1. Staff buka detail konten → klik **Minta Hapus** + alasan.
2. Jika konten sedang aktif → sistem tolak dengan pesan "Sedang tayang di Layar X — ganti dulu".
3. Jika aman → status `pending_delete` → pemilik dapat notifikasi.
4. Pemilik setujui → konten `archived` (hilang dari pilihan), file dipertahankan 30 hari.
5. Jika ditolak → konten kembali `approved` + catatan.

### Flow D — Teknisi Daftarkan & Rawat Layar
1. Teknisi login → buka **Layar** → klik **Tambah Layar** → dapatkan instruksi pairing.
2. Di TV buka URL player → tampilkan **kode pairing 6 digit** → teknisi masukkan kode di dashboard (atau sebaliknya tergantung implementasi) → layar terdaftar & masuk grup.
3. Teknisi pantau **Monitoring**; jika layar merah (offline) → cek jaringan/listrik → perintah **Reload** atau datang ke lokasi.
4. Teknisi gunakan **Identifikasi layar** untuk memastikan TV fisik sesuai data.

### Flow E — Laporan Mingguan Otomatis ke Pemilik
1. Setiap pemutaran tercatat sebagai proof-of-play secara real-time.
2. Tiap Minggu 18:00 WIB scheduler membuat rekap sepekan per layar & per konten.
3. Sistem kirim email ke semua Owner + tampilkan kartu "Laporan Mingguan Siap" di dashboard.
4. Owner buka **Laporan** → filter minggu → lihat grafik + unduh CSV/PDF.

### Flow F — Setup & Login dengan 2FA TOTP
1. Pengguna login → buka **Profil Saya → Keamanan → Aktifkan 2FA** → sistem tampilkan QR + secret manual.
2. Pengguna scan QR di aplikasi authenticator → masukkan kode 6 digit → sistem validasi (toleransi ±1 langkah waktu) → 2FA aktif → sistem tampilkan 10 backup codes (sekali tampil, wajib disimpan).
3. Login berikutnya: email+password → layar **Verifikasi 2FA** → masukkan kode authenticator (atau backup code darurat) → berhasil → masuk dashboard.
4. Kehilangan perangkat: pengguna lapor ke Owner → Owner buka **Manajemen Pengguna → Reset 2FA** + alasan → 2FA target nonaktif → pengguna login password saja lalu enroll ulang.
5. Jika kebijakan wajib-2FA-semua aktif: pengguna tanpa 2FA setelah login langsung diarahkan ke halaman enroll dan tidak bisa akses menu lain sampai 2FA aktif.

---

## 6. Non-Functional Requirements

### 6.1 Performa
- Halaman dashboard (list konten/layar) First Contentful Paint < 2 detik di koneksi 4G, Time-to-Interactive < 3,5 detik.
- API list (paginasi 20) p95 < 300 ms; API player manifest p95 < 200 ms (tanpa file biner).
- Player preload item berikutnya sebelum item saat ini selesai (gap antar konten ≤ 1 detik di jaringan normal).
- Mendukung 100 layar × heartbeat 30 detik tanpa degradasi (≤ 4 req/detik rata-rata).
- Upload besar memakai chunked/multipart + resume; progres real-time.

### 6.2 Keamanan
- Login dengan password hashing (bcrypt/argon2), session JWT httpOnly + refresh token, lockout brute-force (5x gagal → kunci 15 menit), rate-limit login.
- **2FA TOTP (RFC 6238):** secret per pengguna dienkripsi (AES/Fernet) di server, tidak pernah dikirim ke frontend kecuali saat setup; kode 6 digit, periode 30 detik, toleransi ±1 langkah; rate-limit + lockout khusus tahap verifikasi 2FA (5x salah → kunci 15 menit); backup codes di-hash (bcrypt) dan sekali pakai.
- RBAC ditegakkan di backend per endpoint (bukan hanya sembunyikan tombol di frontend).
- File upload: validasi MIME + ekstensi + magic bytes, batas ukuran, scan nama file, simpan di luar web-root / object storage dengan URL bertanda (signed URL) kedaluwarsa.
- Token device player unik per layar, dapat dicabut/regenerasi; pairing code sekali pakai & kedaluwarsa.
- HTTPS wajib di production; header keamanan (CSP, HSTS, X-Frame-Options kecuali halaman player diizinkan embed bila perlu).
- Audit log untuk semua aksi sensitif; data laporan hanya agregat (tanpa data pribadi pengunjung).

### 6.3 Responsif & Kompatibilitas
- Dashboard responsif: desktop utama (1366px+), tablet/laptop kecil tetap usable, HP untuk approval & monitoring (tindakan approve ≤ 3 tap).
- Browser: Chrome/Edge terbaru, Firefox terbaru, Safari terbaru; player dioptimalkan untuk Chromium-based (Android TV/STB) + fallback Safari.
- Player mendukung resolusi 1080p (utama), 720p, 4K (downscale), orientasi landscape & portrait.
- Gaya dashboard: modern penuh warna (kartu gradien, badge status berwarna, ilustrasi promosi) tetapi kontras teks ≥ 4.5:1, mendukung prefers-reduced-motion.

### 6.4 Keandalan & Ketersediaan
- Target uptime CMS 99,5% (single-node Docker cukup untuk MVP; siap scale horizontal backend stateless).
- Player tahan offline: cache manifest + media terakhir; tidak menampilkan layar hitam > 3 detik kecuali tidak ada konten sama sekali (tampilkan splash logo default).
- Backup DB harian + retensi 7 hari; file media direplikasi/ter-backup bersama volume storage.
- Log terstruktur + health-check endpoint `/healthz`.

### 6.5 Skalabilitas & Batasan MVP
- MVP ditargetkan untuk: ≤ 100 layar, ≤ 5.000 konten, ≤ 1 juta baris proof-of-play/90 hari.
- Batasan file default: gambar 10 MB, video 200 MB, total storage 50 GB (dapat dinaikkan via env).

---

## 7. Halaman / Screen yang Dibutuhkan

### A. Area Publik / Auth
1. `Login` — email + password + lupa password.
2. `Verifikasi 2FA (tahap login)` — input kode 6 digit authenticator / backup code + tombol "gunakan kode cadangan".
3. `Setup 2FA (enroll)` — tampilkan QR + secret manual + input konfirmasi + tampilkan backup codes sekali.
4. `Lupa/Reset Password` — minta tautan + form password baru.
5. `Undangan (Accept Invite)` — buat password dari tautan undangan.

### B. Dashboard & Navigasi Utama
6. `Beranda / Ringkasan` — kartu statistik (total layar online, pending review, tayang hari ini), pintasan cepat, aktivitas terbaru. Nuansa penuh warna.
7. `Notifikasi` — daftar + tandai dibaca (atau drawer bell + halaman penuh).

### C. Konten
8. `Media Library (Daftar Konten)` — grid + filter + pencarian + badge status.
9. `Upload Konten` — drag-and-drop + progres (atau modal besar).
10. `Buat/Edit Teks Berjalan & Pengumuman` — form teks + live preview.
11. `Detail Konten` — preview besar, metadata, riwayat versi & review, tombol Ajukan Review / Minta Hapus, daftar layar yang memakai konten ini.

### D. Playlist & Jadwal
12. `Daftar Playlist` — kartu + status + layar target.
13. `Buat/Edit Playlist` — susun item drag-and-drop + assign layar/grup + preview urutan.
14. `Penjadwalan (Kalender Jadwal)` — kalender/event list + form jadwal promo (tanggal, jam, hari, prioritas).

### E. Layar
15. `Daftar Layar` — tabel/kartu + filter status + pencarian + badge online/offline.
16. `Tambah Layar (Pairing)` — panduan + input kode pairing.
17. `Detail Layar` — info, grup, playlist aktif, Now Playing + antrean 5 berikutnya, riwayat heartbeat/uptime, tombol aksi (reload/identifikasi/nonaktifkan), token device.

### F. Review & Moderasi (Pemilik)
18. `Antrean Review (Approval Terbit)` — daftar pending + preview cepat + Setujui/Tolak.
19. `Antrean Hapus (Approval Hapus)` — daftar pending_delete + peringatan jika masih terjadwal.
20. `Riwayat Review` — semua keputusan + catatan + aktor.

### G. Monitoring & Laporan
21. `Monitoring (Wall of Screens)` — grid status semua layar + Now Playing thumbnail + filter.
22. `Laporan Penayangan` — filter tanggal/layar/konten + grafik + tabel + ekspor CSV/PDF.
23. `Laporan Mingguan (Arsip)` — daftar rekap tiap pekan + unduh + status kirim email.

### H. Pengaturan & Admin
24. `Manajemen Pengguna` — daftar, undang, ubah peran, nonaktifkan.
25. `Grup Layar & Lokasi` — kelola gedung/lantai/grup.
26. `Pengaturan Umum` — zona waktu, batas upload, retensi log, SMTP, template email laporan, kebijakan wajib 2FA.
27. `Audit Log` — tabel jejak aksi + filter.
28. `Profil Saya` — nama, avatar, ganti password, kelola 2FA (aktifkan/nonaktifkan, regenerasi backup codes).

### I. Player (di TV, bukan dashboard)
29. `Player Fullscreen (/player)` — putar loop + ticker + jam; mode pairing (tampilkan kode) & mode offline (splash cache).
30. `Pairing Screen` — kode 6 digit besar + QR URL (opsional).

**Total: 30 halaman/state.** MVP wajib mencakup semuanya kecuali arsip laporan mingguan terpisah boleh digabung ke halaman Laporan (filter "Mingguan").

---

## 8. Prioritas Fitur (MVP vs Nice-to-Have)

### MVP (Fase 1 — wajib rilis pertama, estimasi 4–6 minggu 1–2 dev)
- [P0] Auth + 3 peran + RBAC (F10 inti).
- [P0] 2FA TOTP + backup codes + kebijakan wajib untuk Owner (F13 inti; Staff/Teknisi opsional di MVP, penegakan global via pengaturan).
- [P0] Upload gambar/video/teks + library + preview (F1 inti, tanpa transkoding berat — cukup thumbnail).
- [P0] Layar + pairing code + grup (F2 inti).
- [P0] Playlist + assign layar (F3 inti).
- [P0] Jadwal promo sederhana: rentang tanggal + jam (F4 inti, tanpa prioritas kompleks — 1 pemenang = prioritas tertinggi).
- [P0] Approval terbit (F5) + Approval hapus (F6).
- [P0] Player fullscreen + cache offline + heartbeat + proof-of-play (F7 inti).
- [P0] Monitoring Now Playing + online/offline (F8 inti).
- [P0] Proof-of-play log + laporan harian/mingguan + email mingguan otomatis Minggu 18:00 (F9 inti).
- [P0] Notifikasi in-app minimal (review + offline) (F11 inti).
- [P0] Audit log dasar (F12 inti).

**Kriteria keluar MVP:** alur Staff→Review→Tayang→Laporan mingguan berjalan end-to-end di 5+ layar nyata selama 1 minggu tanpa layar hitam > 3 detik dan email mingguan terkirim; **100% akun Owner sudah aktif 2FA** dan login tanpa kode valid selalu ditolak (terverifikasi via uji).

### Fase 2 — Nice-to-Have (setelah MVP stabil)
- Template pengumuman siap pakai + penjadwal berulang (mingguan/bulanan) + pengecualian hari libur nasional.
- Transisi animasi, layout split-screen multi-zona (video + ticker + jam + cuaca).
- Screenshot layar jarak jauh (player kirim thumbnail berkala) sebagai bukti visual.
- Perintah daya (reboot/nyala-mati terjadwal via CEC) + kontrol volume jarak jauh.
- Multi-bahasa (ID/EN), mode gelap dashboard, ekspor PDF cantik.
- Integrasi kalender/event kampus, RSS/berita, cuaca, antrean rumah sakit.
- API publik + webhook (mis. sistem lain memicu konten darurat).

### Fase 3 — Visioner (jangka panjang)
- Editor visual drag-and-drop, animasi HTML5/URL app.
- Bukti tayang dengan foto layar (kamera), analitik perhatian penonton (privasi-aware).
- Multi-tenant (banyak organisasi/usaha dalam satu instalasi), tagihan/kuota.
- Aplikasi mobile teknisi (scan QR pairing, push notifikasi offline).

---

## 9. Metrik Keberhasilan (untuk validasi pasca-rilis)
- Waktu dari upload → tayang yang di-approve ≤ 15 menit (median).
- % layar online harian ≥ 95%.
- 100% konten tayang memiliki approval (0 tayang tanpa approve).
- Email laporan mingguan terkirim tepat waktu ≥ 99%.
- Kepuasan: pemilik dapat approve dari HP ≤ 3 tap; teknisi daftarkan layar ≤ 2 menit.
- Keamanan: 100% akun Owner mengaktifkan 2FA ≤ 7 hari setelah rilis; 0 login sukses tanpa kode 2FA pada akun ber-2FA (hasil uji penetrasi dasar).

## 10. Risiko & Mitigasi
| Risiko | Mitigasi |
|---|---|
| Jaringan lokasi tidak stabil | Cache offline + retry + tampilkan konten terakhir |
| Video besar membuat player lag | Batas ukuran + panduan kompresi + preload + format H.264 |
| Konten salah tayang | Approval wajib + preview + versi + audit |
| Layar mati tidak ketahuan | Heartbeat 30 dtk + badge merah + notifikasi teknisi |
| Storage penuh | Kuota + arsip 30 hari + purge terjadwal + peringatan 80% |
| Pengguna kehilangan akses 2FA (HP hilang) | Backup codes sekali pakai + reset 2FA oleh Owner tercatat audit + notifikasi email keamanan |

---

*Sumber inspirasi praktik industri (prinsip umum, bukan salinan): arsitektur CMS terpusat + player terdistribusi, playlist + scheduling override, device heartbeat/monitoring, dan proof-of-play untuk akuntabilitas penayangan — pola standar sistem digital signage modern.*
