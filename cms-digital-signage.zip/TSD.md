# TSD — CMS Digital Signage (Technical Specification Document)

**Produk:** SignageCMS (pendamping `PRD.md v1.1`)
**Versi Dokumen:** v1.1 (revisi: tambah 2FA TOTP)
**Tanggal:** 8 Oktober 2026
**Bahasa:** Bahasa Indonesia

**Changelog v1.1:** Menambahkan spesifikasi 2FA TOTP — kolom DB + tabel backup codes, endpoint `/auth/2fa/*`, alur login dua tahap, secret terenkripsi, env `TOTP_*`, halaman frontend setup/verifikasi, dan uji `test_2fa.py`.

---

## 1. Arsitektur Sistem

### 1.1 Gambaran Umum

```
                    ┌─────────────────────┐
                    │   TV / Android TV   │
                    │   STB / Mini-PC     │
                    │  ┌───────────────┐  │
                    │  │ PLAYER (web)  │  │── heartbeat 30 dtk ──┐
                    │  │ /player?token │  │── proof-of-play ─────┤
                    │  └───────────────┘  │── poll manifest 60 dtk
                    └─────────┬───────────┘                      │
                              │ HTTPS                            │
                              ▼                                  ▼
                    ┌─────────────────────┐          ┌─────────────────────┐
                    │  nginx (reverse     │          │  Backend API        │
                    │  proxy + static)    │─────────▶│  FastAPI (Python)   │
                    │  :80 / :443         │          │  :8000              │
                    │  - / → dashboard    │          │  - REST JSON       │
                    │  - /player → player │          │  - JWT + device     │
                    │  - /media/* → files │          │    token auth       │
                    │  - /api/* → backend │          │  - Scheduler        │
                    └─────────────────────┘          │    (APScheduler)    │
                                                     └─────────┬───────────┘
                                                               │
                                        ┌──────────────────────┼──────────────────────┐
                                        ▼                      ▼                      ▼
                              ┌─────────────────┐   ┌──────────────────┐   ┌──────────────────┐
                              │  PostgreSQL :5432│   │  Media storage   │   │  SMTP (email)    │
                              │  (data utama)   │   │  volume /media   │   │  laporan mingguan│
                              │  + volume pgdata│   │  (+ thumb cache) │   │  & notifikasi    │
                              └─────────────────┘   └──────────────────┘   └──────────────────┘
                                        ▲
                                        │ backup harian (cron + pg_dump)
                                        ▼
                              ┌─────────────────┐
                              │  Backup volume  │
                              └─────────────────┘

  Admin (Owner/Staff/Teknisi): browser → nginx → dashboard (HTML statis) → fetch /api/*
```

**Aliran data kunci:**
1. **Upload:** Browser → `POST /api/contents/upload` (multipart) → backend simpan ke `/media` + buat thumbnail → catat di DB.
2. **Review:** Staff `POST .../submit-review` → status `pending_review` → Owner `POST .../approve|reject`.
3. **Distribusi:** Player (token device) `GET /api/player/manifest` → backend hanya kembalikan konten/playlist **berstatus approved + jadwal aktif** → player unduh file via signed URL → putar → kirim heartbeat + proof-of-play.
4. **Monitoring:** Backend hitung online/offline dari `last_heartbeat_at`; dashboard polling `GET /api/screens?status=...`.
5. **Laporan:** Scheduler tiap Minggu 18:00 WIB agregasi `play_logs` → simpan `reports` → kirim email via SMTP.

### 1.2 Keputusan Arsitektur
- **Monolit modular (bukan microservices)** untuk MVP: 1 backend FastAPI + 1 DB + 1 nginx. Alasan: tim kecil, deploy sederhana, mudah di-debug di lapangan.
- **Backend stateless:** semua state di PostgreSQL + storage volume; bisa direplika di balik nginx bila butuh scale.
- **Frontend tanpa build-step:** file HTML statis dilayani nginx; logika reaktif via Alpine.js + HTMX/fetch. Player adalah halaman statis terpisah yang ringan agar tahan di STB spek rendah.
- **File media tidak lewat DB:** DB hanya simpan metadata + path; biner di volume (bisa dipindah ke S3-compatible tanpa ubah API).

---

## 2. Tech Stack yang Dipilih (beserta Alasan)

> Mengikuti Technology Stack Rules: user tidak menyebut framework spesifik, maka dipakai default stack tanpa npm build-step.

| Lapisan | Pilihan | Alasan |
|---|---|---|
| **Frontend dashboard + player** | HTML5 + Tailwind CSS (CDN) + Alpine.js (CDN) + HTMX (opsional, CDN) | Tanpa `npm install/build`; cukup file statis → deploy via nginx. Tailwind CDN memberi gaya modern penuh warna dengan cepat (gradien, kartu, badge). Alpine.js cukup untuk drawer/modal/drag-order sederhana. HTMX untuk partial refresh tabel monitoring tanpa SPA berat. Cocok untuk perangkat teknisi/owner yang bervariasi. Tidak memakai React/Next/Vue CLI sesuai aturan. |
| **Backend** | Python **FastAPI** + Uvicorn + SQLAlchemy 2 + Alembic + Pydantic v2 + APScheduler | FastAPI: validasi otomatis, dokumentasi OpenAPI `/docs` gratis, async cocok untuk banyak heartbeat paralel, ekosistem Python mudah untuk tugas media (Pillow, ffmpeg) dan laporan (email, CSV/PDF). Dipilih atas Flask karena typing + performa async lebih baik untuk polling player. |
| **Database** | **PostgreSQL 16** | Default untuk data relasional + transaksional (approval, jadwal, log). Butuh constraint, partial index, dan agregasi laporan (date_trunc, window). Lebih tepat daripada MySQL untuk log besar + JSONB fleksibel (metadata konten). SQLite ditolak karena multi-writer (banyak player bersamaan). |
| **Auth** | JWT access (15 mnt) + refresh (7 hari, httpOnly cookie) + bcrypt (passlib) + **2FA TOTP (`pyotp`) + QR (`qrcode`) + backup codes** | Sederhana, stateless, mudah dicabut via denylist/versi token. TOTP standar RFC 6238 tanpa SMS/OTP vendor (murah, offline-friendly, cocok untuk lapangan). Device player memakai token terpisah (opaque, prefix `scr_`) agar tidak tercampur session user dan tidak terkena 2FA. |
| **Media processing** | Pillow (thumbnail gambar) + `ffmpeg` CLI (thumbnail + probe durasi video) | Ringan, tersedia sebagai paket OS; tanpa service antrean di MVP (proses sinkron < 10 dtk, atau background thread). |
| **Email** | `aiosmtplib` / `smtplib` + Jinja2 template HTML | Untuk undangan, hasil review, laporan mingguan. Konfigurasi via env SMTP generik (Gmail/Mailgun/SMTP lokal). |
| **Reverse proxy + static** | **nginx:alpine** | Satu pintu HTTPS, serve `/` dan `/player` statis + cache `/media`, proxy `/api` ke backend. |
| **Container** | Docker + Docker Compose | 3 service inti (lihat §6). 1 perintah `docker compose up` untuk instalasi di server kantor/toko. |
| **Lainnya** | structlog/logging JSON, `python-multipart` upload, `python-jose` JWT, `APScheduler` cron mingguan, `pyotp` + `qrcode[pil]` + `cryptography` (Fernet) untuk 2FA | Standar, minim dependensi eksotis. Enkripsi secret TOTP memakai Fernet agar secret at-rest tidak plaintext. |

**Yang sengaja TIDAK dipakai di MVP:** Redis (cache/broker) — diganti polling DB + in-memory scheduler single-replica; Celery — diganti APScheduler + thread; S3 wajib — cukup volume lokal dengan abstraksi path (mudah migrasi); WebSocket realtime — diganti polling 30–60 dtk (lebih hemat untuk STB murah dan menekan kompleksitas).

---

## 3. Database Schema

### 3.1 Diagram Relasi (teks)

```
users 1───* contents (created_by)
users 1───* approvals (decided_by) ; users 1───* delete_requests (requested_by)
users 1───* user_backup_codes (kode cadangan 2FA sekali pakai)
contents 1───* content_versions
contents *───* playlists (via playlist_items, ordered)
playlists 1───* schedules
screens *───* playlists (via screen_assignments; 1 default + N scheduled)
screen_groups 1───* screens ; screen_groups *───* playlists (via target grup)
screens 1───* heartbeats (ringkas → screens.last_heartbeat_at)
screens 1───* play_logs ; contents 1───* play_logs
users 1───* notifications
reports (agregat mingguan, tanpa FK keras ke log)
audit_logs (polimorfik: actor, action, entity_type/id, meta JSONB)
pairing_codes 1───1 screens (sekali pakai)
```

### 3.2 Definisi Tabel

Semua tabel memakai `id UUID PK default gen_random_uuid()`, `created_at timestamptz default now()`, `updated_at timestamptz`.

**`users`**
| Kolom | Tipe | Keterangan |
|---|---|---|
| id | uuid PK | |
| name | varchar(100) | |
| email | varchar(255) UNIQUE NOT NULL | lowercased |
| password_hash | varchar(255) NOT NULL | bcrypt |
| role | enum: `owner, staff, teknisi` | default `staff` |
| is_active | boolean default true | nonaktif → token ditolak |
| token_version | int default 0 | naik tiap ganti password/nonaktif → invalidasi JWT lama |
| avatar_url | varchar(500) nullable | |
| last_login_at | timestamptz nullable | |
| totp_secret_enc | text nullable | secret TOTP terenkripsi Fernet; NULL = belum enroll; tidak pernah dikirim ke frontend kecuali saat setup |
| is_2fa_enabled | boolean default false | true hanya setelah konfirmasi kode valid |
| twofa_enrolled_at | timestamptz nullable | |
| twofa_failed_attempts | int default 0 | direset saat sukses |
| twofa_locked_until | timestamptz nullable | kunci tahap verifikasi setelah 5x salah |

**`user_backup_codes`** (kode cadangan 2FA, sekali pakai)
| Kolom | Tipe | Keterangan |
|---|---|---|
| id | uuid PK | |
| user_id | uuid FK→users CASCADE | |
| code_hash | varchar(255) NOT NULL | bcrypt dari kode 8–10 karakter; plaintext hanya tampil sekali saat generate |
| used_at | timestamptz nullable | NULL = masih berlaku |
| created_at | timestamptz default now() | batch generate (10 kode per batch menandai batch_id di meta bila perlu) |

Index: `(user_id, used_at)`.

**`app_settings`** (baru, untuk kebijakan 2FA global + pengaturan umum)
| Kolom | Tipe | Keterangan |
|---|---|---|
| key | varchar(80) PK | mis. `require_2fa_all`, `timezone`, `storage_quota_gb` |
| value | JSONB NOT NULL | mis. `"require_2fa_all": false` (default), `"timezone": "Asia/Jakarta"` |
| updated_by | uuid FK→users nullable | |
| updated_at | timestamptz default now() | |

**`screen_groups`**
| Kolom | Tipe | Keterangan |
|---|---|---|
| id | uuid PK | |
| name | varchar(100) UNIQUE | mis. "Lobi", "Toko A" |
| location | varchar(200) | gedung/lantai/kota |
| description | text nullable | |

**`screens`**
| Kolom | Tipe | Keterangan |
|---|---|---|
| id | uuid PK | |
| name | varchar(120) | mis. "Lobi Lt.1 - TV 01" |
| group_id | uuid FK→screen_groups nullable (SET NULL) | |
| location_detail | varchar(200) | lantai/posisi detail |
| orientation | enum `landscape, portrait` default landscape | |
| resolution | varchar(20) default `1920x1080` | info saja |
| device_token_hash | varchar(255) UNIQUE NOT NULL | hash token `scr_*`; tidak simpan plaintext |
| is_enabled | boolean default true | false = dinonaktifkan |
| last_heartbeat_at | timestamptz nullable | untuk hitung online/offline |
| last_ip | inet nullable | |
| player_version | varchar(20) nullable | |
| current_content_id | uuid FK→contents nullable | denormalisasi Now Playing |
| current_started_at | timestamptz nullable | |

Index: `(is_enabled, last_heartbeat_at)`, `group_id`.

**`pairing_codes`**
| Kolom | Tipe | Keterangan |
|---|---|---|
| code | char(6) PK | mis. "482913" |
| screen_id | uuid FK→screens nullable | NULL = belum diklaim (mode pre-create) atau kode untuk klaim layar baru |
| expires_at | timestamptz NOT NULL | now()+10 menit |
| consumed_at | timestamptz nullable | sekali pakai |
| created_by | uuid FK→users | teknisi/owner pembuat |

**`contents`**
| Kolom | Tipe | Keterangan |
|---|---|---|
| id | uuid PK | |
| title | varchar(200) NOT NULL | |
| type | enum `image, video, ticker, notice` | ticker=teks berjalan, notice=pengumuman |
| file_path | varchar(500) nullable | NULL untuk ticker/notice |
| thumb_path | varchar(500) nullable | |
| mime | varchar(100) nullable | |
| size_bytes | bigint default 0 | |
| duration_sec | int NOT NULL | gambar/notice default 10; video = hasil probe (bisa override) |
| width, height | int nullable | |
| text_payload | JSONB nullable | `{text, speed, fg_color, bg_color, position}` untuk ticker/notice |
| status | enum `draft, pending_review, approved, rejected, pending_delete, archived` default draft | |
| version | int default 1 | naik tiap ajukan ulang |
| created_by | uuid FK→users NOT NULL | |
| rejection_note | text nullable | catatan penolakan terakhir |
| published_at | timestamptz nullable | kapan terakhir di-approve |

Index: `(status)`, `(type, status)`, `(created_by)`.

**`content_versions`** (riwayat revisi)
| Kolom | Tipe | Keterangan |
|---|---|---|
| id | uuid PK | |
| content_id | uuid FK→contents CASCADE | |
| version | int | |
| snapshot | JSONB NOT NULL | salinan metadata + text_payload saat diajukan |
| created_at | timestamptz | |

**`approvals`** (review terbit + hapus, satu tabel)
| Kolom | Tipe | Keterangan |
|---|---|---|
| id | uuid PK | |
| kind | enum `publish, delete` | |
| content_id | uuid FK→contents CASCADE (atau playlist_id nullable — MVP: konten saja; playlist ikut via item) | |
| playlist_id | uuid FK→playlists nullable | untuk approval playlist (F3) |
| requested_by | uuid FK→users | |
| decided_by | uuid FK→users nullable | |
| decision | enum `pending, approved, rejected` default pending | |
| note | text nullable | alasan/catatan |
| decided_at | timestamptz nullable | |

Index: `(decision, kind)`.

**`playlists`**
| Kolom | Tipe | Keterangan |
|---|---|---|
| id | uuid PK | |
| name | varchar(150) | |
| description | text nullable | |
| status | enum sama seperti contents | playlist juga butuh approval bila diubah setelah approved |
| created_by | uuid FK→users | |
| transition | enum `none, fade, slide` default fade | |

**`playlist_items`**
| Kolom | Tipe | Keterangan |
|---|---|---|
| id | uuid PK | |
| playlist_id | uuid FK→playlists CASCADE | |
| content_id | uuid FK→contents RESTRICT | cegah hapus konten yang dipakai (harus arsip via approval) |
| position | int NOT NULL | urutan 0..N |
| override_duration_sec | int nullable | NULL = pakai duration konten |
| UNIQUE(playlist_id, position) deferrable untuk reorder | | |

**`screen_assignments`** (playlist default per layar/grup)
| Kolom | Tipe | Keterangan |
|---|---|---|
| id | uuid PK | |
| playlist_id | uuid FK→playlists CASCADE | |
| screen_id | uuid FK→screens CASCADE nullable | salah satu dari screen_id / group_id wajib isi |
| group_id | uuid FK→screen_groups CASCADE nullable | |
| is_default | boolean default true | 1 default per layar (enforced di aplikasi) |
| CHECK (screen_id IS NOT NULL OR group_id IS NOT NULL) | | |

**`schedules`** (jadwal promo/event — override sementara)
| Kolom | Tipe | Keterangan |
|---|---|---|
| id | uuid PK | |
| name | varchar(150) | mis. "Promo Akhir Pekan" |
| playlist_id | uuid FK→playlists CASCADE | playlist promo |
| screen_id | uuid FK→screens CASCADE nullable | target: screen / group (salah satu wajib) |
| group_id | uuid FK→screen_groups CASCADE nullable | |
| starts_at, ends_at | timestamptz NOT NULL | rentang tanggal |
| daily_start, daily_end | time nullable | slot jam harian, NULL = seharian |
| days_of_week | int[] nullable | mis. `{1,2,3,4,5}` (1=Senin); NULL = semua hari |
| priority | int default 0 | tertinggi menang saat tabrakan |
| timezone | varchar(50) default `Asia/Jakarta` | |
| is_active | boolean default true | |
| CHECK (starts_at < ends_at), CHECK (screen_id IS NOT NULL OR group_id IS NOT NULL) | | |

Index: `(is_active, starts_at, ends_at)`.

**`play_logs`** (proof-of-play, append-only, partisi per bulan bila > 1 jt)
| Kolom | Tipe | Keterangan |
|---|---|---|
| id | bigserial PK | hemat dibanding UUID untuk volume besar |
| screen_id | uuid FK→screens | |
| content_id | uuid FK→contents | |
| playlist_id | uuid FK→playlists nullable | |
| schedule_id | uuid FK→schedules nullable | NULL = default loop |
| started_at | timestamptz NOT NULL | |
| ended_at | timestamptz nullable | |
| played_sec | int default 0 | |
| status | enum `completed, skipped, failed` | completed = ≥90% durasi |
| created_at | timestamptz default now() | |

Index: `(screen_id, started_at DESC)`, `(content_id, started_at DESC)`, `(started_at DESC)`.

**`heartbeats`** (opsional ringkas; MVP boleh hanya update `screens.last_heartbeat_at` + tabel ini untuk grafik uptime)
| Kolom | Tipe | Keterangan |
|---|---|---|
| id | bigserial PK | |
| screen_id | uuid FK→screens | |
| at | timestamptz default now() | |
| ip | inet nullable | |
| player_version | varchar(20) nullable | |

Index: `(screen_id, at DESC)`. Retensi 14 hari (cron hapus).

**`notifications`**
| Kolom | Tipe | Keterangan |
|---|---|---|
| id | uuid PK | |
| user_id | uuid FK→users CASCADE | penerima |
| kind | enum `review_requested, review_decided, delete_requested, delete_decided, screen_offline, report_ready, invite` | |
| title | varchar(200) | |
| body | text nullable | |
| link | varchar(500) nullable | deep-link dashboard |
| is_read | boolean default false | |
| created_at | timestamptz | |

**`reports`** (arsip laporan mingguan)
| Kolom | Tipe | Keterangan |
|---|---|---|
| id | uuid PK | |
| period_start, period_end | date NOT NULL | Senin–Minggu |
| payload | JSONB NOT NULL | ringkasan agregat (total tayang, top konten, downtime) |
| csv_path | varchar(500) nullable | |
| emailed_at | timestamptz nullable | |
| created_at | timestamptz | |

**`audit_logs`**
| Kolom | Tipe | Keterangan |
|---|---|---|
| id | bigserial PK | |
| actor_id | uuid FK→users nullable | NULL = sistem/scheduler |
| action | varchar(80) | `login, upload, submit_review, approve, reject, request_delete, approve_delete, assign, screen_command, ...` |
| entity_type | varchar(40) | `content, playlist, screen, user, ...` |
| entity_id | varchar(80) nullable | |
| meta | JSONB default `{}` | detail tambahan |
| created_at | timestamptz default now() | |

**`invites`**
| Kolom | Tipe | Keterangan |
|---|---|---|
| email | varchar(255) PK-ish | + token |
| token_hash | varchar(255) UNIQUE | |
| role | enum peran | peran yang akan diberikan |
| expires_at | timestamptz | 72 jam |
| accepted_at | timestamptz nullable | |

### 3.3 Aturan Integritas Penting (ditegakkan di DB + backend)
- Player hanya boleh menerima konten `status='approved'` — enforced di query manifest, bukan sekadar filter frontend.
- `playlist_items.content_id RESTRICT` — konten yang dipakai playlist tidak bisa hard-delete.
- Pengajuan hapus konten yang sedang di-assign/jadwal aktif ditolak di service layer dengan daftar pemakaian.
- Satu layar punya tepat 1 assignment default aktif (validasi aplikasi + unique partial index `WHERE is_default`).
- 2FA: `is_2fa_enabled=true` mensyaratkan `totp_secret_enc IS NOT NULL`; reset 2FA wajib menghapus secret + menghanguskan semua backup codes yang belum dipakai; pemakaian backup code bersifat atomik (UPDATE ... WHERE used_at IS NULL) agar tidak bisa dipakai dua kali bersamaan.

---

## 4. API Endpoints

Basis: `/api/v1`. Auth user: `Authorization: Bearer <JWT>` (kecuali login/invite/player). Auth player: header `X-Device-Token: scr_...`.

Format error standar: `{ "detail": "...", "code": "..." }`. List memakai `?page&limit&q&...` → `{ "items": [...], "total": N, "page": P, "limit": L }`.

### 4.1 Auth & Pengguna (termasuk 2FA TOTP)
| Method | Path | Role | Request | Response |
|---|---|---|---|---|
| POST | `/auth/login` | publik | `{email, password}` | Bila user tanpa 2FA: `{access_token, user}` + refresh cookie. Bila 2FA aktif: `{need_2fa:true, challenge_token}` (JWT pendek 5 mnt, scope `2fa`) — frontend lanjut ke layar verifikasi |
| POST | `/auth/2fa/verify-login` | challenge | `{challenge_token, code}` (`code` = 6 digit TOTP atau backup code) | Sukses → `{access_token, user, backup_remaining?}` + refresh cookie; backup code yang dipakai hangus + audit + email keamanan |
| POST | `/auth/refresh` | cookie | — | `{access_token}` (ditolak bila kebijakan wajib-2FA belum dipenuhi user) |
| POST | `/auth/logout` | login | — | `{ok:true}` (hapus cookie) |
| POST | `/auth/forgot-password` | publik | `{email}` | `{ok:true}` (selalu, anti-enumerasi) |
| POST | `/auth/reset-password` | publik | `{token, new_password}` | `{ok:true}` |
| POST | `/auth/2fa/setup` | login | — | `{otpauth_url, qr_data_url, manual_secret(masked? tampil penuh sekali), expires_in_sec:600}` — membuat/menimpa secret sementara (belum aktif) |
| POST | `/auth/2fa/confirm` | login | `{code}` | Verifikasi kode terhadap secret sementara → aktifkan (`is_2fa_enabled=true`) → `{ok:true, backup_codes:[10 plaintext, tampil sekali]}` |
| GET | `/auth/2fa/status` | login | — | `{enabled, enrolled_at, backup_remaining, required_by_policy}` |
| POST | `/auth/2fa/disable` | login | `{password, code}` | Nonaktifkan 2FA sendiri (Owner tetap diblokir bila kebijakan wajib-owner aktif) → hapus secret + hanguskan codes |
| POST | `/auth/2fa/backup-codes/regenerate` | login | `{password}` | Hanguskan batch lama → `{backup_codes:[10 baru]}` + audit |
| POST | `/users/:id/reset-2fa` | owner | `{reason!}` | Reset paksa: nonaktifkan 2FA target + hapus secret/codes + audit `reset_2fa` + email ke target |
| GET | `/users/me` | login | — | profil + `unread_notifications` |
| PATCH | `/users/me` | login | `{name, avatar_url}` | profil |
| POST | `/users/change-password` | login | `{old_password, new_password}` | `{ok:true}` (+ naikkan token_version) |
| GET | `/users` | owner | `?role&q&page` | list users |
| POST | `/users/invite` | owner | `{email, role}` | `{invite_link}` + kirim email |
| POST | `/users/accept-invite` | publik | `{token, name, password}` | `{access_token, user}` |
| PATCH | `/users/:id/role` | owner | `{role}` | user |
| PATCH | `/users/:id/active` | owner | `{is_active}` | user |

### 4.2 Konten
| Method | Path | Role | Keterangan |
|---|---|---|---|
| GET | `/contents?type&status&q&page&mine` | login | list + thumbnail URL; teknisi hanya lihat judul/thumb |
| POST | `/contents/upload` | staff,owner | multipart `file,title,duration_sec?` → validasi → simpan + thumbnail; resp `201 {content}` |
| POST | `/contents/text` | staff,owner | `{title,type:ticker\|notice,text_payload,duration_sec}` → `201` |
| GET | `/contents/:id` | login | detail + versi + `used_in {playlists,screens,schedules}` |
| PATCH | `/contents/:id` | staff(pemilik konten)/owner | edit hanya saat `draft/rejected`; buat versi baru |
| POST | `/contents/:id/submit-review` | staff,owner | draft→pending_review; buat baris approvals(kind=publish); notifikasi owner |
| POST | `/contents/:id/approve` | owner | `{note?}` → approved + `published_at`; notifikasi staff |
| POST | `/contents/:id/reject` | owner | `{note!}` → rejected; notifikasi staff |
| POST | `/contents/:id/request-delete` | staff,owner | `{reason}` → cek pemakaian; → pending_delete + approvals(kind=delete) |
| POST | `/contents/:id/approve-delete` | owner | → archived (soft-delete) |
| POST | `/contents/:id/reject-delete` | owner | `{note}` → kembali approved |
| GET | `/contents/:id/preview-url` | login | signed URL sementara (5 mnt) untuk `<video>/<img>` |

Contoh `text_payload` ticker: `{ "text": "PROMO AKHIR PEKAN...", "speed": "normal", "fg_color": "#FFFFFF", "bg_color": "#E11D48", "position": "bottom" }`.

### 4.3 Playlist, Assignment, Jadwal
| Method | Path | Role | Keterangan |
|---|---|---|---|
| GET/POST | `/playlists` | staff,owner | list/buat `{name, transition}` |
| GET/PATCH/DELETE | `/playlists/:id` | staff,owner | edit (versi/approval ulang bila sudah approved) |
| POST | `/playlists/:id/items` | staff,owner | `{content_id, position?, override_duration_sec?}` — content harus approved |
| PATCH | `/playlists/:id/items/reorder` | staff,owner | `{ordered_ids:[itemId...]}` |
| DELETE | `/playlists/:id/items/:itemId` | staff,owner | hapus item |
| POST | `/playlists/:id/submit-review` | staff,owner | playlist ikut approval (opsional MVP: approval cukup di konten; playlist butuh approve bila berisi konten pending) |
| POST | `/assignments` | staff,owner | `{playlist_id, screen_id?\|group_id?}` → jadikan default |
| GET | `/assignments?screen_id` | login | lihat assignment |
| GET/POST | `/schedules` | staff,owner | list/buat jadwal promo (validasi tabrakan → warning `conflicts:[...]`) |
| PATCH/DELETE | `/schedules/:id` | staff,owner | ubah/nonaktifkan |

### 4.4 Layar & Pairing
| Method | Path | Role | Keterangan |
|---|---|---|---|
| GET | `/screens?status&q&group_id` | login | `status=online\|offline\|disabled`; sertakan `now_playing` ringkas |
| POST | `/screens` | teknisi,owner | `{name, group_id?, orientation?, resolution?}` → resp `{screen, device_token(sekali tampil!), pairing_hint}` |
| GET | `/screens/:id` | login | detail + antrean + heartbeat 24 jam |
| PATCH | `/screens/:id` | teknisi,owner | edit info/pindah grup |
| POST | `/screens/pairing-code` | teknisi,owner | buat kode 6 digit `{screen_id?}` → `{code, expires_at}` |
| POST | `/screens/claim` | teknisi,owner | `{code, screen_id?}` → klaim/aktifkan layar |
| POST | `/screens/:id/commands` | teknisi,owner | `{command: reload\|identify\|refresh_manifest}` → antrean perintah dibaca player saat poll |
| POST | `/screens/:id/regenerate-token` | owner | putar token device (token lama hangus) |
| PATCH | `/screens/:id/enable` | teknisi,owner | `{is_enabled}` |
| GET/POST | `/screen-groups` | owner,(teknisi baca) | CRUD grup & lokasi |

### 4.5 Player API (dipakai TV, auth device-token)
| Method | Path | Keterangan |
|---|---|---|
| GET | `/player/manifest` | Header device-token. Resp: `{ screen:{id,name,orientation}, playlist:{id,name}, items:[{content_id,type,title,file_url?,thumb_url?,duration_sec,text_payload?}], ticker:{...}?, server_time, refresh_in_sec:60, pending_commands:[...] }`. Hanya item approved + jadwal aktif (server pilih pemenang prioritas). `file_url` = signed URL 2 jam. |
| POST | `/player/heartbeat` | `{player_version?, now_playing_content_id?, queue_len?}` → `{ok, server_time, pending_commands}`. Update `last_heartbeat_at`. |
| POST | `/player/proof` | `{content_id, playlist_id?, schedule_id?, started_at, ended_at, played_sec, status}` → `201`. Idempotency-Key disarankan. |
| POST | `/player/pair` | `{pairing_short_code?}` — dipakai layar belum terdaftar untuk tampilkan kode (alternatif: kode dibuat dashboard). |
| GET | `/media/:path` | Serve biner via nginx (X-Accel-Redirect) atau backend dengan signed query `?sig&exp`. Cache `immutable` 1 tahun per hash nama file. |

Contoh manifest (ringkas):
```json
{
  "screen": {"id": "uuid", "name": "Lobi Lt.1 - TV 01", "orientation": "landscape"},
  "playlist": {"id": "uuid", "name": "Loop Harian"},
  "items": [
    {"content_id": "uuid", "type": "video", "title": "Promo Sehat", "file_url": "/media/v/..mp4?sig=..", "duration_sec": 30},
    {"content_id": "uuid", "type": "ticker", "title": "Antrian", "duration_sec": 15, "text_payload": {"text": "...", "bg_color": "#E11D48"}}
  ],
  "server_time": "2026-10-08T10:00:00+07:00",
  "refresh_in_sec": 60
}
```

### 4.6 Monitoring, Laporan, Notifikasi, Audit
| Method | Path | Role | Keterangan |
|---|---|---|---|
| GET | `/monitoring/overview` | login | `{online, offline, disabled, now_playing:[{screen, content, started_at}]}` |
| GET | `/play-logs?screen_id&content_id&from&to&page` | owner,staff(terbatas) | bukti tayang mentah |
| GET | `/reports/summary?from&to&screen_id` | login sesuai peran | agregat: total_plays, total_sec, top_contents, downtime |
| GET | `/reports/weekly?week=YYYY-Www` | owner | arsip mingguan + `csv_url` |
| GET | `/reports/weekly/:id/export.csv` | owner | unduh CSV |
| POST | `/reports/weekly/generate` | owner | generate manual (untuk uji; otomatis via scheduler) |
| GET | `/notifications?unread_only` | login | list |
| POST | `/notifications/:id/read` | login | tandai baca |
| POST | `/notifications/read-all` | login | tandai semua |
| GET | `/audit-logs?action&from&to&page` | owner | jejak aksi (termasuk `2fa_enabled/disabled/failed/backup_used/reset_2fa`) |
| GET | `/healthz` | publik | `{ok, db, storage, time}` untuk Docker healthcheck & monitoring |
| GET | `/settings` | owner baca; login baca `require_2fa_all` | `{require_2fa_all, timezone, ...}` |
| PATCH | `/settings` | owner | `{require_2fa_all?, timezone?, ...}` — mengaktifkan `require_2fa_all=true` memaksa semua user tanpa 2FA enroll saat login berikutnya |

---

## 5. Struktur Folder Project

Dipilih agar frontend tetap file statis (tanpa build) dan backend terpisah jelas:

```
signagecms/
├── docker-compose.yml
├── .env.example
├── README.md
├── PRD.md
├── TSD.md
├── nginx/
│   └── nginx.conf            # reverse proxy + serve static + /media cache
├── frontend/                 # dilayani nginx sebagai static (tanpa npm)
│   ├── index.html            # redirect ke /dashboard/ bila login, else /login.html
│   ├── login.html            # tahap 1: email+password; lanjut ke verify-2fa.html bila need_2fa
│   ├── verify-2fa.html       # tahap 2: kode TOTP / backup code + lockout notice
│   ├── setup-2fa.html        # enroll: QR + secret manual + konfirmasi + backup codes
│   ├── css/
│   │   └── app.css           # custom kecil di atas Tailwind CDN + tema warna promosi
│   ├── js/
│   │   ├── api.js            # wrapper fetch + JWT + refresh
│   │   ├── auth.js           # login/logout/guard peran
│   │   └── components.js     # helper Alpine stores, badge, toast
│   ├── dashboard/
│   │   ├── index.html        # Beranda ringkasan
│   │   ├── contents.html     # library + upload + teks
│   │   ├── playlists.html
│   │   ├── schedules.html
│   │   ├── screens.html
│   │   ├── review.html       # antrean approve + hapus
│   │   ├── monitoring.html
│   │   ├── reports.html
│   │   ├── users.html
│   │   └── settings.html
│   └── player/
│       └── index.html        # player fullscreen (dipakai TV) + pairing view
├── backend/
│   ├── Dockerfile
│   ├── requirements.txt
│   ├── alembic.ini
│   ├── alembic/
│   │   └── versions/
│   ├── app/
│   │   ├── __init__.py
│   │   ├── main.py           # FastAPI app, router, middleware, /healthz, /docs
│   │   ├── config.py         # baca env (DB, JWT, SMTP, storage, batas upload)
│   │   ├── deps.py           # get_db, require_roles, get_current_user/device, require_2fa_ok
│   │   ├── security.py       # hash, JWT, device token, signed URL
│   │   ├── totp.py           # 2FA: generate secret, otpauth_url, QR, verifikasi pyotp (±1 window), enkripsi Fernet, backup codes
│   │   ├── storage.py        # simpan file, thumbnail, signed URL
│   │   ├── mailer.py         # kirim email + template Jinja
│   │   ├── scheduler.py      # APScheduler: laporan mingguan, purge, offline-notify
│   │   ├── models/           # models SQLAlchemy per domain
│   │   ├── schemas/          # Pydantic request/response
│   │   ├── routers/          # auth (+2fa), users, contents, playlists, screens, player, monitoring, reports, settings
│   │   └── services/         # approval_service, manifest_service, report_service, pairing_service, twofa_service
│   ├── templates/
│   │   └── email/            # invite.html, review.html, weekly_report.html
│   └── tests/
│       ├── test_approval.py
│       ├── test_manifest.py
│       ├── test_reports.py
│       └── test_2fa.py         # enroll/confirm, login 2 tahap, backup code sekali pakai, lockout, reset owner
├── media/                    # volume mount (gitignore isinya)
│   └── .gitkeep
└── backups/                  # output pg_dump harian (volume)
```

**Konvensi:**
- File upload tersimpan `media/{images,videos,thumbs}/YYYY/MM/<uuid>.<ext>`; nama acak anti-collision; serve via nginx dengan `Cache-Control: public, max-age=31536000, immutable`.
- Semua halaman dashboard memakai layout bersama (sidebar + topbar + Alpine store `auth`) agar konsisten; warna aksen promosi: gradien fuchsia→amber untuk header kartu, badge status hijau/merah/kuning.

---

## 6. Docker Services

`docker-compose.yml` — 3 service wajib + 1 opsional backup:

```yaml
services:
  db:
    image: postgres:16-alpine
    environment:
      POSTGRES_DB: signage
      POSTGRES_USER: signage
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    volumes: ["pgdata:/var/lib/postgresql/data"]
    healthcheck: {test: ["CMD-SHELL", "pg_isready -U signage"], interval: 10s, retries: 5}
    restart: unless-stopped

  backend:
    build: ./backend
    command: uvicorn app.main:app --host 0.0.0.0 --port 8000
    env_file: [.env]
    volumes: ["./media:/app/media", "./backend:/app:ro"]
    depends_on: {db: {condition: service_healthy}}
    healthcheck: {test: ["CMD", "python", "-c", "import urllib.request; urllib.request.urlopen('http://localhost:8000/healthz')"], interval: 15s, retries: 5}
    restart: unless-stopped

  frontend:  # nginx: static + proxy
    image: nginx:alpine
    ports: ["${HTTP_PORT:-8080}:80"]  # 443 bila sertifikat tersedia
    volumes: ["./frontend:/usr/share/nginx/html:ro", "./media:/usr/share/nginx/media:ro", "./nginx/nginx.conf:/etc/nginx/conf.d/default.conf:ro"]
    depends_on: [backend]
    restart: unless-stopped

  backup:  # cron pg_dump harian (profil opsional)
    image: postgres:16-alpine
    profiles: ["backup"]
    volumes: ["./backups:/backups", "pgdata:/var/lib/postgresql/data:ro"]
    entrypoint: ["sh", "-c", "while true; do pg_dump -h db -U signage signage > /backups/signage-$$(date +%F).sql; sleep 86400; done"]

volumes: {pgdata: {}}
```

**Variabel `.env` utama:** `DB_PASSWORD, DATABASE_URL, JWT_SECRET, JWT_EXPIRE_MIN=15, REFRESH_DAYS=7, MEDIA_DIR=/app/media, MAX_IMAGE_MB=10, MAX_VIDEO_MB=200, STORAGE_QUOTA_GB=50, TZ=Asia/Jakarta, SMTP_HOST/PORT/USER/PASS/FROM, WEEKLY_REPORT_CRON="0 18 * * 0", OFFLINE_THRESHOLD_SEC=90, SIGNED_URL_TTL_SEC=7200, CORS_ORIGINS, TOTP_ISSUER=SignageCMS, TOTP_ENCRYPTION_KEY=(Fernet 32-byte, wajib di production), TOTP_WINDOW=1, CHALLENGE_TOKEN_MIN=5, REQUIRE_2FA_OWNER=true, REQUIRE_2FA_ALL=false`.

**Nginx ringkas:** `/` → static dashboard; `/player` → static player (header `X-Frame-Options` longgar bila perlu embed); `/media/*` → cache agresif; `/api/*` → `proxy_pass http://backend:8000` + batas body `client_max_body_size 220m`.

---

## 7. Authentication & Authorization Flow

### 7.1 User (dashboard) — Password + 2FA TOTP, JWT + Refresh Cookie
1. Tahap 1 — `POST /auth/login {email,password}` → verifikasi bcrypt → cek `is_active` → cek lockout. Bila user **tanpa 2FA dan tidak diwajibkan kebijakan** → terbitkan access JWT `{sub:user_id, role, tv:token_version, exp:15m}` + refresh cookie seperti biasa. Bila user **2FA aktif atau wajib enroll** → terbitkan `challenge_token` JWT pendek (5 mnt, scope `2fa`, belum bisa akses API bisnis) + `{need_2fa:true}` atau `{need_enroll:true}`.
2. Tahap 2 (verify) — `POST /auth/2fa/verify-login {challenge_token, code}` → validasi challenge → cocokkan TOTP via `pyotp` (periode 30 dtk, window ±1) **atau** salah satu backup code (bandingkan bcrypt, tandai `used_at` atomik). Sukses → reset `twofa_failed_attempts`, terbitkan access + refresh penuh; bila backup code dipakai → audit `backup_used` + kirim email keamanan. Gagal → `twofa_failed_attempts += 1`; 5x salah → `twofa_locked_until = now()+15 mnt` + audit `2fa_failed`.
3. Enroll — login penuh → `POST /auth/2fa/setup` → server generate secret acak (Base32, 160-bit), enkripsi Fernet ke `totp_secret_enc` (status tetap disabled), kembalikan `otpauth://totp/{ISSUER}:{email}?secret=...&issuer=...` + QR data-URL (kedaluwarsa 10 mnt). → `POST /auth/2fa/confirm {code}` → cocok → `is_2fa_enabled=true`, generate 10 backup codes (plaintext tampil sekali, simpan bcrypt), audit `2fa_enabled`.
4. Penegakan kebijakan — middleware `require_2fa_ok`: bila `REQUIRE_2FA_ALL=true` (atau role owner + `REQUIRE_2FA_OWNER=true`) dan `is_2fa_enabled=false` → semua endpoint bisnis `403 {code:"2fa_required"}` kecuali `/auth/2fa/*` + `/settings` (baca). Frontend mengarahkan ke `setup-2fa.html`.
5. Setiap request: `get_current_user` → decode JWT → tolak bila `!is_active`, `tv != token_version`, atau token bertipe challenge dipakai ke endpoint bisnis.
6. Refresh/logout/nonaktif sama seperti sebelumnya (bump `token_version` menghanguskan semua session; reset 2FA tidak otomatis logout tetapi menaikkan audit).
7. Brute-force berlapis: rate-limit 10/menit/IP untuk `/auth/*` + khusus `/auth/2fa/verify-login` 5/menit/IP + lockout akun 15 menit setelah 5 gagal; semua kegagalan 2FA masuk audit log.
8. Secret at-rest terenkripsi Fernet (`TOTP_ENCRYPTION_KEY`); rotasi kunci didukung via versi prefix (`v1:...`). Backup codes selalu bcrypt, tidak reversible.

### 7.2 Device (player TV) — Opaque Token
1. Saat layar dibuat, backend generate `scr_<32 random>` → tampilkan **sekali** ke teknisi → simpan **hash SHA256** di `screens.device_token_hash`.
2. TV membuka `/player/?token=scr_...` (atau token disimpan di localStorage STB). Setiap panggilan `/api/player/*` kirim `X-Device-Token`.
3. Backend hash + cocokkan + cek `is_enabled`. Token tidak punya peran — hanya boleh akses endpoint `/player/*` + file media milik layarnya (signed URL).
4. Regenerasi (`POST /screens/:id/regenerate-token`) dan disable langsung memutus akses. Pairing code terpisah (6 digit, 10 menit, sekali pakai) hanya untuk klaim awal, bukan untuk playback rutin.

### 7.3 Signed URL Media
- `GET /contents/:id/preview-url` (user) dan manifest (device) mengembalikan URL `/media/...?exp=<ts>&sig=HMAC(secret, path+exp)`. Nginx/backend verifikasi sebelum serve. TTL: preview 5 menit, player 2 jam (cukup untuk unduh + cache).

---

## 8. Third-Party Integrations

| Integrasi | Kebutuhan | Rencana |
|---|---|---|
| **SMTP email** | Undangan, hasil review, laporan mingguan | Wajib MVP. Provider bebas (Gmail App Password / Mailgun / SMTP kantor). Template Jinja responsif + tautan deep-link. Fallback: bila SMTP down, notifikasi in-app tetap jalan; pengiriman di-retry 3x + catat `emailed_at` NULL + badge "gagal kirim". |
| **Object storage S3-compatible** | Jika storage lokal penuh / multi-server | Opsional Fase 2. Abstraksi `storage.py` (`save/open/sign_url`) sehingga pindah ke MinIO/AWS S3 hanya ubah driver + env, tanpa ubah API. |
| **ffmpeg / Pillow** | Thumbnail + probe durasi | Wajib (bundel di image backend via `apk add ffmpeg`). Bukan SaaS — jalan lokal. |
| **Kalender hari libur / cuaca / RSS berita** | Konten otomatis (nice-to-have) | Fase 2+. Desain `schedules` sudah mendukung `days_of_week`; REST sumber eksternal cukup jadi `content` bertipe `notice` yang di-refresh scheduler. |
| **Push (FCM/WebPush)** | Notifikasi HP teknisi saat offline | Fase 2+. MVP cukup email + polling bell. |
| **PDF export** | Laporan cantik | MVP cukup CSV + cetak-browser (print CSS). PDF via WeasyPrint/ReportLab di Fase 2 bila diminta. |

Tidak ada integrasi pembayaran, peta, atau AI kamera di MVP (sesuai PRD out-of-scope).

---

## 9. Seed Data Plan

Tujuan: sekali `docker compose up` + 1 perintah seed, demo end-to-end (upload → approval → tayang → laporan) langsung bisa dicoba. Dijalankan via `python -m app.seed` (idempoten: lewati bila email sudah ada).

**Akun (password default `Signage123!`, wajib diganti):**
- `owner@demo.local` (owner) — Penerima laporan mingguan. Seed: 2FA **nonaktif** secara default agar demo cepat, dengan 1x perintah contoh untuk enroll; dokumentasikan bahwa production wajib aktif.
- `marketing@demo.local` (staff) — pembuat konten.
- `teknisi@demo.local` (teknisi).
- `app_settings.require_2fa_all = false`, `require_2fa_owner = true` (peringatan di dashboard demo bila owner belum enroll).

**Grup & layar:**
- Grup: `Lobi Gedung A`, `Toko Cabang 1`, `Ruang Tunggu RS`.
- Layar: `Lobi Lt.1 - TV 01` (landscape, online simulasi), `Lobi Lt.1 - TV 02` (portrait), `Toko 1 - Kasir` (landscape), `Toko 1 - Etalase` (landscape, disabled untuk demo offline), `Ruang Tunggu - TV 01`.
- Device token demo dicetak ke console seed (prefiks `scr_demo...`) agar mudah ditempel ke `/player/?token=`.

**Konten (pakai file placeholder bebas lisensi yang digenerate lokal, bukan aset berhak cipta):**
- 3 gambar gradien promosi (digenerate Pillow saat seed: "PROMO BUKA CABANG", "JADWAL LAYANAN", "SELAMAT DATANG") — status approved.
- 1 video sampel kecil (boleh kosongkan file + tandai durasi 15 dtk bila ffmpeg sample tidak ada; atau unduh BigBuckBunny 5 dtk bila online — fallback ke gambar bila offline).
- 2 ticker: "Teks berjalan pengumuman ..." + 1 notice "PENGUMUMAN: ...".
- 1 konten `pending_review` ("Promo Baru - menunggu approval") + 1 `pending_delete` untuk demo antrean owner.

**Playlist, assignment, jadwal:**
- Playlist `Loop Harian Lobi` (approved, berisi 3 gambar + 1 ticker) → default ke grup Lobi.
- Playlist `Promo Akhir Pekan` (approved) + schedule aktif minggu ini (prioritas 10) ke `Toko Cabang 1` untuk demo override.
- 1 schedule kedaluwarsa minggu lalu (untuk demo riwayat).

**Laporan & notifikasi:**
- Generate 200 baris `play_logs` 7 hari terakhir (acak wajar per layar) agar grafik laporan langsung terisi.
- 1 `reports` minggu lalu (`emailed_at` terisi) + notifikasi `report_ready` untuk owner.
- 1 notifikasi `review_requested` untuk owner + 1 `screen_offline` untuk teknisi (dari layar disabled).

**Perintah seed:**
```bash
docker compose up -d db
docker compose run --rm backend alembic upgrade head
docker compose run --rm backend python -m app.seed   # idempoten
docker compose up -d
# buka http://localhost:8080  |  player: http://localhost:8080/player/?token=scr_demo...
```

---

## 10. Pertimbangan Non-Fungsional Teknis (ringkas, melengkapi PRD §6)

- **Polling efisien:** heartbeat 30 dtk + manifest 60 dtk per layar → ~100 layar ≈ 5 req/dtk puncak; gunakan index `last_heartbeat_at`, respons manifest < 50 KB (URL saja, bukan biner).
- **Upload besar:** `client_max_body_size 220m`, streaming ke disk (bukan buffer RAM), timeout 300 dtk; validasi magic-bytes via `python-magic`/`file`.
- **Retensi & purge:** cron harian: `heartbeats > 14 hari`, `play_logs > 90 hari` (agregat tetap di `reports`), file `archived > 30 hari`, `audit_logs > 180 hari`. Peringatan storage 80%.
- **Arah desain/UX (hasil riset praktik industri):** pola standar CMS signage — navigasi kiri (Konten, Playlist, Jadwal, Layar, Review, Monitoring, Laporan), kartu status berwarna + thumbnail Now Playing, kalender jadwal denganplaceholder override, dan player yang mengutamakan fullscreen + ticker + jam. Dashboard memakai gaya promosi (gradien, ilustrasi, badge) tetapi player memakai tema netral gelap agar konten menonjol dan hemat daya — prinsip umum yang diadopsi tanpa menyalin aset/brand pihak mana pun.
- **Testing MVP:** pytest untuk approval-guard (konten pending tidak muncul di manifest), konflik jadwal (prioritas), proof-of-play idempoten, dan pengiriman laporan mingguan (mock SMTP). Tambah `test_2fa.py`: enroll→confirm→login 2 tahap sukses, tolak kode salah, backup code sekali pakai (pakai kedua gagal), lockout setelah 5x salah, `2fa_required` saat kebijakan global aktif, dan reset owner menghanguskan secret/codes lama.

---

*Dokumen ini siap dipakai sebagai acuan implementasi. Langkah berikutnya: `alembic upgrade head` → seed → bangun endpoint auth → konten → layar/pairing → manifest player → approval → monitoring/laporan.*
